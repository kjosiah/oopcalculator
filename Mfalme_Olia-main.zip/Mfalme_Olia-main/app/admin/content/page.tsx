"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import AdminLayout from "@/components/admin-layout"
import { Save, Edit, Plus, Trash2, FileText, Settings, MessageSquare, DollarSign, Globe } from "lucide-react"

export default function ContentManagementPage() {
  const [activeTab, setActiveTab] = useState("services")
  const [editingService, setEditingService] = useState<string | null>(null)

  // Mock data - in production, this would come from your database
  const [services, setServices] = useState([
    {
      id: "1",
      name: "Essay Writing",
      description: "Custom essays crafted to your specifications with thorough research and perfect formatting.",
      price: 4,
      features: ["Original content", "Proper citations", "Timely delivery"],
    },
    {
      id: "2",
      name: "Research Papers",
      description: "In-depth research papers with comprehensive analysis and scholarly references.",
      price: 4,
      features: ["Extensive research", "Academic standards", "Expert analysis"],
    },
    {
      id: "3",
      name: "Editing & Proofreading",
      description: "Professional editing services to polish your work to perfection.",
      price: 4,
      features: ["Grammar correction", "Style improvement", "Structure optimization"],
    },
    {
      id: "4",
      name: "Class Management Services",
      description: "Comprehensive class management and academic support services.",
      price: 25,
      features: ["Weekly management", "Assignment tracking", "Progress reports"],
    },
  ])

  const [testimonials, setTestimonials] = useState([
    {
      id: "1",
      name: "Sarah M.",
      role: "Graduate Student",
      content:
        "WriteHunters delivered an exceptional research paper that exceeded my expectations. The quality and attention to detail were outstanding.",
      rating: 5,
    },
    {
      id: "2",
      name: "James K.",
      role: "PhD Candidate",
      content:
        "Professional, reliable, and always on time. Their editing service helped me improve my thesis significantly.",
      rating: 5,
    },
    {
      id: "3",
      name: "Maria L.",
      role: "Undergraduate",
      content: "The team at WriteHunters understands academic requirements perfectly. Highly recommend their services!",
      rating: 5,
    },
    {
      id: "4",
      name: "David R.",
      role: "Master's Student",
      content:
        "Their class management service has been a game-changer for my busy schedule. Professional and reliable support.",
      rating: 5,
    },
  ])

  const [contactInfo, setContactInfo] = useState({
    whatsapp: "+254 748 881893",
    email: "writehunters@gmail.com",
    facebook: "https://www.facebook.com/profile.php?id=61577361405554",
    instagram: "https://www.instagram.com/writehunters/",
    paypal: "pjay82577@gmail.com",
    bankAccount: "7770178461745",
    accountName: "Josiah Olia",
  })

  const handleSaveService = (serviceId: string) => {
    // In production, this would save to your database
    setEditingService(null)
    // Show success message
  }

  const handleDeleteService = (serviceId: string) => {
    setServices(services.filter((s) => s.id !== serviceId))
  }

  const handleSaveTestimonial = (testimonialId: string) => {
    // In production, this would save to your database
    // Show success message
  }

  const handleDeleteTestimonial = (testimonialId: string) => {
    setTestimonials(testimonials.filter((t) => t.id !== testimonialId))
  }

  return (
    <AdminLayout title="Content Management">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">Content Management</h1>
          <Badge className="bg-green-100 text-green-800">All systems operational</Badge>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="services" className="flex items-center space-x-2">
              <FileText className="h-4 w-4" />
              <span>Services</span>
            </TabsTrigger>
            <TabsTrigger value="testimonials" className="flex items-center space-x-2">
              <MessageSquare className="h-4 w-4" />
              <span>Testimonials</span>
            </TabsTrigger>
            <TabsTrigger value="contact" className="flex items-center space-x-2">
              <Settings className="h-4 w-4" />
              <span>Contact Info</span>
            </TabsTrigger>
            <TabsTrigger value="pricing" className="flex items-center space-x-2">
              <DollarSign className="h-4 w-4" />
              <span>Pricing</span>
            </TabsTrigger>
            <TabsTrigger value="website" className="flex items-center space-x-2">
              <Globe className="h-4 w-4" />
              <span>Website</span>
            </TabsTrigger>
          </TabsList>

          {/* Services Management */}
          <TabsContent value="services" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">Manage Services</h2>
              <Button className="bg-coral hover:bg-coral/90">
                <Plus className="h-4 w-4 mr-2" />
                Add New Service
              </Button>
            </div>

            <div className="grid gap-6">
              {services.map((service) => (
                <Card key={service.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center space-x-2">
                        <span>{service.name}</span>
                        <Badge>${service.price}/page</Badge>
                      </CardTitle>
                      <div className="flex space-x-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setEditingService(editingService === service.id ? null : service.id)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDeleteService(service.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {editingService === service.id ? (
                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium mb-2">Service Name</label>
                          <input type="text" defaultValue={service.name} className="w-full p-2 border rounded-lg" />
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-2">Description</label>
                          <textarea
                            defaultValue={service.description}
                            rows={3}
                            className="w-full p-2 border rounded-lg"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-2">Price per Page ($)</label>
                          <input type="number" defaultValue={service.price} className="w-full p-2 border rounded-lg" />
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-2">Features (one per line)</label>
                          <textarea
                            defaultValue={service.features.join("\n")}
                            rows={3}
                            className="w-full p-2 border rounded-lg"
                          />
                        </div>
                        <div className="flex space-x-2">
                          <Button
                            onClick={() => handleSaveService(service.id)}
                            className="bg-success hover:bg-success/90"
                          >
                            <Save className="h-4 w-4 mr-2" />
                            Save Changes
                          </Button>
                          <Button variant="outline" onClick={() => setEditingService(null)}>
                            Cancel
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div>
                        <p className="text-muted-foreground mb-4">{service.description}</p>
                        <div className="flex flex-wrap gap-2">
                          {service.features.map((feature, index) => (
                            <Badge key={index} variant="outline">
                              {feature}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Testimonials Management */}
          <TabsContent value="testimonials" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">Manage Testimonials</h2>
              <Button className="bg-coral hover:bg-coral/90">
                <Plus className="h-4 w-4 mr-2" />
                Add New Testimonial
              </Button>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              {testimonials.map((testimonial) => (
                <Card key={testimonial.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-lg">{testimonial.name}</CardTitle>
                        <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                      </div>
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDeleteTestimonial(testimonial.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center mb-2">
                      <div className="flex text-yellow-400">{"★".repeat(testimonial.rating)}</div>
                    </div>
                    <p className="text-sm text-muted-foreground">{testimonial.content}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Contact Information */}
          <TabsContent value="contact" className="space-y-6">
            <h2 className="text-xl font-semibold">Contact Information</h2>

            <Card>
              <CardHeader>
                <CardTitle>Update Contact Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">WhatsApp Number</label>
                    <input type="text" defaultValue={contactInfo.whatsapp} className="w-full p-2 border rounded-lg" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Email Address</label>
                    <input type="email" defaultValue={contactInfo.email} className="w-full p-2 border rounded-lg" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Facebook URL</label>
                    <input type="url" defaultValue={contactInfo.facebook} className="w-full p-2 border rounded-lg" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Instagram URL</label>
                    <input type="url" defaultValue={contactInfo.instagram} className="w-full p-2 border rounded-lg" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">PayPal Email</label>
                    <input type="email" defaultValue={contactInfo.paypal} className="w-full p-2 border rounded-lg" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Bank Account Number</label>
                    <input
                      type="text"
                      defaultValue={contactInfo.bankAccount}
                      className="w-full p-2 border rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Account Name</label>
                    <input
                      type="text"
                      defaultValue={contactInfo.accountName}
                      className="w-full p-2 border rounded-lg"
                    />
                  </div>
                </div>
                <Button className="bg-success hover:bg-success/90">
                  <Save className="h-4 w-4 mr-2" />
                  Save Contact Information
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Pricing Management */}
          <TabsContent value="pricing" className="space-y-6">
            <h2 className="text-xl font-semibold">Pricing Configuration</h2>

            <Card>
              <CardHeader>
                <CardTitle>Base Pricing</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Price per Page ($)</label>
                    <input type="number" defaultValue="4" className="w-full p-2 border rounded-lg" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Urgent Multiplier (24h)</label>
                    <input type="number" step="0.1" defaultValue="1.5" className="w-full p-2 border rounded-lg" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Rush Multiplier (12h)</label>
                    <input type="number" step="0.1" defaultValue="2.0" className="w-full p-2 border rounded-lg" />
                  </div>
                </div>
                <Button className="bg-success hover:bg-success/90">
                  <Save className="h-4 w-4 mr-2" />
                  Update Pricing
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Website Settings */}
          <TabsContent value="website" className="space-y-6">
            <h2 className="text-xl font-semibold">Website Settings</h2>

            <Card>
              <CardHeader>
                <CardTitle>Site Configuration</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Site Title</label>
                  <input
                    type="text"
                    defaultValue="WriteHunters - Professional Academic Writing Services"
                    className="w-full p-2 border rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Site Description</label>
                  <textarea
                    defaultValue="Get expert academic writing help from WriteHunters. Professional essay writing, research papers, editing & proofreading services."
                    rows={3}
                    className="w-full p-2 border rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Keywords</label>
                  <textarea
                    defaultValue="academic writing, essay writing service, research papers, editing, proofreading, WriteHunters"
                    rows={2}
                    className="w-full p-2 border rounded-lg"
                  />
                </div>
                <Button className="bg-success hover:bg-success/90">
                  <Save className="h-4 w-4 mr-2" />
                  Save Website Settings
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AdminLayout>
  )
}
