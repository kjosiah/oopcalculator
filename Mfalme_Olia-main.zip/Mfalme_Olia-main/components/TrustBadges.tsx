"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Shield, Award, Clock, Users, CheckCircle, Lock } from "lucide-react"

export default function TrustBadges() {
  const badges = [
    {
      icon: <Shield className="h-6 w-6 text-success" />,
      title: "100% Secure",
      subtitle: "SSL Encrypted",
      color: "from-success/10 to-success/5 border-success/20",
    },
    {
      icon: <Award className="h-6 w-6 text-coral" />,
      title: "Top Rated",
      subtitle: "4.9/5 Stars",
      color: "from-coral/10 to-coral/5 border-coral/20",
    },
    {
      icon: <Clock className="h-6 w-6 text-purple" />,
      title: "On-Time",
      subtitle: "98% Delivery",
      color: "from-purple/10 to-purple/5 border-purple/20",
    },
    {
      icon: <Users className="h-6 w-6 text-blue-600" />,
      title: "5000+ Students",
      subtitle: "Trust Us",
      color: "from-blue-100/50 to-blue-50/50 border-blue-200",
    },
    {
      icon: <CheckCircle className="h-6 w-6 text-success" />,
      title: "Plagiarism Free",
      subtitle: "Guaranteed",
      color: "from-success/10 to-success/5 border-success/20",
    },
    {
      icon: <Lock className="h-6 w-6 text-slate-600" />,
      title: "Confidential",
      subtitle: "100% Private",
      color: "from-slate-100/50 to-slate-50/50 border-slate-200",
    },
  ]

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      {badges.map((badge, index) => (
        <Card key={index} className={`card-elevated hover-lift bg-gradient-to-br ${badge.color}`}>
          <CardContent className="p-4 text-center">
            <div className="flex justify-center mb-3">{badge.icon}</div>
            <h4 className="font-semibold text-sm text-foreground mb-1">{badge.title}</h4>
            <p className="text-xs text-muted-foreground">{badge.subtitle}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
