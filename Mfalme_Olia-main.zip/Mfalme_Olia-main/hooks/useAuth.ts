"use client"

import { useState, useEffect } from "react"

interface User {
  email: string
  name: string
  phone?: string
  loginTime?: string
  registrationTime?: string
}

export function useAuth() {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const checkAuth = () => {
      try {
        const userSession = localStorage.getItem("userSession")
        if (userSession) {
          const userData = JSON.parse(userSession)
          setUser(userData)
        }
      } catch (error) {
        console.error("Error parsing user session:", error)
      } finally {
        setIsLoading(false)
      }
    }

    checkAuth()
  }, [])

  const login = (userData: User) => {
    localStorage.setItem("userSession", JSON.stringify(userData))
    setUser(userData)
  }

  const logout = () => {
    localStorage.removeItem("userSession")
    setUser(null)
  }

  const updateUser = (updatedData: Partial<User>) => {
    if (user) {
      const newUserData = { ...user, ...updatedData }
      localStorage.setItem("userSession", JSON.stringify(newUserData))
      setUser(newUserData)
    }
  }

  return {
    user,
    isLoading,
    isAuthenticated: !!user,
    login,
    logout,
    updateUser,
  }
}
