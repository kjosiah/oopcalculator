"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import {
  BookOpen,
  CheckCircle,
  Clock,
  Shield,
  Star,
  Users,
  Award,
  FileText,
  Calculator,
  MessageCircle,
  ArrowRight,
  Zap,
} from "lucide-react"
import Link from "next/link"

export default function WriteMyPaperClientPage() {
  const [pages, setPages] = useState(1)
  const [deadline, setDeadline] = useState("")
  const [academicLevel, setAcademicLevel] = useState("")
  const [paperType, setPaperType] = useState("")
  const [showOrderForm, setShowOrderForm] = useState(false)

  const pricePerPage = 4
  const totalPrice = pages * pricePerPage

  const getUrgencyMultiplier = (deadline: string) => {
    const hours = Number.parseInt(deadline)
    if (hours <= 6) return 2.0
    if (hours <= 12) return 1.8
    if (hours <= 24) return 1.5
    if (hours <= 48) return 1.3
    if (hours <= 72) return 1.2
    return 1.0
  }

  const urgencyMultiplier = deadline ? getUrgencyMultiplier(deadline) : 1.0
  const finalPrice = Math.round(totalPrice * urgencyMultiplier)

  const handleOrderSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const orderNumber = `WH${Date.now().toString().slice(-6)}${Math.floor(Math.random() * 1000)
      .toString()
      .padStart(3, "0")}`
    const orderData = {
      orderNumber,
      pages,
      deadline,
      academicLevel,
      serviceType: paperType,
      totalPrice: finalPrice,
      timestamp: new Date().toISOString(),
      status: "pending",
    }
    localStorage.setItem("orderData", JSON.stringify(orderData))
    localStorage.setItem("currentOrderNumber", orderNumber)
    window.location.href = "/payment"
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <BookOpen className="h-8 w-8 text-primary" />
              <span className="font-serif text-2xl font-bold text-primary">WriteHunters</span>
            </Link>
            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-foreground hover:text-primary transition-colors">
                Home
              </Link>
              <Link href="/services" className="text-foreground hover:text-primary transition-colors">
                Services
              </Link>
              <Link href="/about" className="text-foreground hover:text-primary transition-colors">
                About
              </Link>
              <Link href="/blog" className="text-foreground hover:text-primary transition-colors">
                Blog
              </Link>
              <Link href="/contact" className="text-foreground hover:text-primary transition-colors">
                Contact
              </Link>
            </nav>
            <Button onClick={() => setShowOrderForm(true)} className="bg-coral hover:bg-coral/90">
              Write My Paper Now
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-coral/5 via-purple/5 to-primary/5">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <div className="flex justify-center space-x-4 mb-6">
              <Badge className="bg-coral/10 text-coral border-coral/20">Professional Writing</Badge>
              <Badge className="bg-success/10 text-success border-success/20">100% Human Written</Badge>
              <Badge className="bg-purple/10 text-purple border-purple/20">24/7 Support</Badge>
            </div>
            <h1 className="font-serif text-5xl md:text-6xl font-bold text-foreground mb-6">
              Write My Paper with <span className="text-coral">Expert Writers</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
              Get your academic paper written by professional writers with advanced degrees. 100% original,
              human-written content delivered on time, every time.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Button
                size="lg"
                onClick={() => setShowOrderForm(true)}
                className="bg-coral hover:bg-coral/90 text-lg px-8 py-4"
              >
                <FileText className="h-5 w-5 mr-2" />
                Write My Paper Now
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="text-lg px-8 py-4 bg-transparent border-purple text-purple hover:bg-purple hover:text-white"
                asChild
              >
                <Link href="#how-it-works">
                  <Clock className="h-5 w-5 mr-2" />
                  How It Works
                </Link>
              </Button>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-2xl mx-auto">
              <div className="text-center">
                <div className="text-3xl font-bold text-coral">5000+</div>
                <div className="text-sm text-muted-foreground">Papers Written</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple">98%</div>
                <div className="text-sm text-muted-foreground">Success Rate</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-success">4.9/5</div>
                <div className="text-sm text-muted-foreground">Client Rating</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-warning">24/7</div>
                <div className="text-sm text-muted-foreground">Support</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Order Form */}
      {showOrderForm && (
        <section className="py-12 bg-white border-t-4 border-coral">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <div className="text-center mb-8">
                <h2 className="font-serif text-3xl font-bold text-foreground mb-4">Get Your Paper Written Now</h2>
                <p className="text-muted-foreground">Fill out the form below and get an instant quote</p>
              </div>

              <Card className="border-2 border-coral/20">
                <CardContent className="p-8">
                  <form onSubmit={handleOrderSubmit} className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <Label htmlFor="paperType">Type of Paper *</Label>
                        <Select value={paperType} onValueChange={setPaperType} required>
                          <SelectTrigger>
                            <SelectValue placeholder="Select paper type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="essay">Essay</SelectItem>
                            <SelectItem value="research-paper">Research Paper</SelectItem>
                            <SelectItem value="term-paper">Term Paper</SelectItem>
                            <SelectItem value="dissertation">Dissertation</SelectItem>
                            <SelectItem value="thesis">Thesis</SelectItem>
                            <SelectItem value="case-study">Case Study</SelectItem>
                            <SelectItem value="coursework">Coursework</SelectItem>
                            <SelectItem value="assignment">Assignment</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label htmlFor="academicLevel">Academic Level *</Label>
                        <Select value={academicLevel} onValueChange={setAcademicLevel} required>
                          <SelectTrigger>
                            <SelectValue placeholder="Select academic level" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="high-school">High School</SelectItem>
                            <SelectItem value="undergraduate">Undergraduate</SelectItem>
                            <SelectItem value="masters">Master's</SelectItem>
                            <SelectItem value="phd">PhD</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <Label htmlFor="pages">Number of Pages *</Label>
                        <div className="flex items-center space-x-2">
                          <Input
                            type="number"
                            min="1"
                            max="500"
                            value={pages}
                            onChange={(e) => setPages(Number.parseInt(e.target.value) || 1)}
                            required
                          />
                          <span className="text-sm text-muted-foreground">pages</span>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">1 page = 275 words</p>
                      </div>

                      <div>
                        <Label htmlFor="deadline">Deadline *</Label>
                        <Select value={deadline} onValueChange={setDeadline} required>
                          <SelectTrigger>
                            <SelectValue placeholder="Select deadline" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="6">6 hours (+100%)</SelectItem>
                            <SelectItem value="12">12 hours (+80%)</SelectItem>
                            <SelectItem value="24">24 hours (+50%)</SelectItem>
                            <SelectItem value="48">2 days (+30%)</SelectItem>
                            <SelectItem value="72">3 days (+20%)</SelectItem>
                            <SelectItem value="168">1 week (Standard)</SelectItem>
                            <SelectItem value="336">2 weeks (Standard)</SelectItem>
                            <SelectItem value="720">1 month (Standard)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="topic">Paper Topic *</Label>
                      <Input placeholder="Enter your paper topic" required />
                    </div>

                    <div>
                      <Label htmlFor="instructions">Paper Instructions *</Label>
                      <Textarea
                        placeholder="Provide detailed instructions for your paper including requirements, format, sources, etc."
                        rows={4}
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="email">Your Email *</Label>
                      <Input type="email" placeholder="Enter your email address" required />
                    </div>

                    <div className="flex items-center justify-between p-4 bg-coral/5 rounded-lg">
                      <div>
                        <div className="font-semibold">Total Price:</div>
                        <div className="text-sm text-muted-foreground">
                          {pages} pages × ${pricePerPage} {urgencyMultiplier > 1 && `× ${urgencyMultiplier} (urgency)`}
                        </div>
                      </div>
                      <div className="text-3xl font-bold text-coral">${finalPrice}</div>
                    </div>

                    <Button type="submit" className="w-full bg-coral hover:bg-coral/90 text-lg py-4">
                      <ArrowRight className="h-5 w-5 mr-2" />
                      Proceed to Payment - ${finalPrice}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      )}

      {/* How It Works */}
      <section id="how-it-works" className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl font-bold text-foreground mb-4">How We Write Your Paper</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Our streamlined process ensures you get high-quality, original papers delivered on time
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-coral/10 rounded-full flex items-center justify-center mx-auto mb-6 relative">
                <FileText className="h-8 w-8 text-coral" />
                <div className="absolute -top-2 -right-2 w-8 h-8 bg-coral text-white rounded-full flex items-center justify-center text-sm font-bold">
                  1
                </div>
              </div>
              <h3 className="font-serif text-xl font-bold mb-4">Place Your Order</h3>
              <p className="text-muted-foreground">
                Fill out our simple form with your paper requirements, deadline, and academic level.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-purple/10 rounded-full flex items-center justify-center mx-auto mb-6 relative">
                <Users className="h-8 w-8 text-purple" />
                <div className="absolute -top-2 -right-2 w-8 h-8 bg-purple text-white rounded-full flex items-center justify-center text-sm font-bold">
                  2
                </div>
              </div>
              <h3 className="font-serif text-xl font-bold mb-4">Writer Assignment</h3>
              <p className="text-muted-foreground">
                We assign your paper to a qualified writer with expertise in your subject area.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-6 relative">
                <Award className="h-8 w-8 text-success" />
                <div className="absolute -top-2 -right-2 w-8 h-8 bg-success text-white rounded-full flex items-center justify-center text-sm font-bold">
                  3
                </div>
              </div>
              <h3 className="font-serif text-xl font-bold mb-4">Writing Process</h3>
              <p className="text-muted-foreground">
                Your writer conducts research and crafts your paper following all academic standards.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-warning/10 rounded-full flex items-center justify-center mx-auto mb-6 relative">
                <CheckCircle className="h-8 w-8 text-warning" />
                <div className="absolute -top-2 -right-2 w-8 h-8 bg-warning text-white rounded-full flex items-center justify-center text-sm font-bold">
                  4
                </div>
              </div>
              <h3 className="font-serif text-xl font-bold mb-4">Quality Check & Delivery</h3>
              <p className="text-muted-foreground">
                We review, edit, and deliver your completed paper before the deadline.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Paper Types */}
      <section className="py-20 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl font-bold text-foreground mb-4">Types of Papers We Write</h2>
            <p className="text-xl text-muted-foreground">
              Our expert writers handle all types of academic papers across all subjects
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                name: "Essays",
                description: "Argumentative, persuasive, descriptive, and narrative essays",
                icon: BookOpen,
                color: "coral",
              },
              {
                name: "Research Papers",
                description: "In-depth research with proper citations and analysis",
                icon: Award,
                color: "purple",
              },
              {
                name: "Term Papers",
                description: "Comprehensive papers covering entire course topics",
                icon: FileText,
                color: "success",
              },
              {
                name: "Dissertations",
                description: "PhD-level research projects with original findings",
                icon: Star,
                color: "warning",
              },
              {
                name: "Case Studies",
                description: "Detailed analysis of specific scenarios or situations",
                icon: Users,
                color: "coral",
              },
              {
                name: "Thesis Papers",
                description: "Master's level research with thorough methodology",
                icon: Shield,
                color: "purple",
              },
            ].map((paperType, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6 text-center">
                  <div
                    className={`w-12 h-12 bg-${paperType.color}/10 rounded-full flex items-center justify-center mx-auto mb-4`}
                  >
                    <paperType.icon className={`h-6 w-6 text-${paperType.color}`} />
                  </div>
                  <h3 className="font-serif text-xl font-bold mb-3">{paperType.name}</h3>
                  <p className="text-muted-foreground text-sm">{paperType.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Guarantees */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl font-bold text-foreground mb-4">Our Writing Guarantees</h2>
            <p className="text-xl text-muted-foreground">
              We stand behind every paper we write with these ironclad guarantees
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="h-8 w-8 text-success" />
              </div>
              <h3 className="font-serif text-xl font-bold mb-4">100% Human Written</h3>
              <p className="text-muted-foreground">
                Every paper is written by human experts, never AI-generated content.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-coral/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Shield className="h-8 w-8 text-coral" />
              </div>
              <h3 className="font-serif text-xl font-bold mb-4">100% Original</h3>
              <p className="text-muted-foreground">
                All papers are written from scratch with free plagiarism reports included.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-purple/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Clock className="h-8 w-8 text-purple" />
              </div>
              <h3 className="font-serif text-xl font-bold mb-4">On-Time Delivery</h3>
              <p className="text-muted-foreground">Your paper will be delivered before your deadline, guaranteed.</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-warning/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Star className="h-8 w-8 text-warning" />
              </div>
              <h3 className="font-serif text-xl font-bold mb-4">Free Revisions</h3>
              <p className="text-muted-foreground">Unlimited free revisions within 14 days of delivery.</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Users className="h-8 w-8 text-success" />
              </div>
              <h3 className="font-serif text-xl font-bold mb-4">Expert Writers</h3>
              <p className="text-muted-foreground">
                PhD and Master's degree holders with proven academic writing experience.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-coral/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <MessageCircle className="h-8 w-8 text-coral" />
              </div>
              <h3 className="font-serif text-xl font-bold mb-4">24/7 Support</h3>
              <p className="text-muted-foreground">
                Round-the-clock customer support via WhatsApp, email, and live chat.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-20 bg-gradient-to-r from-coral/5 to-purple/5">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl font-bold text-foreground mb-4">Transparent Pricing</h2>
            <p className="text-xl text-muted-foreground">
              No hidden fees. Pay only for what you need with our competitive rates.
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <Card className="border-2 border-coral/20">
              <CardContent className="p-8">
                <div className="text-center mb-8">
                  <div className="text-5xl font-bold text-coral mb-2">$4</div>
                  <div className="text-xl text-muted-foreground">per page</div>
                  <div className="text-sm text-muted-foreground">Starting price for standard deadline</div>
                </div>

                <div className="grid md:grid-cols-2 gap-8">
                  <div>
                    <h4 className="font-semibold mb-4">What's Included:</h4>
                    <div className="space-y-3">
                      <div className="flex items-center">
                        <CheckCircle className="h-5 w-5 text-success mr-3" />
                        <span>100% original, human-written content</span>
                      </div>
                      <div className="flex items-center">
                        <CheckCircle className="h-5 w-5 text-success mr-3" />
                        <span>Free plagiarism report</span>
                      </div>
                      <div className="flex items-center">
                        <CheckCircle className="h-5 w-5 text-success mr-3" />
                        <span>Proper citations and formatting</span>
                      </div>
                      <div className="flex items-center">
                        <CheckCircle className="h-5 w-5 text-success mr-3" />
                        <span>Free title page and bibliography</span>
                      </div>
                      <div className="flex items-center">
                        <CheckCircle className="h-5 w-5 text-success mr-3" />
                        <span>Unlimited free revisions (14 days)</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-4">Urgency Pricing:</h4>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span>1 week+</span>
                        <span className="font-semibold">$4/page</span>
                      </div>
                      <div className="flex justify-between">
                        <span>3 days</span>
                        <span className="font-semibold">$4.8/page (+20%)</span>
                      </div>
                      <div className="flex justify-between">
                        <span>2 days</span>
                        <span className="font-semibold">$5.2/page (+30%)</span>
                      </div>
                      <div className="flex justify-between">
                        <span>24 hours</span>
                        <span className="font-semibold">$6/page (+50%)</span>
                      </div>
                      <div className="flex justify-between">
                        <span>12 hours</span>
                        <span className="font-semibold">$7.2/page (+80%)</span>
                      </div>
                      <div className="flex justify-between">
                        <span>6 hours</span>
                        <span className="font-semibold">$8/page (+100%)</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="text-center mt-8">
                  <Button
                    size="lg"
                    onClick={() => setShowOrderForm(true)}
                    className="bg-coral hover:bg-coral/90 text-lg px-8 py-4"
                  >
                    <Calculator className="h-5 w-5 mr-2" />
                    Calculate My Price
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-coral to-purple">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center text-white">
            <h2 className="font-serif text-4xl font-bold mb-6">Ready to Get Your Paper Written?</h2>
            <p className="text-xl mb-8 opacity-90">
              Join thousands of satisfied students who trust WriteHunters with their academic success.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                onClick={() => setShowOrderForm(true)}
                className="bg-white text-coral hover:bg-gray-100 text-lg px-8 py-4"
              >
                <Zap className="h-5 w-5 mr-2" />
                Write My Paper Now
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="text-lg px-8 py-4 border-white text-white hover:bg-white hover:text-coral bg-transparent"
                asChild
              >
                <Link href="/contact">
                  <MessageCircle className="h-5 w-5 mr-2" />
                  Chat with Us
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
