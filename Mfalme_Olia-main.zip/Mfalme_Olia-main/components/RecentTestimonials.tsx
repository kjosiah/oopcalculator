"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, Quote, User } from "lucide-react"

interface Testimonial {
  id: string
  name: string
  service: string
  rating: number
  comment: string
  timeAgo: string
  verified: boolean
}

export default function RecentTestimonials() {
  const [testimonials, setTestimonials] = useState<Testimonial[]>([
    {
      id: "1",
      name: "Sarah M.",
      service: "Research Paper",
      rating: 5,
      comment: "Excellent work! The research was thorough and the writing was perfect.",
      timeAgo: "2 hours ago",
      verified: true,
    },
    {
      id: "2",
      name: "James K.",
      service: "Essay Writing",
      rating: 5,
      comment: "Amazing quality and delivered on time. Highly recommend!",
      timeAgo: "5 hours ago",
      verified: true,
    },
    {
      id: "3",
      name: "Maria L.",
      service: "Class Management",
      rating: 5,
      comment: "They handled my entire course perfectly. Great communication throughout.",
      timeAgo: "1 day ago",
      verified: true,
    },
  ])

  const [currentIndex, setCurrentIndex] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length)
    }, 5000) // Rotate every 5 seconds

    return () => clearInterval(interval)
  }, [testimonials.length])

  const currentTestimonial = testimonials[currentIndex]

  return (
    <Card className="card-elevated overflow-hidden">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-foreground">Recent Reviews</h3>
          <Badge className="bg-success/10 text-success border-success/20">
            <Star className="h-3 w-3 mr-1" />
            4.9/5
          </Badge>
        </div>

        <div className="relative">
          <Quote className="h-8 w-8 text-purple/20 absolute -top-2 -left-2" />
          <div className="pl-6">
            <p className="text-muted-foreground mb-4 italic">"{currentTestimonial.comment}"</p>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-coral rounded-full flex items-center justify-center">
                  <User className="h-5 w-5 text-white" />
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="font-semibold text-foreground">{currentTestimonial.name}</span>
                    {currentTestimonial.verified && (
                      <Badge className="bg-success/10 text-success border-success/20 text-xs">Verified</Badge>
                    )}
                  </div>
                  <div className="text-sm text-muted-foreground">{currentTestimonial.service}</div>
                </div>
              </div>

              <div className="text-right">
                <div className="flex items-center space-x-1 mb-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${
                        i < currentTestimonial.rating ? "text-warning fill-current" : "text-gray-300"
                      }`}
                    />
                  ))}
                </div>
                <div className="text-xs text-muted-foreground">{currentTestimonial.timeAgo}</div>
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-center space-x-2 mt-4">
          {testimonials.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className={`w-2 h-2 rounded-full transition-colors ${
                index === currentIndex ? "bg-coral" : "bg-gray-300"
              }`}
            />
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
