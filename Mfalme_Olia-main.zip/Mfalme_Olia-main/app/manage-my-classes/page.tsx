import ManageMyClassesClientPage from "./ManageMyClassesClientPage"

export const metadata = {
  title: "Manage My Classes - Complete Academic Class Management Service | WriteHunters",
  description:
    "Professional class management service. CATs $10, Exams $25, Full management $50/week or $600/month. WhatsApp, email & phone support available 24/7.",
  keywords:
    "class management service, academic support, CAT assistance, exam help, course management, WriteHunters classes",
  openGraph: {
    title: "Manage My Classes - Academic Class Management Service",
    description:
      "Complete class management service with CATs, exams, and full course support. Starting at $10 per CAT.",
    type: "website",
    url: "https://writehunters.com/manage-my-classes",
  },
}

export default function ManageMyClassesPage() {
  return <ManageMyClassesClientPage />
}
