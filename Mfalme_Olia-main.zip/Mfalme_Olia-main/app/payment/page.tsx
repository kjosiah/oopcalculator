"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BookOpen, CreditCard, Building2, CheckCircle, Copy, Mail, MessageCircle } from "lucide-react"
import Link from "next/link"

export default function PaymentPage() {
  const [orderData, setOrderData] = useState<any>(null)
  const [paymentMethod, setPaymentMethod] = useState("")

  useEffect(() => {
    const data = localStorage.getItem("orderData")
    if (data) {
      setOrderData(JSON.parse(data))
    }
  }, [])

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  if (!orderData) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">No Order Found</h1>
          <Link href="/order">
            <Button>Place New Order</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <BookOpen className="h-8 w-8 text-primary" />
              <span className="font-serif text-2xl font-bold text-primary">WriteHunters</span>
            </Link>
            <Badge className="bg-green-100 text-green-800">Order Confirmed</Badge>
          </div>
        </div>
      </header>

      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
              <h1 className="font-serif text-3xl font-bold text-foreground mb-2">Order Confirmed!</h1>
              <p className="text-muted-foreground">Please complete your payment to start working on your order</p>
            </div>

            <div className="grid lg:grid-cols-2 gap-8">
              {/* Order Summary */}
              <Card>
                <CardHeader>
                  <CardTitle>Order Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span>Service Type:</span>
                      <span className="capitalize">{orderData.serviceType}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Academic Level:</span>
                      <span className="capitalize">{orderData.academicLevel}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Number of Pages:</span>
                      <span>{orderData.pages}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Deadline:</span>
                      <span>{orderData.deadline} hours</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Attached Files:</span>
                      <span>{orderData.files} files</span>
                    </div>
                    <div className="border-t pt-4">
                      <div className="flex justify-between text-lg font-bold">
                        <span>Total Amount:</span>
                        <span className="text-primary">${orderData.totalPrice}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Payment Methods */}
              <Card>
                <CardHeader>
                  <CardTitle>Choose Payment Method</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {/* PayPal Option */}
                    <div
                      className={`border-2 rounded-lg p-4 cursor-pointer transition-colors ${
                        paymentMethod === "paypal"
                          ? "border-primary bg-primary/5"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                      onClick={() => setPaymentMethod("paypal")}
                    >
                      <div className="flex items-center space-x-3">
                        <CreditCard className="h-6 w-6 text-blue-600" />
                        <div>
                          <div className="font-medium">PayPal</div>
                          <div className="text-sm text-muted-foreground">Pay securely with PayPal</div>
                        </div>
                      </div>
                      {paymentMethod === "paypal" && (
                        <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                          <p className="text-sm mb-3">Send payment to our PayPal account:</p>
                          <div className="flex items-center justify-between bg-white p-3 rounded border">
                            <span className="font-mono">pjay82577@gmail.com</span>
                            <Button size="sm" variant="outline" onClick={() => copyToClipboard("pjay82577@gmail.com")}>
                              <Copy className="h-4 w-4" />
                            </Button>
                          </div>
                          <p className="text-xs text-muted-foreground mt-2">
                            Include your order reference in the payment note
                          </p>
                        </div>
                      )}
                    </div>

                    {/* Bank Transfer Option */}
                    <div
                      className={`border-2 rounded-lg p-4 cursor-pointer transition-colors ${
                        paymentMethod === "bank"
                          ? "border-primary bg-primary/5"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                      onClick={() => setPaymentMethod("bank")}
                    >
                      <div className="flex items-center space-x-3">
                        <Building2 className="h-6 w-6 text-green-600" />
                        <div>
                          <div className="font-medium">Bank Transfer</div>
                          <div className="text-sm text-muted-foreground">Direct bank transfer</div>
                        </div>
                      </div>
                      {paymentMethod === "bank" && (
                        <div className="mt-4 p-4 bg-green-50 rounded-lg">
                          <p className="text-sm mb-3">Bank Transfer Details:</p>
                          <div className="space-y-2">
                            <div className="flex items-center justify-between bg-white p-2 rounded border">
                              <span className="text-sm">Bank Name:</span>
                              <span className="font-mono text-sm">Equity Bank Kenya</span>
                            </div>
                            <div className="flex items-center justify-between bg-white p-2 rounded border">
                              <span className="text-sm">Account Name:</span>
                              <span className="font-mono text-sm">Josiah Olia</span>
                            </div>
                            <div className="flex items-center justify-between bg-white p-2 rounded border">
                              <span className="text-sm">Account Number:</span>
                              <div className="flex items-center space-x-2">
                                <span className="font-mono text-sm">7770178461745</span>
                                <Button size="sm" variant="outline" onClick={() => copyToClipboard("7770178461745")}>
                                  <Copy className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                            <div className="flex items-center justify-between bg-white p-2 rounded border">
                              <span className="text-sm">Swift Code:</span>
                              <span className="font-mono text-sm">EQBLKENA</span>
                            </div>
                          </div>
                          <p className="text-xs text-muted-foreground mt-2">
                            Please include your order reference in the transfer description
                          </p>
                        </div>
                      )}
                    </div>
                  </div>

                  {paymentMethod && (
                    <div className="mt-6 p-4 bg-coral/10 border border-coral/20 rounded-lg">
                      <h4 className="font-medium text-coral mb-2">Next Steps:</h4>
                      <ol className="text-sm text-coral/80 space-y-1">
                        <li>1. Complete your payment using the details above</li>
                        <li>2. Take a screenshot of your payment confirmation</li>
                        <li>
                          3.{" "}
                          <a href="/messages" className="underline font-medium">
                            Send the screenshot via our inbox
                          </a>{" "}
                          with your order reference
                        </li>
                        <li>4. We'll assign your order number and start working immediately</li>
                        <li>5. You'll receive regular updates on your order progress</li>
                      </ol>
                      <div className="mt-4 p-3 bg-white rounded border">
                        <p className="text-sm font-medium text-coral">Your Order Reference: {orderData.orderNumber}</p>
                        <p className="text-xs text-muted-foreground">
                          Include this in your message when sending payment confirmation
                        </p>
                      </div>
                    </div>
                  )}

                  <div className="mt-6 pt-6 border-t">
                    <h4 className="font-medium mb-3">Send Payment Confirmation</h4>
                    <div className="space-y-2">
                      <a
                        href="/messages"
                        className="flex items-center space-x-3 p-3 bg-coral/10 rounded-lg hover:bg-coral/20 transition-colors"
                      >
                        <MessageCircle className="h-5 w-5 text-coral" />
                        <div>
                          <div className="font-medium text-coral">Send via Inbox</div>
                          <div className="text-sm text-coral/70">Upload payment screenshot</div>
                        </div>
                      </a>
                      <div className="flex items-center space-x-3">
                        <MessageCircle className="h-4 w-4 text-green-600" />
                        <span className="text-sm">WhatsApp: +254 748 881893</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Mail className="h-4 w-4 text-blue-600" />
                        <span className="text-sm">Email: writehunters@gmail.com</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
