"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { BookOpen, LogOut, Home, Settings, FileText, BarChart3 } from "lucide-react"
import Link from "next/link"
import { isAdminAuthenticated, adminLogout, getAdminUser } from "@/lib/admin-auth"

interface AdminLayoutProps {
  children: React.ReactNode
  title?: string
}

export default function AdminLayout({ children, title = "Admin Dashboard" }: AdminLayoutProps) {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [adminUser, setAdminUser] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    const checkAuth = () => {
      const auth = isAdminAuthenticated()
      const user = getAdminUser()

      if (!auth) {
        router.push("/admin/login")
        return
      }

      setIsAuthenticated(auth)
      setAdminUser(user)
    }

    checkAuth()
  }, [router])

  const handleLogout = () => {
    adminLogout()
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Checking authentication...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Admin Header */}
      <header className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/" className="flex items-center space-x-2">
                <BookOpen className="h-6 w-6 text-primary" />
                <span className="font-serif text-xl font-bold text-primary">WriteHunters</span>
              </Link>
              <div className="h-6 w-px bg-gray-300"></div>
              <h1 className="font-semibold text-foreground">{title}</h1>
            </div>

            <div className="flex items-center space-x-4">
              <span className="text-sm text-muted-foreground">Welcome, {adminUser}</span>
              <Button variant="outline" size="sm" onClick={handleLogout}>
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white border-r min-h-[calc(100vh-73px)]">
          <nav className="p-4">
            <ul className="space-y-2">
              <li>
                <Link
                  href="/admin/dashboard"
                  className="flex items-center space-x-3 px-3 py-2 rounded-lg text-foreground hover:bg-slate-100 transition-colors"
                >
                  <BarChart3 className="h-5 w-5" />
                  <span>Dashboard</span>
                </Link>
              </li>
              <li>
                <Link
                  href="/admin/orders"
                  className="flex items-center space-x-3 px-3 py-2 rounded-lg text-foreground hover:bg-slate-100 transition-colors"
                >
                  <FileText className="h-5 w-5" />
                  <span>Orders</span>
                </Link>
              </li>
              <li>
                <Link
                  href="/admin/content"
                  className="flex items-center space-x-3 px-3 py-2 rounded-lg text-foreground hover:bg-slate-100 transition-colors"
                >
                  <Settings className="h-5 w-5" />
                  <span>Content Management</span>
                </Link>
              </li>
              <li>
                <Link
                  href="/"
                  target="_blank"
                  className="flex items-center space-x-3 px-3 py-2 rounded-lg text-muted-foreground hover:bg-slate-100 transition-colors"
                >
                  <Home className="h-5 w-5" />
                  <span>View Website</span>
                </Link>
              </li>
            </ul>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6">{children}</main>
      </div>
    </div>
  )
}
