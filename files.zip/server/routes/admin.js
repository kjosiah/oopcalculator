const express = require('express');
const db = require('../db');
const router = express.Router();

// Very light admin check: either a JWT user with role admin or ADMIN_PASSWORD in header (for quick setup).
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'change_this_admin_password';

function isAdmin(req) {
  // Basic header check for quick admin access (CHANGE for production)
  const pw = req.headers['x-admin-password'];
  if (pw && pw === ADMIN_PASSWORD) return true;
  return false;
}

router.get('/orders', (req, res) => {
  if (!isAdmin(req)) return res.status(403).json({ error: 'Forbidden' });
  const rows = db.prepare('SELECT * FROM orders ORDER BY created_at DESC').all();
  res.json({ orders: rows });
});

router.post('/orders/:orderNumber/status', (req, res) => {
  if (!isAdmin(req)) return res.status(403).json({ error: 'Forbidden' });
  const { status } = req.body;
  const stmt = db.prepare('UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE order_number = ?');
  stmt.run(status, req.params.orderNumber);
  res.json({ ok: true });
});

// Assign writer to order
router.post('/orders/:orderNumber/assign', (req, res) => {
  if (!isAdmin(req)) return res.status(403).json({ error: 'Forbidden' });
  const { writer } = req.body;
  const stmt = db.prepare('UPDATE orders SET assigned_writer = ?, updated_at = CURRENT_TIMESTAMP WHERE order_number = ?');
  stmt.run(writer, req.params.orderNumber);
  res.json({ ok: true });
});

// List files for an order
router.get('/orders/:orderNumber/files', (req, res) => {
  if (!isAdmin(req)) return res.status(403).json({ error: 'Forbidden' });
  const row = db.prepare('SELECT id FROM orders WHERE order_number = ?').get(req.params.orderNumber);
  if (!row) return res.status(404).json({ error: 'Order not found' });
  const files = db.prepare('SELECT id, filename, original_name, mime_type, size, uploaded_at FROM order_files WHERE order_id = ?').all(row.id);
  res.json({ files });
});

module.exports = router;