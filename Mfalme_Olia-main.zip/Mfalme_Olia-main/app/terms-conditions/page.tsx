import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BookOpen, Scale, FileText, Shield, AlertTriangle, Users, CreditCard, RefreshCw } from "lucide-react"
import Link from "next/link"

export const metadata = {
  title: "Terms & Conditions - WriteHunters Academic Writing Services",
  description:
    "Read WriteHunters' terms and conditions for our academic writing services. Understand our policies, guarantees, and service agreements.",
  keywords: "WriteHunters terms conditions, academic writing terms, service agreement, writing service policies",
  openGraph: {
    title: "Terms & Conditions - WriteHunters",
    description: "Understand the terms and conditions for WriteHunters academic writing services.",
    type: "website",
    url: "https://writehunters.com/terms-conditions",
  },
}

export default function TermsConditionsPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <BookOpen className="h-8 w-8 text-primary" />
              <span className="font-serif text-2xl font-bold text-primary">WriteHunters</span>
            </Link>
            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-foreground hover:text-primary transition-colors">
                Home
              </Link>
              <Link href="/services" className="text-foreground hover:text-primary transition-colors">
                Services
              </Link>
              <Link href="/about" className="text-foreground hover:text-primary transition-colors">
                About
              </Link>
              <Link href="/contact" className="text-foreground hover:text-primary transition-colors">
                Contact
              </Link>
            </nav>
            <Button asChild className="bg-coral hover:bg-coral/90 text-coral-foreground">
              <Link href="/order">Place Your Order</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <Scale className="h-8 w-8 text-white" />
            </div>
            <h1 className="font-serif text-4xl md:text-5xl font-bold text-foreground mb-6">Terms & Conditions</h1>
            <p className="text-xl text-muted-foreground">
              Please read these terms and conditions carefully before using our academic writing services.
            </p>
            <p className="text-sm text-muted-foreground mt-4">Last updated: December 2024</p>
          </div>
        </div>
      </section>

      {/* Terms Content */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="space-y-12">
              {/* Agreement to Terms */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <FileText className="h-6 w-6 mr-3 text-primary" />
                    Agreement to Terms
                  </CardTitle>
                </CardHeader>
                <CardContent className="prose prose-lg max-w-none">
                  <p>
                    By accessing and using WriteHunters' website and services, you accept and agree to be bound by the
                    terms and provision of this agreement. If you do not agree to abide by the above, please do not use
                    this service.
                  </p>
                  <p>
                    These Terms and Conditions ("Terms") govern your use of our website located at writehunters.com (the
                    "Service") operated by WriteHunters ("us", "we", or "our").
                  </p>
                  <p>
                    Your access to and use of the Service is conditioned on your acceptance of and compliance with these
                    Terms. These Terms apply to all visitors, users, and others who access or use the Service.
                  </p>
                </CardContent>
              </Card>

              {/* Service Description */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BookOpen className="h-6 w-6 mr-3 text-coral" />
                    Service Description
                  </CardTitle>
                </CardHeader>
                <CardContent className="prose prose-lg max-w-none">
                  <p>WriteHunters provides academic writing and editing services including but not limited to:</p>
                  <ul>
                    <li>Custom essay writing</li>
                    <li>Research paper writing</li>
                    <li>Editing and proofreading services</li>
                    <li>Class management services</li>
                    <li>Academic consultation and tutoring</li>
                  </ul>
                  <p>
                    All work is performed by qualified writers with relevant academic backgrounds. We guarantee
                    original, plagiarism-free content tailored to your specific requirements.
                  </p>
                  <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                    <div className="flex items-start">
                      <AlertTriangle className="h-5 w-5 text-amber-600 mr-2 mt-0.5" />
                      <div>
                        <h4 className="font-semibold text-amber-800 mb-2">Academic Integrity Notice</h4>
                        <p className="text-amber-700 text-sm">
                          Our services are intended for research and reference purposes only. Students are responsible
                          for ensuring their use of our services complies with their institution's academic integrity
                          policies.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* User Responsibilities */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Users className="h-6 w-6 mr-3 text-success" />
                    User Responsibilities
                  </CardTitle>
                </CardHeader>
                <CardContent className="prose prose-lg max-w-none">
                  <p>By using our services, you agree to:</p>
                  <ul>
                    <li>Provide accurate and complete information when placing orders</li>
                    <li>Use our services in compliance with applicable laws and regulations</li>
                    <li>Respect intellectual property rights</li>
                    <li>Not use our services for any illegal or unauthorized purpose</li>
                    <li>Maintain the confidentiality of your account credentials</li>
                    <li>Use our work as a reference or research aid in accordance with academic integrity policies</li>
                  </ul>
                  <p>You are prohibited from:</p>
                  <ul>
                    <li>Reselling or redistributing our work without permission</li>
                    <li>Claiming our work as your own original creation</li>
                    <li>Using our services to violate academic integrity policies</li>
                    <li>Attempting to reverse engineer or copy our proprietary methods</li>
                    <li>Harassing or threatening our staff members</li>
                  </ul>
                </CardContent>
              </Card>

              {/* Payment Terms */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <CreditCard className="h-6 w-6 mr-3 text-warning" />
                    Payment Terms
                  </CardTitle>
                </CardHeader>
                <CardContent className="prose prose-lg max-w-none">
                  <h3>Pricing and Payment</h3>
                  <p>
                    Our pricing is based on various factors including academic level, deadline, and complexity of the
                    assignment. All prices are quoted in USD and are subject to change without notice.
                  </p>
                  <ul>
                    <li>Payment is required before work begins</li>
                    <li>We accept payments via PayPal, bank transfer, and other approved methods</li>
                    <li>All transactions are processed securely</li>
                    <li>Prices include all applicable taxes and fees</li>
                  </ul>

                  <h3>Payment Information</h3>
                  <div className="bg-slate-50 p-6 rounded-lg border">
                    <div className="space-y-2">
                      <div>
                        <strong>PayPal:</strong> pjay82577@gmail.com
                      </div>
                      <div>
                        <strong>Bank Account:</strong> 7770178461745
                      </div>
                      <div>
                        <strong>Account Name:</strong> Josiah Olia
                      </div>
                    </div>
                  </div>

                  <h3>Late Payment</h3>
                  <p>
                    Orders will not commence until full payment is received. Late payments may result in delays or
                    cancellation of your order.
                  </p>
                </CardContent>
              </Card>

              {/* Guarantees and Policies */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Shield className="h-6 w-6 mr-3 text-purple" />
                    Our Guarantees
                  </CardTitle>
                </CardHeader>
                <CardContent className="prose prose-lg max-w-none">
                  <h3>Quality Guarantee</h3>
                  <p>We guarantee that all work delivered will:</p>
                  <ul>
                    <li>Be 100% original and plagiarism-free</li>
                    <li>Meet your specified requirements and instructions</li>
                    <li>Be completed by qualified writers in the relevant field</li>
                    <li>Follow proper academic formatting and citation styles</li>
                  </ul>

                  <h3>On-Time Delivery</h3>
                  <p>
                    We guarantee timely delivery of all orders. If we fail to deliver your order by the agreed deadline,
                    you may be eligible for a partial refund or free revision.
                  </p>

                  <h3>Confidentiality</h3>
                  <p>
                    We guarantee complete confidentiality of your personal information and order details. Your privacy
                    is our priority, and we will never share your information with third parties.
                  </p>

                  <h3>Free Revisions</h3>
                  <p>
                    We offer unlimited free revisions within 14 days of delivery, provided the revision requests are
                    within the original order requirements.
                  </p>
                </CardContent>
              </Card>

              {/* Refund Policy */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <RefreshCw className="h-6 w-6 mr-3 text-accent" />
                    Refund Policy
                  </CardTitle>
                </CardHeader>
                <CardContent className="prose prose-lg max-w-none">
                  <p>We offer refunds under the following circumstances:</p>

                  <h3>Full Refund (100%)</h3>
                  <ul>
                    <li>Order not delivered by the agreed deadline</li>
                    <li>Work does not meet the specified requirements after multiple revision attempts</li>
                    <li>Duplicate payment or technical error</li>
                    <li>Order cancelled before work begins</li>
                  </ul>

                  <h3>Partial Refund (50-75%)</h3>
                  <ul>
                    <li>Late delivery (within 24 hours of deadline)</li>
                    <li>Minor deviations from requirements that cannot be resolved through revisions</li>
                    <li>Order cancelled after work has begun but before 50% completion</li>
                  </ul>

                  <h3>No Refund</h3>
                  <ul>
                    <li>Work delivered according to specifications and on time</li>
                    <li>Customer changes requirements after work completion</li>
                    <li>Order cancelled after 75% completion</li>
                    <li>Customer fails to respond to revision requests within 14 days</li>
                  </ul>

                  <p>
                    Refund requests must be submitted within 30 days of order completion. All refunds are processed
                    within 5-10 business days.
                  </p>
                </CardContent>
              </Card>

              {/* Intellectual Property */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <FileText className="h-6 w-6 mr-3 text-coral" />
                    Intellectual Property
                  </CardTitle>
                </CardHeader>
                <CardContent className="prose prose-lg max-w-none">
                  <h3>Ownership of Work</h3>
                  <p>
                    Upon full payment, you receive full ownership rights to the completed work. However, we retain the
                    right to use anonymized portions of the work for quality assurance and training purposes.
                  </p>

                  <h3>Website Content</h3>
                  <p>
                    The content, organization, graphics, design, and other matters related to our website are protected
                    under applicable copyrights and other proprietary laws. Copying, redistribution, or publication of
                    any such content is strictly prohibited.
                  </p>

                  <h3>Trademarks</h3>
                  <p>
                    WriteHunters and our logo are trademarks of our company. You may not use our trademarks without our
                    prior written consent.
                  </p>
                </CardContent>
              </Card>

              {/* Limitation of Liability */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <AlertTriangle className="h-6 w-6 mr-3 text-warning" />
                    Limitation of Liability
                  </CardTitle>
                </CardHeader>
                <CardContent className="prose prose-lg max-w-none">
                  <p>
                    WriteHunters shall not be liable for any indirect, incidental, special, consequential, or punitive
                    damages, including but not limited to:
                  </p>
                  <ul>
                    <li>Loss of profits or revenue</li>
                    <li>Loss of data or information</li>
                    <li>Academic consequences resulting from misuse of our services</li>
                    <li>Damages resulting from third-party actions</li>
                  </ul>
                  <p>
                    Our total liability for any claim arising from our services shall not exceed the amount paid for the
                    specific order in question.
                  </p>
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                    <div className="flex items-start">
                      <AlertTriangle className="h-5 w-5 text-red-600 mr-2 mt-0.5" />
                      <div>
                        <h4 className="font-semibold text-red-800 mb-2">Important Disclaimer</h4>
                        <p className="text-red-700 text-sm">
                          Students are solely responsible for how they use our services and must ensure compliance with
                          their institution's academic policies. We are not responsible for any academic consequences
                          resulting from the misuse of our services.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Privacy and Data Protection */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Shield className="h-6 w-6 mr-3 text-success" />
                    Privacy and Data Protection
                  </CardTitle>
                </CardHeader>
                <CardContent className="prose prose-lg max-w-none">
                  <p>
                    We are committed to protecting your privacy and personal information. Our data practices are
                    governed by our Privacy Policy, which forms part of these Terms and Conditions.
                  </p>
                  <ul>
                    <li>We collect only necessary information to provide our services</li>
                    <li>Your personal information is stored securely and never shared with third parties</li>
                    <li>You have the right to request deletion of your personal data</li>
                    <li>We use industry-standard security measures to protect your information</li>
                  </ul>
                  <p>
                    For detailed information about our data practices, please review our{" "}
                    <Link href="/privacy-policy" className="text-primary hover:underline">
                      Privacy Policy
                    </Link>
                    .
                  </p>
                </CardContent>
              </Card>

              {/* Termination */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <AlertTriangle className="h-6 w-6 mr-3 text-coral" />
                    Termination
                  </CardTitle>
                </CardHeader>
                <CardContent className="prose prose-lg max-w-none">
                  <p>
                    We reserve the right to terminate or suspend your access to our services immediately, without prior
                    notice, for any reason, including but not limited to:
                  </p>
                  <ul>
                    <li>Violation of these Terms and Conditions</li>
                    <li>Fraudulent or illegal activity</li>
                    <li>Abusive behavior toward our staff</li>
                    <li>Non-payment of fees</li>
                    <li>Misuse of our services</li>
                  </ul>
                  <p>
                    Upon termination, your right to use our services will cease immediately. All provisions of these
                    Terms which by their nature should survive termination shall survive.
                  </p>
                </CardContent>
              </Card>

              {/* Changes to Terms */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <RefreshCw className="h-6 w-6 mr-3 text-purple" />
                    Changes to Terms
                  </CardTitle>
                </CardHeader>
                <CardContent className="prose prose-lg max-w-none">
                  <p>
                    We reserve the right to modify or replace these Terms at any time. If a revision is material, we
                    will try to provide at least 30 days notice prior to any new terms taking effect.
                  </p>
                  <p>
                    What constitutes a material change will be determined at our sole discretion. By continuing to
                    access or use our Service after those revisions become effective, you agree to be bound by the
                    revised terms.
                  </p>
                  <p>
                    If you do not agree to the new terms, please stop using the Service. We encourage you to review
                    these Terms periodically for any changes.
                  </p>
                </CardContent>
              </Card>

              {/* Governing Law */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Scale className="h-6 w-6 mr-3 text-accent" />
                    Governing Law and Jurisdiction
                  </CardTitle>
                </CardHeader>
                <CardContent className="prose prose-lg max-w-none">
                  <p>
                    These Terms shall be interpreted and governed by the laws of Kenya, without regard to its conflict
                    of law provisions.
                  </p>
                  <p>
                    Any disputes arising from these Terms or your use of our services shall be resolved through binding
                    arbitration in accordance with the laws of Kenya.
                  </p>
                  <p>
                    If any provision of these Terms is held to be invalid or unenforceable, the remaining provisions
                    will remain in full force and effect.
                  </p>
                </CardContent>
              </Card>

              {/* Contact Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BookOpen className="h-6 w-6 mr-3 text-primary" />
                    Contact Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="prose prose-lg max-w-none">
                  <p>
                    If you have any questions about these Terms and Conditions, please contact us using the information
                    below:
                  </p>
                  <div className="bg-slate-50 p-6 rounded-lg border">
                    <div className="space-y-2">
                      <div>
                        <strong>Company:</strong> WriteHunters
                      </div>
                      <div>
                        <strong>Email:</strong> writehunters@gmail.com
                      </div>
                      <div>
                        <strong>WhatsApp:</strong> +254 748 881893
                      </div>
                      <div>
                        <strong>Address:</strong> Kenya
                      </div>
                    </div>
                  </div>
                  <p>
                    We will respond to your inquiry as soon as possible, typically within 48 hours during business days.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-slate-900 to-slate-800 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <BookOpen className="h-6 w-6 text-accent" />
                <span className="font-serif text-xl font-bold">WriteHunters</span>
              </div>
              <p className="text-slate-300">
                Professional academic writing services for students and academics worldwide.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4 text-coral">Services</h4>
              <ul className="space-y-2 text-slate-300">
                <li>
                  <Link href="/services">Essay Writing</Link>
                </li>
                <li>
                  <Link href="/services">Research Papers</Link>
                </li>
                <li>
                  <Link href="/services">Editing & Proofreading</Link>
                </li>
                <li>Class Management</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4 text-purple">Company</h4>
              <ul className="space-y-2 text-slate-300">
                <li>
                  <Link href="/about">About Us</Link>
                </li>
                <li>
                  <Link href="/contact">Contact</Link>
                </li>
                <li>
                  <Link href="/privacy-policy">Privacy Policy</Link>
                </li>
                <li>
                  <Link href="/cookie-policy">Cookie Policy</Link>
                </li>
                <li>
                  <Link href="/terms-conditions">Terms & Conditions</Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4 text-success">Contact</h4>
              <div className="space-y-2 text-slate-300">
                <div>WhatsApp: +254 748 881893</div>
                <div>Email: writehunters@gmail.com</div>
                <div>Bank Account: 7770178461745</div>
              </div>
            </div>
          </div>

          <div className="border-t border-slate-700 mt-8 pt-8 text-center text-slate-300">
            <p>&copy; 2024 WriteHunters. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
