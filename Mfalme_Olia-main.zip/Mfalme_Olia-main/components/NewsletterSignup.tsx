"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Mail, ArrowRight, BookOpen, Gift } from "lucide-react"

export default function NewsletterSignup() {
  const [email, setEmail] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubscribed, setIsSubscribed] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    console.log("Newsletter signup:", { email })

    setIsSubmitting(false)
    setIsSubscribed(true)
  }

  if (isSubscribed) {
    return (
      <Card className="bg-gradient-to-r from-success/10 to-success/5 border-success/20">
        <CardContent className="p-6 text-center">
          <div className="w-12 h-12 bg-success rounded-full flex items-center justify-center mx-auto mb-4">
            <Mail className="h-6 w-6 text-white" />
          </div>
          <h3 className="font-semibold text-success mb-2">Successfully Subscribed!</h3>
          <p className="text-sm text-muted-foreground">Check your email for your welcome gift.</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="bg-gradient-to-r from-purple/5 to-coral/5 border-purple/20 hover:border-purple/40 transition-all duration-300">
      <CardContent className="p-6">
        <div className="flex items-start space-x-4">
          <div className="w-12 h-12 bg-gradient-purple rounded-lg flex items-center justify-center flex-shrink-0">
            <BookOpen className="h-6 w-6 text-white" />
          </div>
          <div className="flex-1">
            <div className="flex items-center space-x-2 mb-2">
              <h3 className="font-semibold text-foreground">Get Free Writing Resources</h3>
              <Badge className="bg-coral text-white text-xs">
                <Gift className="h-3 w-3 mr-1" />
                Free
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              Join 5000+ students getting weekly writing tips, study guides, and exclusive discounts.
            </p>
            <form onSubmit={handleSubmit} className="flex space-x-2">
              <input
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="flex-1 px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple focus:border-transparent"
                required
              />
              <Button type="submit" size="sm" className="bg-purple hover:bg-purple/90" disabled={isSubmitting}>
                {isSubmitting ? "..." : <ArrowRight className="h-4 w-4" />}
              </Button>
            </form>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
