import WriteMyPaperClientPage from "./WriteMyPaperClientPage"

export const metadata = {
  title: "Write My Paper - Professional Academic Paper Writing Service | WriteHunters",
  description:
    "Get your academic paper written by expert writers. 100% human-written, original content. Essays, research papers, dissertations. Starting at $4/page with 24/7 support.",
  keywords:
    "write my paper, academic paper writing, essay writing service, research paper help, dissertation writing, WriteHunters",
  openGraph: {
    title: "Write My Paper - Professional Academic Writing Service",
    description: "Expert academic paper writing service. 100% human-written, original content starting at $4/page.",
    type: "website",
    url: "https://writehunters.com/write-my-paper",
  },
}

export default function WriteMyPaperPage() {
  return <WriteMyPaperClientPage />
}
