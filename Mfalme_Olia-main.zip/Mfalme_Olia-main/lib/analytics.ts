// Utility functions for tracking custom events
export const trackEvent = (eventName: string, parameters?: Record<string, any>) => {
  if (typeof window !== "undefined" && window.gtag) {
    window.gtag("event", eventName, {
      event_category: "WriteHunters",
      event_label: parameters?.label || "",
      value: parameters?.value || 0,
      ...parameters,
    })
  }
}

// Predefined tracking functions for WriteHunters
export const trackOrderPlaced = (orderValue: number, orderType: string) => {
  trackEvent("order_placed", {
    event_category: "Orders",
    event_label: orderType,
    value: orderValue,
  })
}

export const trackContactForm = (formType: string) => {
  trackEvent("contact_form_submit", {
    event_category: "Contact",
    event_label: formType,
  })
}

export const trackServiceView = (serviceName: string) => {
  trackEvent("service_viewed", {
    event_category: "Services",
    event_label: serviceName,
  })
}

// TypeScript declaration for gtag
declare global {
  interface Window {
    gtag: (command: string, targetId: string, config?: Record<string, any>) => void
  }
}
