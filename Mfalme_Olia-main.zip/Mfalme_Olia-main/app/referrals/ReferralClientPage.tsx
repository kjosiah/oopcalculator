"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Users,
  DollarSign,
  Share2,
  Copy,
  Gift,
  TrendingUp,
  CheckCircle,
  Star,
  ArrowRight,
  Facebook,
  Twitter,
  MessageCircle,
  Mail,
} from "lucide-react"

export default function ReferralClientPage() {
  const [referralCode, setReferralCode] = useState("")
  const [referralStats, setReferralStats] = useState({
    totalReferrals: 0,
    successfulReferrals: 0,
    totalEarnings: 0,
    pendingEarnings: 0,
  })
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    // Generate unique referral code (in real app, get from backend)
    const generateCode = () => {
      const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
      let result = "WH"
      for (let i = 0; i < 6; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length))
      }
      return result
    }

    setReferralCode(generateCode())

    // Load referral stats (mock data)
    setReferralStats({
      totalReferrals: 12,
      successfulReferrals: 8,
      totalEarnings: 240,
      pendingEarnings: 60,
    })
  }, [])

  const referralLink = `https://writehunters.com?ref=${referralCode}`

  const copyToClipboard = () => {
    navigator.clipboard.writeText(referralLink)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const shareOnSocial = (platform: string) => {
    const message =
      "Check out WriteHunters for professional academic writing services! Use my referral link to get started:"
    const url = encodeURIComponent(referralLink)
    const text = encodeURIComponent(message)

    const shareUrls = {
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${url}`,
      twitter: `https://twitter.com/intent/tweet?text=${text}&url=${url}`,
      whatsapp: `https://wa.me/?text=${text} ${url}`,
      email: `mailto:?subject=Check out WriteHunters&body=${text} ${referralLink}`,
    }

    window.open(shareUrls[platform as keyof typeof shareUrls], "_blank")
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <section className="section-padding bg-gradient-to-br from-purple-50 via-blue-50 to-cyan-50">
        <div className="container mx-auto container-padding">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-6 bg-gradient-to-r from-coral to-purple text-white border-0">
              <Gift className="h-4 w-4 mr-2" />
              Referral Program
            </Badge>
            <h1 className="font-serif text-4xl md:text-5xl font-bold text-foreground mb-6">
              Earn Money by Sharing WriteHunters
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Get paid for every successful referral! Earn 20% commission on every order placed by your referrals.
            </p>

            <div className="grid md:grid-cols-4 gap-6 mb-12">
              <Card className="card-elevated">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-gradient-success rounded-lg flex items-center justify-center mx-auto mb-4">
                    <Users className="h-6 w-6 text-white" />
                  </div>
                  <div className="text-2xl font-bold text-success mb-1">{referralStats.totalReferrals}</div>
                  <div className="text-sm text-muted-foreground">Total Referrals</div>
                </CardContent>
              </Card>

              <Card className="card-elevated">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-gradient-coral rounded-lg flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="h-6 w-6 text-white" />
                  </div>
                  <div className="text-2xl font-bold text-coral mb-1">{referralStats.successfulReferrals}</div>
                  <div className="text-sm text-muted-foreground">Successful</div>
                </CardContent>
              </Card>

              <Card className="card-elevated">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-gradient-purple rounded-lg flex items-center justify-center mx-auto mb-4">
                    <DollarSign className="h-6 w-6 text-white" />
                  </div>
                  <div className="text-2xl font-bold text-purple mb-1">${referralStats.totalEarnings}</div>
                  <div className="text-sm text-muted-foreground">Total Earned</div>
                </CardContent>
              </Card>

              <Card className="card-elevated">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-gradient-to-br from-warning to-orange-400 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <TrendingUp className="h-6 w-6 text-white" />
                  </div>
                  <div className="text-2xl font-bold text-warning mb-1">${referralStats.pendingEarnings}</div>
                  <div className="text-sm text-muted-foreground">Pending</div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Referral Link Section */}
      <section className="section-padding">
        <div className="container mx-auto container-padding">
          <div className="max-w-4xl mx-auto">
            <Card className="card-premium shadow-xl mb-12">
              <CardContent className="p-8">
                <h2 className="font-serif text-3xl font-bold mb-6 text-center">Your Referral Link</h2>
                <div className="bg-gradient-to-r from-slate-50 to-blue-50 rounded-lg p-6 mb-6">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <div className="font-semibold text-foreground mb-1">Your Referral Code</div>
                      <div className="text-2xl font-bold text-coral">{referralCode}</div>
                    </div>
                    <Badge className="bg-success text-white">Active</Badge>
                  </div>

                  <div className="flex items-center space-x-2 mb-4">
                    <input
                      type="text"
                      value={referralLink}
                      readOnly
                      className="flex-1 px-4 py-3 border border-gray-300 rounded-lg bg-white"
                    />
                    <Button
                      onClick={copyToClipboard}
                      className={`px-6 ${copied ? "bg-success" : "bg-coral"} hover:opacity-90`}
                    >
                      {copied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                    </Button>
                  </div>

                  <div className="flex flex-wrap gap-3">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => shareOnSocial("facebook")}
                      className="flex items-center space-x-2"
                    >
                      <Facebook className="h-4 w-4" />
                      <span>Facebook</span>
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => shareOnSocial("twitter")}
                      className="flex items-center space-x-2"
                    >
                      <Twitter className="h-4 w-4" />
                      <span>Twitter</span>
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => shareOnSocial("whatsapp")}
                      className="flex items-center space-x-2"
                    >
                      <MessageCircle className="h-4 w-4" />
                      <span>WhatsApp</span>
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => shareOnSocial("email")}
                      className="flex items-center space-x-2"
                    >
                      <Mail className="h-4 w-4" />
                      <span>Email</span>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* How It Works */}
            <div className="mb-12">
              <h2 className="font-serif text-3xl font-bold text-center mb-12">How It Works</h2>
              <div className="grid md:grid-cols-3 gap-8">
                <Card className="card-elevated text-center">
                  <CardContent className="p-8">
                    <div className="w-16 h-16 bg-gradient-coral rounded-2xl flex items-center justify-center mx-auto mb-6">
                      <Share2 className="h-8 w-8 text-white" />
                    </div>
                    <h3 className="font-semibold text-xl mb-4">1. Share Your Link</h3>
                    <p className="text-muted-foreground">
                      Share your unique referral link with friends, classmates, or on social media.
                    </p>
                  </CardContent>
                </Card>

                <Card className="card-elevated text-center">
                  <CardContent className="p-8">
                    <div className="w-16 h-16 bg-gradient-purple rounded-2xl flex items-center justify-center mx-auto mb-6">
                      <Users className="h-8 w-8 text-white" />
                    </div>
                    <h3 className="font-semibold text-xl mb-4">2. Friends Sign Up</h3>
                    <p className="text-muted-foreground">
                      When someone clicks your link and places their first order, they get 10% off.
                    </p>
                  </CardContent>
                </Card>

                <Card className="card-elevated text-center">
                  <CardContent className="p-8">
                    <div className="w-16 h-16 bg-gradient-success rounded-2xl flex items-center justify-center mx-auto mb-6">
                      <DollarSign className="h-8 w-8 text-white" />
                    </div>
                    <h3 className="font-semibold text-xl mb-4">3. You Earn Money</h3>
                    <p className="text-muted-foreground">
                      Earn 20% commission on every order placed by your referrals. Get paid monthly!
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Rewards Structure */}
            <Card className="card-elevated mb-12">
              <CardContent className="p-8">
                <h2 className="font-serif text-3xl font-bold text-center mb-8">Reward Structure</h2>
                <div className="grid md:grid-cols-2 gap-8">
                  <div className="space-y-6">
                    <div className="flex items-center space-x-4 p-4 bg-gradient-to-r from-coral/10 to-coral/5 rounded-lg">
                      <div className="w-12 h-12 bg-coral rounded-lg flex items-center justify-center">
                        <Gift className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <div className="font-semibold text-coral">New Customer Bonus</div>
                        <div className="text-sm text-muted-foreground">
                          Your referral gets 10% off their first order
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-4 p-4 bg-gradient-to-r from-success/10 to-success/5 rounded-lg">
                      <div className="w-12 h-12 bg-success rounded-lg flex items-center justify-center">
                        <DollarSign className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <div className="font-semibold text-success">Your Commission</div>
                        <div className="text-sm text-muted-foreground">Earn 20% on every order they place</div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div className="flex items-center space-x-4 p-4 bg-gradient-to-r from-purple/10 to-purple/5 rounded-lg">
                      <div className="w-12 h-12 bg-purple rounded-lg flex items-center justify-center">
                        <Star className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <div className="font-semibold text-purple">Lifetime Earnings</div>
                        <div className="text-sm text-muted-foreground">
                          Earn from all future orders by your referrals
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-4 p-4 bg-gradient-to-r from-warning/10 to-warning/5 rounded-lg">
                      <div className="w-12 h-12 bg-warning rounded-lg flex items-center justify-center">
                        <TrendingUp className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <div className="font-semibold text-warning">Monthly Payouts</div>
                        <div className="text-sm text-muted-foreground">Get paid via PayPal or bank transfer</div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* CTA Section */}
            <Card className="bg-gradient-to-r from-coral to-purple text-white">
              <CardContent className="p-8 text-center">
                <h2 className="font-serif text-3xl font-bold mb-4">Start Earning Today!</h2>
                <p className="text-xl mb-6 opacity-90">
                  Join hundreds of students already earning money with WriteHunters referral program.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button size="lg" className="bg-white text-coral hover:bg-gray-100" onClick={copyToClipboard}>
                    <Copy className="h-5 w-5 mr-2" />
                    Copy Referral Link
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    className="border-white text-white hover:bg-white hover:text-coral bg-transparent"
                    asChild
                  >
                    <a href="/contact">
                      <span>Contact Support</span>
                      <ArrowRight className="h-5 w-5 ml-2" />
                    </a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  )
}
