const express = require('express');
const sendMail = require('../mailer');
const router = express.Router();

router.post('/', async (req, res) => {
  const { name, email, subject, message } = req.body;
  if (!email || !message) return res.status(400).json({ error: 'Email and message required' });
  const to = process.env.CONTACT_EMAIL || 'writehunters@gmail.com';
  const body = `
    New message from WriteHunters contact form:
    Name: ${name || 'N/A'}
    Email: ${email}
    Subject: ${subject || 'N/A'}
    Message:
    ${message}
  `;
  try {
    await sendMail({ to, subject: `[Contact] ${subject || 'Website message'}`, text: body, from: process.env.SMTP_USER });
    res.json({ ok: true });
  } catch (err) {
    console.error('Contact mail error', err);
    res.status(500).json({ error: 'Failed to send message' });
  }
});

module.exports = router;