"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  CheckCircle,
  BookOpen,
  Users,
  Award,
  Mail,
  MessageCircle,
  Star,
  Clock,
  Facebook,
  Instagram,
  ArrowRight,
  Sparkles,
  TrendingUp,
} from "lucide-react"
import LeadCaptureModal from "@/components/LeadCaptureModal"
import NewsletterSignup from "@/components/NewsletterSignup"
import { useExitIntent } from "@/hooks/useExitIntent"

export default function ClientPage() {
  const { showExitIntent, closeExitIntent } = useExitIntent()

  return (
    <div className="min-h-screen bg-background">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Organization",
            name: "WriteHunters",
            description: "Professional academic writing services for students and academics worldwide",
            url: "https://writehunters.com",
            logo: "https://writehunters.com/logo.png",
            contactPoint: {
              "@type": "ContactPoint",
              telephone: "+254748881893",
              contactType: "customer service",
              availableLanguage: "English",
            },
            address: {
              "@type": "PostalAddress",
              addressCountry: "KE",
            },
            sameAs: ["https://wa.me/254748881893"],
            aggregateRating: {
              "@type": "AggregateRating",
              ratingValue: "4.9",
              reviewCount: "5000",
            },
            offers: {
              "@type": "Offer",
              description: "Academic writing services including essays, research papers, and editing",
              priceRange: "$15-$50",
            },
          }),
        }}
      />

      {/* Header */}
      <header className="border-b glass-effect sticky top-0 z-50 animate-fade-in">
        <div className="container mx-auto container-padding py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3 group">
              <div className="w-10 h-10 bg-gradient-primary rounded-lg flex items-center justify-center shadow-sm group-hover:shadow-lg transition-all duration-300">
                <BookOpen className="h-6 w-6 text-yellow-300" />
              </div>
              <span className="font-serif text-2xl font-bold text-gradient-primary">WriteHunters</span>
            </div>
            <nav className="hidden md:flex items-center space-x-8">
              <a
                href="/services"
                className="text-foreground hover:text-primary transition-all duration-300 font-medium hover:scale-105"
              >
                Services
              </a>
              <a
                href="/about"
                className="text-foreground hover:text-primary transition-all duration-300 font-medium hover:scale-105"
              >
                About
              </a>
              <a
                href="/contact"
                className="text-foreground hover:text-primary transition-all duration-300 font-medium hover:scale-105"
              >
                Contact
              </a>
              <a
                href="/login"
                className="text-foreground hover:text-primary transition-all duration-300 font-medium hover:scale-105"
              >
                Login
              </a>
              <a
                href="/client-dashboard"
                className="text-foreground hover:text-primary transition-all duration-300 font-medium hover:scale-105"
              >
                Dashboard
              </a>
            </nav>
            <Button asChild className="btn-coral shadow-lg hover:shadow-xl">
              <a href="/order" className="flex items-center space-x-2">
                <span>Place Your Order</span>
                <ArrowRight className="h-4 w-4" />
              </a>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="section-padding bg-gradient-to-br from-blue-50 via-purple-50 to-cyan-50 relative overflow-hidden">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-20 left-10 w-32 h-32 bg-purple/10 rounded-full blur-3xl animate-float"></div>
          <div
            className="absolute top-40 right-20 w-48 h-48 bg-coral/10 rounded-full blur-3xl animate-float"
            style={{ animationDelay: "2s" }}
          ></div>
          <div
            className="absolute bottom-20 left-1/3 w-40 h-40 bg-accent/10 rounded-full blur-3xl animate-float"
            style={{ animationDelay: "4s" }}
          ></div>
        </div>

        <div className="container mx-auto container-padding relative">
          <div className="max-w-5xl mx-auto text-center">
            <Badge className="mb-8 bg-gradient-to-r from-purple to-accent text-white border-0 shadow-lg hover:shadow-xl transition-all duration-300 animate-scale-in">
              <Sparkles className="h-4 w-4 mr-2" />
              Professional Academic Writing
            </Badge>
            <h1 className="font-serif text-5xl md:text-6xl lg:text-7xl font-bold text-foreground mb-8 animate-slide-up text-balance">
              Elevate Your Academic Writing with <span className="text-gradient-coral">Expert Guidance</span>
            </h1>
            <p
              className="text-xl md:text-2xl text-muted-foreground mb-12 max-w-3xl mx-auto animate-slide-up text-balance"
              style={{ animationDelay: "0.2s" }}
            >
              Crafting quality papers for every level of study. From essays to dissertations, our expert writers deliver
              excellence that meets your academic standards.
            </p>
            <div
              className="flex flex-col sm:flex-row gap-6 justify-center mb-16 animate-slide-up"
              style={{ animationDelay: "0.4s" }}
            >
              <Button size="lg" asChild className="btn-coral text-lg px-10 py-5 shadow-xl">
                <a href="/order" className="flex items-center space-x-2">
                  <span>Place Your Order</span>
                  <ArrowRight className="h-5 w-5" />
                </a>
              </Button>
              <Button
                size="lg"
                variant="outline"
                asChild
                className="text-lg px-10 py-5 bg-white/80 backdrop-blur border-purple/30 text-purple hover:bg-purple hover:text-white shadow-lg hover:shadow-xl transition-all duration-300"
              >
                <a href="/services" className="flex items-center space-x-2">
                  <span>View Our Services</span>
                  <TrendingUp className="h-5 w-5" />
                </a>
              </Button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 animate-slide-up" style={{ animationDelay: "0.6s" }}>
              <div className="text-center group">
                <div className="w-20 h-20 bg-gradient-success rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg group-hover:shadow-xl transition-all duration-300 hover-lift">
                  <Users className="h-10 w-10 text-green-100" />
                </div>
                <div className="text-3xl md:text-4xl font-bold text-success mb-2">5000+</div>
                <div className="text-sm md:text-base text-muted-foreground font-medium">Happy Students</div>
              </div>
              <div className="text-center group">
                <div className="w-20 h-20 bg-gradient-to-br from-warning to-orange-400 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg group-hover:shadow-xl transition-all duration-300 hover-lift">
                  <BookOpen className="h-10 w-10 text-orange-100" />
                </div>
                <div className="text-3xl md:text-4xl font-bold text-warning mb-2">15000+</div>
                <div className="text-sm md:text-base text-muted-foreground font-medium">Papers Delivered</div>
              </div>
              <div className="text-center group">
                <div className="w-20 h-20 bg-gradient-purple rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg group-hover:shadow-xl transition-all duration-300 hover-lift">
                  <Star className="h-10 w-10 text-purple-100" />
                </div>
                <div className="text-3xl md:text-4xl font-bold text-purple mb-2">4.9/5</div>
                <div className="text-sm md:text-base text-muted-foreground font-medium">Average Rating</div>
              </div>
              <div className="text-center group">
                <div className="w-20 h-20 bg-gradient-coral rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg group-hover:shadow-xl transition-all duration-300 hover-lift">
                  <Clock className="h-10 w-10 text-coral-100" />
                </div>
                <div className="text-3xl md:text-4xl font-bold text-coral mb-2">24/7</div>
                <div className="text-sm md:text-base text-muted-foreground font-medium">Support Available</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section id="services" className="section-padding">
        <div className="container mx-auto container-padding">
          <div className="text-center mb-20 animate-fade-in">
            <Badge className="mb-6 bg-purple/10 text-purple border-purple/20">Our Expertise</Badge>
            <h2 className="font-serif text-4xl md:text-5xl font-bold text-foreground mb-6 text-balance">
              Our Writing Services
            </h2>
            <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto text-balance">
              Comprehensive academic writing solutions tailored to your needs
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 lg:gap-12">
            <Card className="card-elevated hover-lift group animate-fade-in">
              <CardContent className="p-8 lg:p-10">
                <div className="w-16 h-16 bg-gradient-coral rounded-2xl flex items-center justify-center mb-8 shadow-lg group-hover:shadow-xl transition-all duration-300">
                  <BookOpen className="h-8 w-8 text-coral-100" />
                </div>
                <h3 className="font-serif text-2xl md:text-3xl font-bold mb-6">Essay Writing</h3>
                <p className="text-muted-foreground mb-8 text-lg leading-relaxed">
                  Custom essays crafted to your specifications with thorough research and perfect formatting.
                </p>
                <ul className="space-y-4">
                  <li className="flex items-center text-base">
                    <CheckCircle className="h-5 w-5 text-success mr-3 flex-shrink-0" />
                    <span>Original content guaranteed</span>
                  </li>
                  <li className="flex items-center text-base">
                    <CheckCircle className="h-5 w-5 text-success mr-3 flex-shrink-0" />
                    <span>Proper citations & formatting</span>
                  </li>
                  <li className="flex items-center text-base">
                    <CheckCircle className="h-5 w-5 text-success mr-3 flex-shrink-0" />
                    <span>Timely delivery promise</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="card-premium hover-lift group animate-fade-in" style={{ animationDelay: "0.2s" }}>
              <CardContent className="p-8 lg:p-10">
                <Badge className="mb-6 bg-purple text-white">Most Popular</Badge>
                <div className="w-16 h-16 bg-gradient-purple rounded-2xl flex items-center justify-center mb-8 shadow-lg group-hover:shadow-xl transition-all duration-300">
                  <Award className="h-8 w-8 text-purple-100" />
                </div>
                <h3 className="font-serif text-2xl md:text-3xl font-bold mb-6">Research Papers</h3>
                <p className="text-muted-foreground mb-8 text-lg leading-relaxed">
                  In-depth research papers with comprehensive analysis and scholarly references.
                </p>
                <ul className="space-y-4">
                  <li className="flex items-center text-base">
                    <CheckCircle className="h-5 w-5 text-success mr-3 flex-shrink-0" />
                    <span>Extensive research methodology</span>
                  </li>
                  <li className="flex items-center text-base">
                    <CheckCircle className="h-5 w-5 text-success mr-3 flex-shrink-0" />
                    <span>Academic standards compliance</span>
                  </li>
                  <li className="flex items-center text-base">
                    <CheckCircle className="h-5 w-5 text-success mr-3 flex-shrink-0" />
                    <span>Expert analysis & insights</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="card-elevated hover-lift group animate-fade-in" style={{ animationDelay: "0.4s" }}>
              <CardContent className="p-8 lg:p-10">
                <div className="w-16 h-16 bg-gradient-to-br from-accent to-cyan-400 rounded-2xl flex items-center justify-center mb-8 shadow-lg group-hover:shadow-xl transition-all duration-300">
                  <Users className="h-8 w-8 text-cyan-100" />
                </div>
                <h3 className="font-serif text-2xl md:text-3xl font-bold mb-6">Editing & Proofreading</h3>
                <p className="text-muted-foreground mb-8 text-lg leading-relaxed">
                  Professional editing services to polish your work to perfection.
                </p>
                <ul className="space-y-4">
                  <li className="flex items-center text-base">
                    <CheckCircle className="h-5 w-5 text-success mr-3 flex-shrink-0" />
                    <span>Grammar & syntax correction</span>
                  </li>
                  <li className="flex items-center text-base">
                    <CheckCircle className="h-5 w-5 text-success mr-3 flex-shrink-0" />
                    <span>Style & tone improvement</span>
                  </li>
                  <li className="flex items-center text-base">
                    <CheckCircle className="h-5 w-5 text-success mr-3 flex-shrink-0" />
                    <span>Structure optimization</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="section-padding bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50">
        <div className="container mx-auto container-padding">
          <div className="text-center mb-20 animate-fade-in">
            <Badge className="mb-6 bg-success/10 text-success border-success/20">Client Success</Badge>
            <h2 className="font-serif text-4xl md:text-5xl font-bold text-foreground mb-6 text-balance">
              What Our Clients Say
            </h2>
            <p className="text-xl md:text-2xl text-muted-foreground text-balance">
              Trusted by students and academics worldwide
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-12">
            <Card className="card-elevated hover-lift border-l-4 border-l-coral animate-fade-in">
              <CardContent className="p-8">
                <div className="flex items-center mb-6">
                  <div className="flex text-warning text-xl">{"★".repeat(5)}</div>
                </div>
                <p className="text-muted-foreground mb-8 text-lg leading-relaxed italic">
                  "WriteHunters delivered an exceptional research paper that exceeded my expectations. The quality and
                  attention to detail were outstanding."
                </p>
                <div className="flex items-center space-x-4">
                  <img
                    src="/professional-woman-student.png"
                    alt="Sarah M."
                    className="w-12 h-12 rounded-full object-cover border-2 border-coral/20"
                  />
                  <div>
                    <div className="font-semibold text-coral text-lg">Sarah M.</div>
                    <div className="text-sm text-muted-foreground">Graduate Student, Kenya</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card
              className="card-elevated hover-lift border-l-4 border-l-purple animate-fade-in"
              style={{ animationDelay: "0.2s" }}
            >
              <CardContent className="p-8">
                <div className="flex items-center mb-6">
                  <div className="flex text-warning text-xl">{"★".repeat(5)}</div>
                </div>
                <p className="text-muted-foreground mb-8 text-lg leading-relaxed italic">
                  "Professional, reliable, and always on time. Their editing service helped me improve my thesis
                  significantly."
                </p>
                <div className="flex items-center space-x-4">
                  <img
                    src="/professional-man-student.png"
                    alt="James K."
                    className="w-12 h-12 rounded-full object-cover border-2 border-purple/20"
                  />
                  <div>
                    <div className="font-semibold text-purple text-lg">James K.</div>
                    <div className="text-sm text-muted-foreground">PhD Candidate, UK</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card
              className="card-elevated hover-lift border-l-4 border-l-success animate-fade-in"
              style={{ animationDelay: "0.4s" }}
            >
              <CardContent className="p-8">
                <div className="flex items-center mb-6">
                  <div className="flex text-warning text-xl">{"★".repeat(5)}</div>
                </div>
                <p className="text-muted-foreground mb-8 text-lg leading-relaxed italic">
                  "The team at WriteHunters understands academic requirements perfectly. Highly recommend their
                  services!"
                </p>
                <div className="flex items-center space-x-4">
                  <img
                    src="/placeholder-hc04d.png"
                    alt="Maria L."
                    className="w-12 h-12 rounded-full object-cover border-2 border-success/20"
                  />
                  <div>
                    <div className="font-semibold text-success text-lg">Maria L.</div>
                    <div className="text-sm text-muted-foreground">Undergraduate, USA</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card
              className="card-elevated hover-lift border-l-4 border-l-accent animate-fade-in"
              style={{ animationDelay: "0.6s" }}
            >
              <CardContent className="p-8">
                <div className="flex items-center mb-6">
                  <div className="flex text-warning text-xl">{"★".repeat(5)}</div>
                </div>
                <p className="text-muted-foreground mb-8 text-lg leading-relaxed italic">
                  "Outstanding dissertation support! The research methodology was thorough and the writing quality
                  exceptional. Couldn't have completed my PhD without them."
                </p>
                <div className="flex items-center space-x-4">
                  <img
                    src="/professional-african-academic.png"
                    alt="Dr. Emmanuel O."
                    className="w-12 h-12 rounded-full object-cover border-2 border-accent/20"
                  />
                  <div>
                    <div className="font-semibold text-accent text-lg">Dr. Emmanuel O.</div>
                    <div className="text-sm text-muted-foreground">PhD Graduate, Nigeria</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card
              className="card-elevated hover-lift border-l-4 border-l-warning animate-fade-in"
              style={{ animationDelay: "0.8s" }}
            >
              <CardContent className="p-8">
                <div className="flex items-center mb-6">
                  <div className="flex text-warning text-xl">{"★".repeat(5)}</div>
                </div>
                <p className="text-muted-foreground mb-8 text-lg leading-relaxed italic">
                  "Excellent class management service! They handled all my coursework professionally while I focused on
                  my internship. Highly recommended for busy students."
                </p>
                <div className="flex items-center space-x-4">
                  <img
                    src="/professional-asian-student.png"
                    alt="Priya S."
                    className="w-12 h-12 rounded-full object-cover border-2 border-warning/20"
                  />
                  <div>
                    <div className="font-semibold text-warning text-lg">Priya S.</div>
                    <div className="text-sm text-muted-foreground">MBA Student, Canada</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card
              className="card-elevated hover-lift border-l-4 border-l-indigo-500 animate-fade-in"
              style={{ animationDelay: "1.0s" }}
            >
              <CardContent className="p-8">
                <div className="flex items-center mb-6">
                  <div className="flex text-warning text-xl">{"★".repeat(5)}</div>
                </div>
                <p className="text-muted-foreground mb-8 text-lg leading-relaxed italic">
                  "Amazing support for my engineering thesis! The technical writing was precise and the research was
                  comprehensive. They truly understand complex subjects."
                </p>
                <div className="flex items-center space-x-4">
                  <img
                    src="/middle-eastern-engineer.png"
                    alt="Ahmed R."
                    className="w-12 h-12 rounded-full object-cover border-2 border-indigo-500/20"
                  />
                  <div>
                    <div className="font-semibold text-indigo-600 text-lg">Ahmed R.</div>
                    <div className="text-sm text-muted-foreground">Engineering Student, UAE</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Newsletter Signup Section */}
      <section className="section-padding bg-gradient-to-r from-slate-50 to-purple-50">
        <div className="container mx-auto container-padding">
          <div className="max-w-4xl mx-auto">
            <NewsletterSignup />
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-slate-900 to-slate-800 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <BookOpen className="h-6 w-6 text-accent" />
                <span className="font-serif text-xl font-bold">WriteHunters</span>
              </div>
              <p className="text-slate-300 mb-4">
                Professional academic writing services for students and academics worldwide.
              </p>
              <div className="flex space-x-4">
                <a
                  href="https://www.facebook.com/profile.php?id=61577361405554"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center hover:bg-blue-700 transition-colors shadow-lg hover:shadow-xl"
                >
                  <Facebook className="h-5 w-5 text-blue-100" />
                </a>
                <a
                  href="https://www.instagram.com/writehunters/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center hover:from-purple-600 hover:to-pink-600 transition-colors shadow-lg hover:shadow-xl"
                >
                  <Instagram className="h-5 w-5 text-pink-100" />
                </a>
                <a
                  href="/messages"
                  className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center hover:bg-green-700 transition-colors shadow-lg hover:shadow-xl"
                >
                  <MessageCircle className="h-5 w-5 text-green-100" />
                </a>
              </div>
            </div>

            <div>
              <h4 className="font-semibold mb-4 text-coral">Services</h4>
              <ul className="space-y-2 text-slate-300">
                <li>
                  <a href="/services" className="hover:text-coral transition-colors">
                    Essay Writing
                  </a>
                </li>
                <li>
                  <a href="/services" className="hover:text-coral transition-colors">
                    Research Papers
                  </a>
                </li>
                <li>
                  <a href="/services" className="hover:text-coral transition-colors">
                    Editing & Proofreading
                  </a>
                </li>
                <li>
                  <a href="/write-my-paper" className="hover:text-coral transition-colors">
                    Write My Paper
                  </a>
                </li>
                <li>
                  <a href="/manage-my-classes" className="hover:text-coral transition-colors">
                    Class Management
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4 text-purple">Company</h4>
              <ul className="space-y-2 text-slate-300">
                <li>
                  <a href="/about" className="hover:text-purple transition-colors">
                    About Us
                  </a>
                </li>
                <li>
                  <a href="/contact" className="hover:text-purple transition-colors">
                    Contact
                  </a>
                </li>
                <li>
                  <a href="/privacy-policy" className="hover:text-purple transition-colors">
                    Privacy Policy
                  </a>
                </li>
                <li>
                  <a href="/cookie-policy" className="hover:text-purple transition-colors">
                    Cookie Policy
                  </a>
                </li>
                <li>
                  <a href="/terms-conditions" className="hover:text-purple transition-colors">
                    Terms & Conditions
                  </a>
                </li>
                <li>
                  <a href="/login" className="hover:text-purple transition-colors">
                    Client Login
                  </a>
                </li>
                <li>
                  <a href="/messages" className="hover:text-purple transition-colors">
                    Send Message
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4 text-success">Contact</h4>
              <div className="space-y-2 text-slate-300">
                <div className="flex items-center space-x-2">
                  <MessageCircle className="h-4 w-4 text-green-400" />
                  <span>WhatsApp: +254 748 881893</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Mail className="h-4 w-4 text-blue-400" />
                  <span>Email: writehunters@gmail.com</span>
                </div>
                <div className="mt-4">
                  <a
                    href="https://www.facebook.com/profile.php?id=61577361405554"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-slate-300 hover:text-blue-400 transition-colors flex items-center space-x-2"
                  >
                    <Facebook className="h-4 w-4 text-blue-400" />
                    <span>Facebook</span>
                  </a>
                </div>
                <div>
                  <a
                    href="https://www.instagram.com/writehunters/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-slate-300 hover:text-pink-400 transition-colors flex items-center space-x-2"
                  >
                    <Instagram className="h-4 w-4 text-pink-400" />
                    <span>Instagram</span>
                  </a>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-slate-700 mt-8 pt-8 text-center text-slate-300">
            <p>&copy; 2024 WriteHunters. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Exit-intent Modal */}
      <LeadCaptureModal isOpen={showExitIntent} onClose={closeExitIntent} type="exit-intent" />
    </div>
  )
}
