import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Users, Award, Shield, CheckCircle, Star, Target, Heart, Zap } from "lucide-react"
import Link from "next/link"

export const metadata = {
  title: "About WriteHunters - Trusted Academic Writing Service Since 2019",
  description:
    "Learn about WriteHunters, your trusted academic writing partner. 5000+ satisfied students, 15000+ papers delivered, 4.9/5 rating. Expert PhD & Master's writers with quality guarantees.",
  keywords:
    "about WriteHunters, academic writing company, expert writers, PhD writers, academic writing team, WriteHunters history",
  openGraph: {
    title: "About WriteHunters - Trusted Academic Writing Service",
    description:
      "5000+ satisfied students trust WriteHunters for academic writing. Expert writers with quality guarantees.",
    type: "website",
    url: "https://writehunters.com/about",
  },
}

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <BookOpen className="h-8 w-8 text-primary" />
              <span className="font-serif text-2xl font-bold text-primary">WriteHunters</span>
            </Link>
            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-foreground hover:text-primary transition-colors">
                Home
              </Link>
              <Link href="/services" className="text-foreground hover:text-primary transition-colors">
                Services
              </Link>
              <Link href="/about" className="text-primary font-semibold">
                About
              </Link>
              <Link href="/blog" className="text-foreground hover:text-primary transition-colors">
                Blog
              </Link>
              <Link href="/contact" className="text-foreground hover:text-primary transition-colors">
                Contact
              </Link>
            </nav>
            <Button className="bg-primary hover:bg-primary/90">
              <Link href="/order">Place Your Order</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-6 bg-accent/10 text-accent border-accent/20">About WriteHunters</Badge>
            <h1 className="font-serif text-4xl md:text-5xl font-bold text-foreground mb-6">
              Your Trusted Academic Writing Partner
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-6">
              At WriteHunters, we are committed to providing top-tier academic assistance tailored to your needs.
              Whether you're tackling essays, dissertations, or require editing expertise, our team of professionals is
              here to help. We pride ourselves on delivering original, reliable, and precise content, ensuring that your
              academic goals are within reach. Trust WriteHunters to be a pivotal part of your academic journey.
            </p>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              For over 5 years, WriteHunters has been helping students and academics achieve their goals through
              exceptional writing services. We combine expertise, integrity, and innovation to deliver results that
              exceed expectations.
            </p>
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="font-serif text-4xl font-bold text-foreground mb-6">Our Story</h2>
                <p className="text-muted-foreground mb-6">
                  WriteHunters was founded in 2019 with a simple mission: to help students succeed academically by
                  providing high-quality, original writing services. What started as a small team of passionate
                  educators has grown into a trusted network of expert writers serving students worldwide.
                </p>
                <p className="text-muted-foreground mb-6">
                  Based in Kenya with a global reach, we serve students from universities across Africa, Europe, North
                  America, and beyond. Our team consists of carefully vetted writers with advanced degrees from
                  prestigious institutions including University of Nairobi, Strathmore University, Harvard, Oxford, and
                  Cambridge.
                </p>
                <p className="text-muted-foreground mb-6">
                  We understand the challenges students face - tight deadlines, complex assignments, language barriers,
                  and the pressure to excel. That's why we've built a service that not only delivers exceptional work
                  but also provides learning opportunities through our detailed, well-researched papers with
                  comprehensive explanations.
                </p>
                <p className="text-muted-foreground mb-6">
                  Our commitment extends beyond just writing. We offer 24/7 customer support, free revisions, plagiarism
                  reports, and even tutoring sessions to help students understand complex concepts. We believe in
                  empowering students with knowledge, not just completing their assignments.
                </p>
                <p className="text-muted-foreground">
                  Today, we're proud to have helped over 5,000 students achieve their academic goals while maintaining
                  the highest standards of quality, integrity, and academic excellence. Our success is measured by our
                  students' success.
                </p>
              </div>
              <div className="space-y-6">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <Users className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-primary">5000+</div>
                        <div className="text-muted-foreground">Happy Students</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <BookOpen className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-primary">15000+</div>
                        <div className="text-muted-foreground">Papers Delivered</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <Star className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-primary">4.9/5</div>
                        <div className="text-muted-foreground">Average Rating</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-20 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl font-bold text-foreground mb-4">Our Core Values</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              These principles guide everything we do and ensure we deliver exceptional service every time
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Shield className="h-8 w-8 text-primary" />
                </div>
                <h3 className="font-serif text-2xl font-bold mb-4">Integrity</h3>
                <p className="text-muted-foreground">
                  We maintain the highest ethical standards, ensuring all work is original, properly cited, and
                  academically honest.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Target className="h-8 w-8 text-primary" />
                </div>
                <h3 className="font-serif text-2xl font-bold mb-4">Excellence</h3>
                <p className="text-muted-foreground">
                  We strive for perfection in every paper, combining thorough research with exceptional writing to
                  exceed expectations.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Heart className="h-8 w-8 text-primary" />
                </div>
                <h3 className="font-serif text-2xl font-bold mb-4">Support</h3>
                <p className="text-muted-foreground">
                  We're committed to supporting student success through personalized service, timely delivery, and
                  ongoing assistance.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Our Team */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl font-bold text-foreground mb-4">Meet Our Expert Writers</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Our team consists of qualified professionals with advanced degrees and extensive writing experience
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-10 w-10 text-primary" />
                </div>
                <h3 className="font-serif text-lg font-bold mb-2">PhD Writers</h3>
                <p className="text-muted-foreground text-sm mb-4">
                  Doctoral degree holders specializing in advanced research and dissertation writing.
                </p>
                <Badge className="bg-primary/10 text-primary">25+ Writers</Badge>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="h-10 w-10 text-primary" />
                </div>
                <h3 className="font-serif text-lg font-bold mb-2">Master's Experts</h3>
                <p className="text-muted-foreground text-sm mb-4">
                  Graduate-level specialists in various academic disciplines and professional fields.
                </p>
                <Badge className="bg-primary/10 text-primary">50+ Writers</Badge>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <BookOpen className="h-10 w-10 text-primary" />
                </div>
                <h3 className="font-serif text-lg font-bold mb-2">Subject Specialists</h3>
                <p className="text-muted-foreground text-sm mb-4">
                  Writers with deep expertise in specific academic fields and industries.
                </p>
                <Badge className="bg-primary/10 text-primary">100+ Fields</Badge>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Zap className="h-10 w-10 text-primary" />
                </div>
                <h3 className="font-serif text-lg font-bold mb-2">Native Speakers</h3>
                <p className="text-muted-foreground text-sm mb-4">
                  Native English speakers ensuring perfect grammar, style, and academic tone.
                </p>
                <Badge className="bg-primary/10 text-primary">100% Native</Badge>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Our Expertise */}
      <section className="py-20 bg-gradient-to-br from-blue-50 to-cyan-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl font-bold text-foreground mb-4">Our Areas of Expertise</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              We cover over 100 academic disciplines with specialized writers for each field
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center hover:shadow-lg transition-shadow border-l-4 border-l-blue-500">
              <CardContent className="p-6">
                <h3 className="font-serif text-lg font-bold mb-3 text-blue-600">Business & Management</h3>
                <p className="text-sm text-muted-foreground">MBA, Finance, Marketing, HR, Operations, Strategy</p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow border-l-4 border-l-green-500">
              <CardContent className="p-6">
                <h3 className="font-serif text-lg font-bold mb-3 text-green-600">Sciences & Technology</h3>
                <p className="text-sm text-muted-foreground">
                  Computer Science, Engineering, Biology, Chemistry, Physics
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow border-l-4 border-l-purple-500">
              <CardContent className="p-6">
                <h3 className="font-serif text-lg font-bold mb-3 text-purple-600">Social Sciences</h3>
                <p className="text-sm text-muted-foreground">Psychology, Sociology, Political Science, Anthropology</p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow border-l-4 border-l-orange-500">
              <CardContent className="p-6">
                <h3 className="font-serif text-lg font-bold mb-3 text-orange-600">Humanities & Arts</h3>
                <p className="text-sm text-muted-foreground">Literature, History, Philosophy, Art, Music, Languages</p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow border-l-4 border-l-red-500">
              <CardContent className="p-6">
                <h3 className="font-serif text-lg font-bold mb-3 text-red-600">Health & Medicine</h3>
                <p className="text-sm text-muted-foreground">Nursing, Medicine, Public Health, Pharmacy, Dentistry</p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow border-l-4 border-l-teal-500">
              <CardContent className="p-6">
                <h3 className="font-serif text-lg font-bold mb-3 text-teal-600">Education</h3>
                <p className="text-sm text-muted-foreground">
                  Teaching, Curriculum, Educational Psychology, Administration
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow border-l-4 border-l-indigo-500">
              <CardContent className="p-6">
                <h3 className="font-serif text-lg font-bold mb-3 text-indigo-600">Law & Legal Studies</h3>
                <p className="text-sm text-muted-foreground">
                  Constitutional Law, Criminal Law, Corporate Law, International Law
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow border-l-4 border-l-pink-500">
              <CardContent className="p-6">
                <h3 className="font-serif text-lg font-bold mb-3 text-pink-600">Environmental Studies</h3>
                <p className="text-sm text-muted-foreground">
                  Sustainability, Climate Change, Conservation, Green Technology
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Quality Guarantees */}
      <section className="py-20 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl font-bold text-foreground mb-4">Our Quality Guarantees</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              We stand behind our work with comprehensive guarantees that protect your investment
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="flex items-center mb-4">
                  <CheckCircle className="h-6 w-6 text-accent mr-3" />
                  <h3 className="font-serif text-xl font-bold">100% Original Work</h3>
                </div>
                <p className="text-muted-foreground">
                  Every paper is written from scratch with thorough plagiarism checks and detailed reports provided.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="flex items-center mb-4">
                  <CheckCircle className="h-6 w-6 text-accent mr-3" />
                  <h3 className="font-serif text-xl font-bold">Unlimited Revisions</h3>
                </div>
                <p className="text-muted-foreground">
                  Free unlimited revisions within 14 days to ensure your complete satisfaction with the final product.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="flex items-center mb-4">
                  <CheckCircle className="h-6 w-6 text-accent mr-3" />
                  <h3 className="font-serif text-xl font-bold">On-Time Delivery</h3>
                </div>
                <p className="text-muted-foreground">
                  We guarantee timely delivery of all orders, with most papers delivered before the deadline.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="flex items-center mb-4">
                  <CheckCircle className="h-6 w-6 text-accent mr-3" />
                  <h3 className="font-serif text-xl font-bold">Money-Back Guarantee</h3>
                </div>
                <p className="text-muted-foreground">
                  Full refund if we fail to meet your requirements or deliver on time, no questions asked.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="flex items-center mb-4">
                  <CheckCircle className="h-6 w-6 text-accent mr-3" />
                  <h3 className="font-serif text-xl font-bold">Confidentiality</h3>
                </div>
                <p className="text-muted-foreground">
                  Complete privacy protection with secure systems and strict confidentiality agreements.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="flex items-center mb-4">
                  <CheckCircle className="h-6 w-6 text-accent mr-3" />
                  <h3 className="font-serif text-xl font-bold">24/7 Support</h3>
                </div>
                <p className="text-muted-foreground">
                  Round-the-clock customer support through WhatsApp, email, and live chat for immediate assistance.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl font-bold text-foreground mb-4">What Our Clients Say</h2>
            <p className="text-xl text-muted-foreground">Real feedback from satisfied students and academics</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="flex items-center mb-4">
                  <div className="flex text-yellow-400 mr-4">{"★".repeat(5)}</div>
                  <Badge className="bg-accent/10 text-accent">Verified</Badge>
                </div>
                <p className="text-muted-foreground mb-6">
                  "WriteHunters saved my semester! Their research paper was incredibly well-written and helped me
                  understand complex concepts. The writer was knowledgeable and responsive to my questions."
                </p>
                <div>
                  <div className="font-semibold">Sarah M.</div>
                  <div className="text-sm text-muted-foreground">Psychology Major, University of Nairobi</div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="flex items-center mb-4">
                  <div className="flex text-yellow-400 mr-4">{"★".repeat(5)}</div>
                  <Badge className="bg-accent/10 text-accent">Verified</Badge>
                </div>
                <p className="text-muted-foreground mb-6">
                  "Professional, reliable, and always on time. I've used WriteHunters for multiple assignments and they
                  consistently deliver high-quality work. Their editing service is particularly excellent."
                </p>
                <div>
                  <div className="font-semibold">James K.</div>
                  <div className="text-sm text-muted-foreground">MBA Student, Strathmore University</div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="flex items-center mb-4">
                  <div className="flex text-yellow-400 mr-4">{"★".repeat(5)}</div>
                  <Badge className="bg-accent/10 text-accent">Verified</Badge>
                </div>
                <p className="text-muted-foreground mb-6">
                  "The team at WriteHunters understands academic requirements perfectly. They helped me with my thesis
                  and provided valuable insights that improved my research methodology."
                </p>
                <div>
                  <div className="font-semibold">Maria L.</div>
                  <div className="text-sm text-muted-foreground">PhD Candidate, Kenyatta University</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="font-serif text-4xl font-bold mb-6">Ready to Experience Excellence?</h2>
            <p className="text-xl mb-8 opacity-90">
              Join thousands of satisfied students who trust WriteHunters for their academic success.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-white text-primary hover:bg-white/90 text-lg px-8">
                Place Your Order Today
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="text-lg px-8 border-white text-white hover:bg-white hover:text-primary bg-transparent"
              >
                Contact Our Team
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <BookOpen className="h-6 w-6" />
                <span className="font-serif text-xl font-bold">WriteHunters</span>
              </div>
              <p className="text-slate-300">
                Professional academic writing services for students and academics worldwide.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-slate-300">
                <li>
                  <Link href="/services/essay-writing">Essay Writing</Link>
                </li>
                <li>
                  <Link href="/services/research-papers">Research Papers</Link>
                </li>
                <li>
                  <Link href="/services/editing">Editing & Proofreading</Link>
                </li>
                <li>Dissertation Help</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-slate-300">
                <li>
                  <Link href="/about">About Us</Link>
                </li>
                <li>Our Writers</li>
                <li>Quality Guarantee</li>
                <li>Privacy Policy</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <div className="space-y-2 text-slate-300">
                <div>WhatsApp: +254 748 881893</div>
                <div>Email: writehunters@gmail.com</div>
              </div>
            </div>
          </div>

          <div className="border-t border-slate-700 mt-8 pt-8 text-center text-slate-300">
            <p>&copy; 2024 WriteHunters. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
