const express = require('express');
const db = require('../db');
const { v4: uuidv4 } = require('uuid');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret';

// Multer setup
const uploadsDir = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const unique = `${Date.now()}-${Math.random().toString(36).slice(2,8)}-${file.originalname}`;
    cb(null, unique);
  }
});
const upload = multer({ storage });

// Simple auth helper
function getUserFromToken(req) {
  const token = req.cookies?.wh_token;
  if (!token) return null;
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch {
    return null;
  }
}

// Price calculator
function calculatePrice(serviceType, pages) {
  let base = 0;
  switch ((serviceType || '').toLowerCase()) {
    case 'essay': base = 4; break;
    case 'research': base = 6; break;
    case 'editing': base = 3; break;
    case 'class management': base = 50; return base; // per week pricing handled separately
    default: base = 5;
  }
  return Math.max(1, pages) * base;
}

// Create an order
router.post('/create', (req, res) => {
  const user = getUserFromToken(req);
  const { serviceType, academicLevel, pages, deadline, instructions } = req.body;
  if (!serviceType || !pages) return res.status(400).json({ error: 'Missing fields' });

  const price = calculatePrice(serviceType, pages);
  const order_number = `WH-${Date.now().toString(36)}-${uuidv4().slice(0,6).toUpperCase()}`;

  const stmt = db.prepare(`INSERT INTO orders
    (order_number, user_id, service_type, academic_level, pages, price, deadline, instructions)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);

  const info = stmt.run(order_number, user?.id || null, serviceType, academicLevel, pages, price, deadline, instructions);
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(info.lastInsertRowid);

  res.json({ order });
});

// Upload file for an order
router.post('/:orderNumber/upload', upload.single('file'), (req, res) => {
  const user = getUserFromToken(req);
  if (!user) return res.status(401).json({ error: 'Unauthorized' });

  const row = db.prepare('SELECT * FROM orders WHERE order_number = ?').get(req.params.orderNumber);
  if (!row) return res.status(404).json({ error: 'Order not found' });
  if (row.user_id !== user.id && user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });

  const file = req.file;
  const stmt = db.prepare('INSERT INTO order_files (order_id, filename, original_name, mime_type, size) VALUES (?, ?, ?, ?, ?)');
  stmt.run(row.id, file.filename, file.originalname, file.mimetype, file.size);

  res.json({ ok: true, file: { filename: file.filename, original: file.originalname } });
});

// Get orders for current user
router.get('/my', (req, res) => {
  const user = getUserFromToken(req);
  if (!user) return res.status(401).json({ error: 'Unauthorized' });
  const rows = db.prepare('SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC').all(user.id);
  res.json({ orders: rows });
});

// Get order by number (public for signed-in users)
router.get('/:orderNumber', (req, res) => {
  const user = getUserFromToken(req);
  if (!user) return res.status(401).json({ error: 'Unauthorized' });
  const row = db.prepare('SELECT * FROM orders WHERE order_number = ?').get(req.params.orderNumber);
  if (!row) return res.status(404).json({ error: 'Order not found' });
  if (row.user_id !== user.id && user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
  const messages = db.prepare('SELECT * FROM messages WHERE order_id = ? ORDER BY created_at ASC').all(row.id);
  const files = db.prepare('SELECT id, filename, original_name, mime_type, size, uploaded_at FROM order_files WHERE order_id = ?').all(row.id);
  res.json({ order: row, messages, files });
});

// Add message to order (client/writer communication)
router.post('/:orderNumber/message', (req, res) => {
  const user = getUserFromToken(req);
  if (!user) return res.status(401).json({ error: 'Unauthorized' });
  const row = db.prepare('SELECT * FROM orders WHERE order_number = ?').get(req.params.orderNumber);
  if (!row) return res.status(404).json({ error: 'Order not found' });
  if (row.user_id !== user.id && user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });

  const stmt = db.prepare('INSERT INTO messages (order_id, author, body) VALUES (?, ?, ?)');
  stmt.run(row.id, user.email, req.body.body || '');
  res.json({ ok: true });
});

module.exports = router;