"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, User, Clock, MapPin } from "lucide-react"

interface Activity {
  id: string
  type: "order" | "completion" | "signup"
  customer: string
  service: string
  location: string
  timeAgo: string
}

export default function LiveActivityFeed() {
  const [activities, setActivities] = useState<Activity[]>([
    {
      id: "1",
      type: "order",
      customer: "Sarah M.",
      service: "Research Paper",
      location: "Nairobi, Kenya",
      timeAgo: "2 minutes ago",
    },
    {
      id: "2",
      type: "completion",
      customer: "James K.",
      service: "Essay Writing",
      location: "Mombasa, Kenya",
      timeAgo: "5 minutes ago",
    },
    {
      id: "3",
      type: "signup",
      customer: "Maria L.",
      service: "Class Management",
      location: "Kisumu, Kenya",
      timeAgo: "8 minutes ago",
    },
  ])

  useEffect(() => {
    const interval = setInterval(() => {
      const newActivity: Activity = {
        id: Date.now().toString(),
        type: Math.random() > 0.6 ? "order" : Math.random() > 0.5 ? "completion" : "signup",
        customer: ["Alex K.", "Emma S.", "David M.", "Lisa R.", "John D.", "Anna P."][Math.floor(Math.random() * 6)],
        service: ["Essay Writing", "Research Paper", "Editing", "Class Management"][Math.floor(Math.random() * 4)],
        location: ["Nairobi, Kenya", "Mombasa, Kenya", "Kisumu, Kenya", "Eldoret, Kenya"][
          Math.floor(Math.random() * 4)
        ],
        timeAgo: "Just now",
      }

      setActivities((prev) => [newActivity, ...prev.slice(0, 4)])
    }, 15000) // New activity every 15 seconds

    return () => clearInterval(interval)
  }, [])

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "order":
        return <CheckCircle className="h-4 w-4 text-coral" />
      case "completion":
        return <CheckCircle className="h-4 w-4 text-success" />
      default:
        return <User className="h-4 w-4 text-purple" />
    }
  }

  const getActivityText = (activity: Activity) => {
    switch (activity.type) {
      case "order":
        return `${activity.customer} just ordered ${activity.service}`
      case "completion":
        return `${activity.customer} received their completed ${activity.service}`
      default:
        return `${activity.customer} signed up for ${activity.service}`
    }
  }

  const getActivityBadge = (type: string) => {
    switch (type) {
      case "order":
        return <Badge className="bg-coral/10 text-coral border-coral/20">New Order</Badge>
      case "completion":
        return <Badge className="bg-success/10 text-success border-success/20">Completed</Badge>
      default:
        return <Badge className="bg-purple/10 text-purple border-purple/20">New Customer</Badge>
    }
  }

  return (
    <Card className="card-elevated">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="font-semibold text-foreground">Live Activity</h3>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
            <span className="text-sm text-success font-medium">Live</span>
          </div>
        </div>

        <div className="space-y-4">
          {activities.map((activity) => (
            <div
              key={activity.id}
              className="flex items-start space-x-3 p-3 rounded-lg bg-gradient-to-r from-slate-50 to-blue-50 hover:from-slate-100 hover:to-blue-100 transition-colors"
            >
              <div className="flex-shrink-0 mt-1">{getActivityIcon(activity.type)}</div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <p className="text-sm font-medium text-foreground">{getActivityText(activity)}</p>
                  {getActivityBadge(activity.type)}
                </div>
                <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                  <div className="flex items-center space-x-1">
                    <MapPin className="h-3 w-3" />
                    <span>{activity.location}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Clock className="h-3 w-3" />
                    <span>{activity.timeAgo}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
