"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BookOpen,
  User,
  Star,
  MessageSquare,
  FileText,
  Settings,
  LogOut,
  Send,
  Clock,
  CheckCircle,
  AlertCircle,
} from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import AuthGuard from "@/components/AuthGuard"
import { useAuth } from "@/hooks/useAuth"

function DashboardContent() {
  const { user, logout } = useAuth()
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("overview")
  const [reviewForm, setReviewForm] = useState({
    rating: 5,
    service: "",
    comment: "",
    recommend: true,
  })
  const [complaintForm, setComplaintForm] = useState({
    subject: "",
    priority: "medium",
    description: "",
    orderReference: "",
  })

  const handleLogout = () => {
    logout()
    router.push("/")
  }

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // In a real app, this would submit to an API
    alert("Review submitted successfully! Thank you for your feedback.")
    setReviewForm({
      rating: 5,
      service: "",
      comment: "",
      recommend: true,
    })
  }

  const handleComplaintSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // In a real app, this would submit to an API
    alert("Complaint submitted successfully! We'll get back to you within 24 hours.")
    setComplaintForm({
      subject: "",
      priority: "medium",
      description: "",
      orderReference: "",
    })
  }

  // Mock data for orders
  const orders = [
    {
      id: "WH-2024-001",
      service: "Research Paper",
      status: "completed",
      date: "2024-01-15",
      amount: "$45.00",
    },
    {
      id: "WH-2024-002",
      service: "Essay Writing",
      status: "in-progress",
      date: "2024-01-20",
      amount: "$32.00",
    },
    {
      id: "WH-2024-003",
      service: "Editing & Proofreading",
      status: "pending",
      date: "2024-01-22",
      amount: "$28.00",
    },
  ]

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="h-4 w-4 text-success" />
      case "in-progress":
        return <Clock className="h-4 w-4 text-warning" />
      case "pending":
        return <AlertCircle className="h-4 w-4 text-coral" />
      default:
        return <Clock className="h-4 w-4 text-muted-foreground" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-success/10 text-success border-success/20"
      case "in-progress":
        return "bg-warning/10 text-warning border-warning/20"
      case "pending":
        return "bg-coral/10 text-coral border-coral/20"
      default:
        return "bg-muted/10 text-muted-foreground border-muted/20"
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <BookOpen className="h-8 w-8 text-primary" />
              <span className="font-serif text-2xl font-bold text-primary">WriteHunters</span>
            </Link>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="font-medium text-foreground">Welcome, {user?.name}</p>
                <p className="text-sm text-muted-foreground">{user?.email}</p>
              </div>
              <Button variant="outline" onClick={handleLogout} className="flex items-center space-x-2 bg-transparent">
                <LogOut className="h-4 w-4" />
                <span>Logout</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Dashboard Content */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <div className="mb-8">
            <h1 className="font-serif text-3xl font-bold text-foreground mb-2">Client Dashboard</h1>
            <p className="text-muted-foreground">Manage your orders, submit reviews, and get support</p>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-5 mb-8">
              <TabsTrigger value="overview" className="flex items-center space-x-2">
                <User className="h-4 w-4" />
                <span>Overview</span>
              </TabsTrigger>
              <TabsTrigger value="orders" className="flex items-center space-x-2">
                <FileText className="h-4 w-4" />
                <span>My Orders</span>
              </TabsTrigger>
              <TabsTrigger value="reviews" className="flex items-center space-x-2">
                <Star className="h-4 w-4" />
                <span>Submit Review</span>
              </TabsTrigger>
              <TabsTrigger value="complaints" className="flex items-center space-x-2">
                <MessageSquare className="h-4 w-4" />
                <span>Complaints</span>
              </TabsTrigger>
              <TabsTrigger value="profile" className="flex items-center space-x-2">
                <Settings className="h-4 w-4" />
                <span>Profile</span>
              </TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-6">
              <div className="grid md:grid-cols-3 gap-6">
                <Card className="card-elevated">
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gradient-primary rounded-lg flex items-center justify-center">
                        <FileText className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-primary">3</div>
                        <div className="text-muted-foreground">Total Orders</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="card-elevated">
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gradient-success rounded-lg flex items-center justify-center">
                        <CheckCircle className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-success">1</div>
                        <div className="text-muted-foreground">Completed</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="card-elevated">
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gradient-warning rounded-lg flex items-center justify-center">
                        <Clock className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-warning">2</div>
                        <div className="text-muted-foreground">In Progress</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card className="card-elevated">
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-4 p-4 bg-success/5 rounded-lg border border-success/20">
                      <CheckCircle className="h-5 w-5 text-success" />
                      <div className="flex-1">
                        <p className="font-medium">Order WH-2024-001 completed</p>
                        <p className="text-sm text-muted-foreground">Research Paper - Delivered on time</p>
                      </div>
                      <Badge className="bg-success/10 text-success border-success/20">Completed</Badge>
                    </div>
                    <div className="flex items-center space-x-4 p-4 bg-warning/5 rounded-lg border border-warning/20">
                      <Clock className="h-5 w-5 text-warning" />
                      <div className="flex-1">
                        <p className="font-medium">Order WH-2024-002 in progress</p>
                        <p className="text-sm text-muted-foreground">Essay Writing - Expected delivery: Jan 25</p>
                      </div>
                      <Badge className="bg-warning/10 text-warning border-warning/20">In Progress</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Orders Tab */}
            <TabsContent value="orders" className="space-y-6">
              <Card className="card-elevated">
                <CardHeader>
                  <CardTitle>Order History</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {orders.map((order) => (
                      <div key={order.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-4">
                          {getStatusIcon(order.status)}
                          <div>
                            <p className="font-medium">{order.id}</p>
                            <p className="text-sm text-muted-foreground">{order.service}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">{order.amount}</p>
                          <p className="text-sm text-muted-foreground">{order.date}</p>
                        </div>
                        <Badge className={getStatusColor(order.status)}>{order.status}</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Reviews Tab */}
            <TabsContent value="reviews" className="space-y-6">
              <Card className="card-elevated">
                <CardHeader>
                  <CardTitle>Submit a Review</CardTitle>
                  <p className="text-muted-foreground">
                    Share your experience with WriteHunters to help us improve our services
                  </p>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleReviewSubmit} className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium mb-2">Service Type</label>
                      <select
                        value={reviewForm.service}
                        onChange={(e) => setReviewForm({ ...reviewForm, service: e.target.value })}
                        className="form-select"
                        required
                      >
                        <option value="">Select service</option>
                        <option value="essay-writing">Essay Writing</option>
                        <option value="research-paper">Research Paper</option>
                        <option value="editing">Editing & Proofreading</option>
                        <option value="class-management">Class Management</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Rating</label>
                      <div className="flex items-center space-x-2">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            key={star}
                            type="button"
                            onClick={() => setReviewForm({ ...reviewForm, rating: star })}
                            className={`text-2xl ${
                              star <= reviewForm.rating ? "text-warning" : "text-gray-300"
                            } hover:text-warning transition-colors`}
                          >
                            ★
                          </button>
                        ))}
                        <span className="ml-2 text-sm text-muted-foreground">{reviewForm.rating} out of 5 stars</span>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Your Review</label>
                      <textarea
                        value={reviewForm.comment}
                        onChange={(e) => setReviewForm({ ...reviewForm, comment: e.target.value })}
                        placeholder="Tell us about your experience with our service..."
                        rows={4}
                        className="form-textarea"
                        required
                      />
                    </div>

                    <div className="flex items-center space-x-3">
                      <input
                        type="checkbox"
                        checked={reviewForm.recommend}
                        onChange={(e) => setReviewForm({ ...reviewForm, recommend: e.target.checked })}
                        className="rounded border-gray-300 text-primary focus:ring-primary"
                      />
                      <label className="text-sm">I would recommend WriteHunters to others</label>
                    </div>

                    <Button type="submit" className="btn-success">
                      <Send className="h-4 w-4 mr-2" />
                      Submit Review
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Complaints Tab */}
            <TabsContent value="complaints" className="space-y-6">
              <Card className="card-elevated">
                <CardHeader>
                  <CardTitle>Submit a Complaint</CardTitle>
                  <p className="text-muted-foreground">
                    We take all feedback seriously. Please provide details about your concern.
                  </p>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleComplaintSubmit} className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium mb-2">Order Reference (Optional)</label>
                      <input
                        type="text"
                        value={complaintForm.orderReference}
                        onChange={(e) => setComplaintForm({ ...complaintForm, orderReference: e.target.value })}
                        placeholder="e.g., WH-2024-001"
                        className="form-input"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Subject</label>
                      <input
                        type="text"
                        value={complaintForm.subject}
                        onChange={(e) => setComplaintForm({ ...complaintForm, subject: e.target.value })}
                        placeholder="Brief description of the issue"
                        className="form-input"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Priority</label>
                      <select
                        value={complaintForm.priority}
                        onChange={(e) => setComplaintForm({ ...complaintForm, priority: e.target.value })}
                        className="form-select"
                      >
                        <option value="low">Low - General feedback</option>
                        <option value="medium">Medium - Service issue</option>
                        <option value="high">High - Urgent matter</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Description</label>
                      <textarea
                        value={complaintForm.description}
                        onChange={(e) => setComplaintForm({ ...complaintForm, description: e.target.value })}
                        placeholder="Please provide detailed information about your complaint..."
                        rows={5}
                        className="form-textarea"
                        required
                      />
                    </div>

                    <div className="p-4 bg-coral/5 border border-coral/20 rounded-lg">
                      <div className="flex items-start space-x-3">
                        <AlertCircle className="h-5 w-5 text-coral mt-0.5" />
                        <div>
                          <h4 className="font-medium text-coral mb-1">Response Time</h4>
                          <p className="text-sm text-coral/80">
                            We aim to respond to all complaints within 24 hours. High priority issues will be addressed
                            immediately.
                          </p>
                        </div>
                      </div>
                    </div>

                    <Button type="submit" className="btn-coral">
                      <Send className="h-4 w-4 mr-2" />
                      Submit Complaint
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Profile Tab */}
            <TabsContent value="profile" className="space-y-6">
              <Card className="card-elevated">
                <CardHeader>
                  <CardTitle>Profile Information</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-2">Full Name</label>
                        <input type="text" defaultValue={user?.name} className="form-input" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">Email Address</label>
                        <input type="email" defaultValue={user?.email} className="form-input" />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Phone Number</label>
                      <input type="tel" defaultValue={user?.phone} className="form-input" />
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Preferred Communication</label>
                      <select className="form-select">
                        <option value="email">Email</option>
                        <option value="whatsapp">WhatsApp</option>
                        <option value="both">Both Email and WhatsApp</option>
                      </select>
                    </div>

                    <div className="pt-4 border-t">
                      <h3 className="font-medium mb-4">Account Security</h3>
                      <div className="space-y-4">
                        <Button variant="outline" className="w-full md:w-auto bg-transparent">
                          Change Password
                        </Button>
                        <Button
                          variant="outline"
                          className="w-full md:w-auto text-red-600 border-red-200 hover:bg-red-50 bg-transparent"
                        >
                          Delete Account
                        </Button>
                      </div>
                    </div>

                    <Button className="btn-primary">
                      <Settings className="h-4 w-4 mr-2" />
                      Update Profile
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </section>
    </div>
  )
}

export default function ClientDashboardPage() {
  return (
    <AuthGuard>
      <DashboardContent />
    </AuthGuard>
  )
}
