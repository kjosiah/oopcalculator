"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Clock, Flame, Users, ArrowRight } from "lucide-react"

export default function UrgencyBanner() {
  const [ordersToday, setOrdersToday] = useState(47)
  const [spotsLeft, setSpotsLeft] = useState(8)

  useEffect(() => {
    // Simulate real-time updates
    const interval = setInterval(() => {
      if (Math.random() > 0.7) {
        setOrdersToday((prev) => prev + 1)
        setSpotsLeft((prev) => Math.max(1, prev - 1))
      }
    }, 30000) // Update every 30 seconds

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white py-3 px-6">
      <div className="container mx-auto">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-2">
              <Flame className="h-5 w-5 animate-pulse" />
              <Badge className="bg-white/20 text-white border-white/30">High Demand</Badge>
            </div>

            <div className="flex items-center space-x-4 text-sm">
              <div className="flex items-center space-x-1">
                <Users className="h-4 w-4" />
                <span className="font-semibold">{ordersToday} orders</span>
                <span className="opacity-90">placed today</span>
              </div>

              <div className="hidden md:block w-px h-4 bg-white/30"></div>

              <div className="hidden md:flex items-center space-x-1">
                <Clock className="h-4 w-4" />
                <span className="font-semibold">Only {spotsLeft} spots</span>
                <span className="opacity-90">left for urgent orders</span>
              </div>
            </div>
          </div>

          <Button size="sm" className="bg-white text-orange-600 hover:bg-gray-100 font-semibold">
            <a href="/order" className="flex items-center space-x-1">
              <span>Order Now</span>
              <ArrowRight className="h-3 w-3" />
            </a>
          </Button>
        </div>
      </div>
    </div>
  )
}
