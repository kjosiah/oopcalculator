import React, { useState } from 'react'
import axios from 'axios'
import ThemeToggle from './components/ThemeToggle'

function Header() {
  return (
    <header className="site-header">
      <div className="container">
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <h1>WriteHunters</h1>
          <nav style={{ display: 'flex', gap: 12 }}>
            <a href="#services">Services</a>
            <a href="#order">Order Now</a>
            <a href="#contact">Contact</a>
            <a href="/legal/privacy.html" target="_blank" rel="noreferrer">Privacy</a>
            <a href="/admin" className="admin-link">Admin</a>
          </nav>
        </div>

        <div className="right-controls">
          {/* Theme toggle sits in the header right side */}
          <ThemeToggle />
        </div>
      </div>
    </header>
  )
}

function OrderForm() {
  const [form, setForm] = useState({ serviceType: 'Essay', pages: 1, academicLevel: 'Undergraduate', deadline: '', instructions: '' })
  const [price, setPrice] = useState(0)
  const [createdOrder, setCreatedOrder] = useState(null)
  const [file, setFile] = useState(null)
  const [uploading, setUploading] = useState(false)
  const [payloaded, setPayloaded] = useState(false)

  const calcPrice = () => {
    const base = form.serviceType === 'Research' ? 6 : form.serviceType === 'Editing' ? 3 : form.serviceType === 'Class Management' ? 50 : 4
    if (form.serviceType === 'Class Management') return base
    return Math.max(1, Number(form.pages)) * base
  }

  React.useEffect(()=> setPrice(calcPrice()), [form])

  const submit = async (e) => {
    e.preventDefault()
    try {
      const res = await axios.post('/api/orders/create', form, { withCredentials: true })
      setCreatedOrder(res.data.order)
    } catch (err) {
      alert('Error creating order: ' + (err.response?.data?.error || err.message))
    }
  }

  const uploadFile = async (e) => {
    e.preventDefault()
    if (!file || !createdOrder) return alert('Select a file and create order first')
    setUploading(true)
    try {
      const fd = new FormData()
      fd.append('file', file)
      await axios.post(`/api/orders/${createdOrder.order_number}/upload`, fd, { withCredentials: true, headers: { 'Content-Type': 'multipart/form-data' } })
      alert('Uploaded')
    } catch (err) {
      alert('Upload failed')
    } finally {
      setUploading(false)
    }
  }

  React.useEffect(() => {
    if (!createdOrder || payloaded) return
    const script = document.createElement('script')
    const clientId = import.meta.env.VITE_PAYPAL_CLIENT_ID || ''
    const cid = clientId || 'sb'
    script.src = `https://www.paypal.com/sdk/js?client-id=${cid}&currency=USD`
    script.async = true
    script.onload = () => {
      if (!window.paypal) return
      window.paypal.Buttons({
        createOrder: async () => {
          const res = await fetch('/api/payments/create-paypal-order', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ orderNumber: createdOrder.order_number })
          })
          const data = await res.json()
          if (!res.ok) throw new Error(data?.error || 'Failed to create PayPal order')
          return data.id
        },
        onApprove: async (data, actions) => {
          const res = await fetch('/api/payments/capture-paypal-order', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ orderID: data.orderID || data.orderID, orderNumber: createdOrder.order_number })
          })
          const capture = await res.json()
          if (res.ok) {
            alert('Payment captured and order marked paid.')
            setPayloaded(true)
          } else {
            alert('Capture failed: ' + JSON.stringify(capture))
          }
        },
        onError: (err) => {
          console.error('PayPal error', err)
          alert('PayPal error')
        }
      }).render('#paypal-button-container')
    }
    document.body.appendChild(script)
  }, [createdOrder, payloaded])

  return (
    <section id="order" className="order-section container">
      <h2>Place an Order</h2>
      <form onSubmit={submit}>
        <label>Service
          <select value={form.serviceType} onChange={e => setForm({...form, serviceType: e.target.value})}>
            <option>Essay</option>
            <option>Research</option>
            <option>Editing</option>
            <option>Class Management</option>
          </select>
        </label>
        <label>Academic Level
          <select value={form.academicLevel} onChange={e => setForm({...form, academicLevel: e.target.value})}>
            <option>Undergraduate</option>
            <option>Masters</option>
            <option>PhD</option>
          </select>
        </label>
        <label>Pages
          <input type="number" value={form.pages} min="1" onChange={e => setForm({...form, pages: e.target.value})} />
        </label>
        <label>Deadline
          <input type="date" value={form.deadline} onChange={e => setForm({...form, deadline: e.target.value})} />
        </label>
        <label>Instructions
          <textarea value={form.instructions} onChange={e => setForm({...form, instructions: e.target.value})} />
        </label>

        <div className="price">Estimated price: ${price}</div>

        <button type="submit" className="btn primary">Create Order</button>

        {createdOrder && (
          <div className="order-created">
            <p>Order created: <strong>{createdOrder.order_number}</strong></p>
            <p>Price: ${createdOrder.price}</p>

            <div style={{ marginTop: 12 }}>
              <h4>Upload File (drafts / attachments)</h4>
              <input type="file" onChange={e => setFile(e.target.files?.[0] || null)} />
              <button onClick={uploadFile} disabled={uploading} className="btn" style={{ marginLeft: 8 }}>{uploading ? 'Uploading...' : 'Upload'}</button>
            </div>

            <div style={{ marginTop: 16 }}>
              <h4>Pay with PayPal</h4>
              <div id="paypal-button-container"></div>
            </div>
          </div>
        )}
      </form>
    </section>
  )
}

function Services() {
  return (
    <section id="services" className="container services">
      <h2>Services</h2>
      <ul>
        <li>Essay Writing — From $4/page</li>
        <li>Research Papers — From $6/page</li>
        <li>Editing & Proofreading — From $3/page</li>
        <li>Class Management — From $50/week</li>
      </ul>
    </section>
  )
}

function Contact() {
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: ''})
  const submit = async (e) => {
    e.preventDefault()
    try {
      await axios.post('/api/contact', form)
      alert('Message sent. We will respond to writehunters@gmail.com')
    } catch (err) {
      alert('Error sending message')
    }
  }
  return (
    <section id="contact" className="container">
      <h2>Contact Us</h2>
      <form onSubmit={submit}>
        <label>Name<input value={form.name} onChange={e => setForm({...form, name: e.target.value})} /></label>
        <label>Email<input value={form.email} onChange={e => setForm({...form, email: e.target.value})} /></label>
        <label>Subject<input value={form.subject} onChange={e => setForm({...form, subject: e.target.value})} /></label>
        <label>Message<textarea value={form.message} onChange={e => setForm({...form, message: e.target.value})} /></label>
        <button className="btn">Send Message</button>
      </form>

      <div className="social">
        <a href="https://www.facebook.com/profile.php?id=61577361405554" target="_blank" rel="noreferrer">Facebook</a>
        <a href="https://www.instagram.com/writehunters/" target="_blank" rel="noreferrer">Instagram</a>
        <a className="whatsapp" href="https://wa.me/254748881893" target="_blank" rel="noreferrer">Chat on WhatsApp</a>
      </div>
    </section>
  )
}

function Footer() {
  return (
    <footer className="site-footer">
      <div className="container">
        <p>&copy; {new Date().getFullYear()} WriteHunters — Integrity · Excellence · Support</p>
      </div>
    </footer>
  )
}

export default function App() {
  return (
    <div>
      <Header />
      <main>
        <section className="hero container">
          <h2>Your academic success partner</h2>
          <p>High-quality academic writing, editing and class management support — secure, confidential, affordable.</p>
          <a href="#order" className="btn primary">Order Now</a>
          <a href="#contact" className="btn">Contact Us</a>
        </section>

        <Services />
        <OrderForm />
        <Contact />
      </main>
      <Footer />
    </div>
  )
}