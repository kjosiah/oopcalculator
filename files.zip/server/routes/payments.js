const express = require('express');
const db = require('../db');
const fetch = global.fetch; // Node 18+ has global fetch
const dotenv = require('dotenv');
dotenv.config();

const router = express.Router();

const PAYPAL_CLIENT_ID = process.env.PAYPAL_CLIENT_ID;
const PAYPAL_CLIENT_SECRET = process.env.PAYPAL_CLIENT_SECRET;
const PAYPAL_WEBHOOK_ID = process.env.PAYPAL_WEBHOOK_ID; // configure in your PayPal app
const PAYPAL_API = process.env.NODE_ENV === 'production' ? 'https://api-m.paypal.com' : 'https://api-m.sandbox.paypal.com';

// get access token
async function getAccessToken() {
  const auth = Buffer.from(`${PAYPAL_CLIENT_ID}:${PAYPAL_CLIENT_SECRET}`).toString('base64');
  const res = await fetch(`${PAYPAL_API}/v1/oauth2/token`, {
    method: 'POST',
    headers: {
      Authorization: `Basic ${auth}`,
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: 'grant_type=client_credentials'
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error('Failed to get PayPal token: ' + text);
  }
  const data = await res.json();
  return data.access_token;
}

// Create PayPal order for an existing orderNumber
router.post('/create-paypal-order', async (req, res) => {
  try {
    const { orderNumber } = req.body;
    if (!orderNumber) return res.status(400).json({ error: 'orderNumber required' });
    const order = db.prepare('SELECT * FROM orders WHERE order_number = ?').get(orderNumber);
    if (!order) return res.status(404).json({ error: 'Order not found' });

    const accessToken = await getAccessToken();
    const body = {
      intent: 'CAPTURE',
      purchase_units: [{
        reference_id: order.order_number,
        amount: {
          currency_code: 'USD',
          value: String(Number(order.price).toFixed(2))
        }
      }]
    };

    const resp = await fetch(`${PAYPAL_API}/v2/checkout/orders`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    });

    const data = await resp.json();
    if (!resp.ok) {
      return res.status(500).json({ error: 'Failed to create PayPal order', details: data });
    }
    res.json({ id: data.id });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Capture PayPal order after approval
router.post('/capture-paypal-order', async (req, res) => {
  try {
    const { orderID, orderNumber } = req.body;
    if (!orderID || !orderNumber) return res.status(400).json({ error: 'orderID and orderNumber required' });

    const accessToken = await getAccessToken();
    const resp = await fetch(`${PAYPAL_API}/v2/checkout/orders/${orderID}/capture`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      }
    });
    const data = await resp.json();
    if (!resp.ok) {
      return res.status(500).json({ error: 'Failed to capture PayPal order', details: data });
    }

    // Find capture id and update order as paid
    const capture = (data.purchase_units?.[0]?.payments?.captures?.[0]) || null;
    const captureId = capture ? capture.id : (data.id || null);

    const stmt = db.prepare('UPDATE orders SET paid = 1, payment_id = ?, status = ?, updated_at = CURRENT_TIMESTAMP WHERE order_number = ?');
    stmt.run(captureId, 'paid', orderNumber);

    res.json({ ok: true, capture: data });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Webhook endpoint to verify PayPal events (e.g., PAYMENT.CAPTURE.COMPLETED)
router.post('/webhook', express.raw({ type: '*/*' }), async (req, res) => {
  try {
    // Extract PayPal headers
    const transmissionId = req.headers['paypal-transmission-id'];
    const transmissionTime = req.headers['paypal-transmission-time'];
    const certUrl = req.headers['paypal-cert-url'];
    const authAlgo = req.headers['paypal-auth-algo'];
    const transmissionSig = req.headers['paypal-transmission-sig'];
    const webhookId = PAYPAL_WEBHOOK_ID;

    if (!transmissionId || !transmissionTime || !certUrl || !authAlgo || !transmissionSig || !webhookId) {
      console.warn('Missing PayPal webhook headers or webhook id');
      return res.status(400).end();
    }

    const accessToken = await getAccessToken();

    const verifyPayload = {
      auth_algo: authAlgo,
      cert_url: certUrl,
      transmission_id: transmissionId,
      transmission_sig: transmissionSig,
      transmission_time: transmissionTime,
      webhook_id: webhookId,
      webhook_event: JSON.parse(req.body.toString())
    };

    const verifyResp = await fetch(`${PAYPAL_API}/v1/notifications/verify-webhook-signature`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(verifyPayload)
    });

    const verifyData = await verifyResp.json();
    if (!verifyResp.ok || verifyData.verification_status !== 'SUCCESS') {
      console.warn('Webhook verification failed', verifyData);
      return res.status(400).json({ verified: false, details: verifyData });
    }

    const event = verifyPayload.webhook_event;
    // handle payment capture completed events
    if (event.event_type === 'PAYMENT.CAPTURE.COMPLETED' || event.event_type === 'PAYMENT.CAPTURE.DENIED') {
      const resource = event.resource;
      const captureId = resource.id;
      const referenceId = resource.supplementary_data?.related_ids?.order_id || resource.invoice_id || resource.custom_id || null;
      // If we have reference id mapping to our order_number, update order as paid
      // The best mapping is to use purchase_unit reference_id which PayPal sends in order creation -> in some events it's available
      const orderRef = resource.invoice_id || (resource?.supplementary_data?.related_ids?.order_id) || null;

      // Try to find an order by payment_id match or by reference if provided
      if (referenceId) {
        // update any order that matches referenceId
        const stmt = db.prepare('UPDATE orders SET paid = 1, payment_id = ?, status = ?, updated_at = CURRENT_TIMESTAMP WHERE order_number = ?');
        stmt.run(captureId, 'paid', referenceId);
      }
    }

    res.json({ verified: true });
  } catch (err) {
    console.error('Webhook processing error', err);
    res.status(500).end();
  }
});

module.exports = router;