# WriteHunters — Academic Writing Website (Starter)

Overview
- Modern responsive frontend (React + Vite) and secure Node/Express backend.
- Features implemented:
  - Responsive UI with order form, price calculator, order dashboard, contact form, legal pages.
  - Secure registration & login (bcrypt + JWT in httpOnly cookies).
  - Order creation with unique Order Number generation and server-side price calculation.
  - PayPal integration points (uses your merchant ID PA5B4RAVDET9Y in client).
  - Contact form that sends email to writehunters@gmail.com (via SMTP nodemailer).
  - Admin route for site management (set via env).
  - WhatsApp quick chat button (opens chat but does not display the number).
- Excluded: Blog (as requested).

Quick start (development)
1. Copy environment variables:
   cp .env.example .env
   Fill in values for PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET, SMTP_*, JWT_SECRET, ADMIN_PASSWORD, and SESSION_COOKIE_SECRET.

2. Install dependencies and run:
   npm install
   npm run dev

3. Open http://localhost:5173 for the frontend (Vite) and API runs on http://localhost:4000

Important production notes
- Serve through HTTPS (TLS/SSL). If you deploy behind a load balancer / reverse proxy, terminate TLS there.
- Fill PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET in .env for server-side PayPal flows.
- Use a real SMTP provider for sending contact emails.
- Replace ADMIN_PASSWORD with a secure secret and manage admin accounts in DB for multiple admins.

Admin link
- Admin UI is available at: /admin
- Set ADMIN_PASSWORD in your .env to manage site via this route (or create admin user accounts in the DB).

Project layout (key)
- server/: Express backend
- client/: React frontend (Vite)
- legal/: Static legal pages (Privacy, Cookies, Terms)