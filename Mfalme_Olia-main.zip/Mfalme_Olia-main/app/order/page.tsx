"use client"

import type React from "react"
import { MessageCircle } from "lucide-react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Upload, Calculator, CreditCard, Building2, FileText, Shield, CheckCircle } from "lucide-react"
import Link from "next/link"

export default function OrderPage() {
  const [pages, setPages] = useState(1)
  const [deadline, setDeadline] = useState("")
  const [academicLevel, setAcademicLevel] = useState("")
  const [serviceType, setServiceType] = useState("")
  const [files, setFiles] = useState<File[]>([])

  const pricePerPage = 4
  const totalPrice = pages * pricePerPage

  // Generate unique order number
  const generateOrderNumber = () => {
    const timestamp = Date.now().toString().slice(-6)
    const random = Math.floor(Math.random() * 1000)
      .toString()
      .padStart(3, "0")
    return `WH${timestamp}${random}`
  }

  // Calculate urgency multiplier
  const getUrgencyMultiplier = (deadline: string) => {
    const hours = Number.parseInt(deadline)
    if (hours <= 6) return 2.0
    if (hours <= 12) return 1.8
    if (hours <= 24) return 1.5
    if (hours <= 48) return 1.3
    if (hours <= 72) return 1.2
    return 1.0
  }

  const urgencyMultiplier = deadline ? getUrgencyMultiplier(deadline) : 1.0
  const finalPrice = Math.round(totalPrice * urgencyMultiplier)

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles(Array.from(e.target.files))
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const orderNumber = generateOrderNumber()
    const orderData = {
      orderNumber,
      pages,
      deadline,
      academicLevel,
      serviceType,
      totalPrice: finalPrice,
      files: files.length,
      timestamp: new Date().toISOString(),
      status: "pending",
    }
    localStorage.setItem("orderData", JSON.stringify(orderData))
    localStorage.setItem("currentOrderNumber", orderNumber)
    window.location.href = "/payment"
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <BookOpen className="h-8 w-8 text-primary" />
              <span className="font-serif text-2xl font-bold text-primary">WriteHunters</span>
            </Link>
            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-foreground hover:text-primary transition-colors">
                Home
              </Link>
              <Link href="/services" className="text-foreground hover:text-primary transition-colors">
                Services
              </Link>
              <Link href="/about" className="text-foreground hover:text-primary transition-colors">
                About
              </Link>
              <Link href="/blog" className="text-foreground hover:text-primary transition-colors">
                Blog
              </Link>
              <Link href="/contact" className="text-foreground hover:text-primary transition-colors">
                Contact
              </Link>
            </nav>
            <Link href="/order">
              <Button className="bg-coral hover:bg-coral/90">Place Your Order</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Order Form */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <div className="flex justify-center space-x-4 mb-4">
                <Badge className="bg-coral/10 text-coral border-coral/20">Place Your Order</Badge>
                <Badge className="bg-success/10 text-success border-success/20">100% Human Written</Badge>
              </div>
              <h1 className="font-serif text-4xl font-bold text-foreground mb-4">Get Your Academic Paper Written</h1>
              <p className="text-xl text-muted-foreground">
                Fill out the form below and get an instant quote. Our expert writers create 100% original, human-written
                content!
              </p>
            </div>

            <div className="grid lg:grid-cols-3 gap-8">
              {/* Order Form */}
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <FileText className="h-5 w-5 mr-2" />
                      Order Details
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div className="grid md:grid-cols-2 gap-6">
                        <div>
                          <Label htmlFor="serviceType">Service Type *</Label>
                          <Select value={serviceType} onValueChange={setServiceType} required>
                            <SelectTrigger>
                              <SelectValue placeholder="Select service type" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="essay">Essay Writing</SelectItem>
                              <SelectItem value="research">Research Paper</SelectItem>
                              <SelectItem value="dissertation">Dissertation</SelectItem>
                              <SelectItem value="thesis">Thesis</SelectItem>
                              <SelectItem value="coursework">Coursework</SelectItem>
                              <SelectItem value="assignment">Assignment</SelectItem>
                              <SelectItem value="editing">Editing & Proofreading</SelectItem>
                              <SelectItem value="class-management">Class Management</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <Label htmlFor="academicLevel">Academic Level *</Label>
                          <Select value={academicLevel} onValueChange={setAcademicLevel} required>
                            <SelectTrigger>
                              <SelectValue placeholder="Select academic level" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="high-school">High School</SelectItem>
                              <SelectItem value="undergraduate">Undergraduate</SelectItem>
                              <SelectItem value="masters">Master's</SelectItem>
                              <SelectItem value="phd">PhD</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="grid md:grid-cols-2 gap-6">
                        <div>
                          <Label htmlFor="pages">Number of Pages *</Label>
                          <div className="flex items-center space-x-2">
                            <Input
                              type="number"
                              min="1"
                              max="500"
                              value={pages}
                              onChange={(e) => setPages(Number.parseInt(e.target.value) || 1)}
                              required
                            />
                            <span className="text-sm text-muted-foreground">pages</span>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">1 page = 275 words</p>
                        </div>

                        <div>
                          <Label htmlFor="deadline">Deadline *</Label>
                          <Select value={deadline} onValueChange={setDeadline} required>
                            <SelectTrigger>
                              <SelectValue placeholder="Select deadline" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="6">6 hours (+100%)</SelectItem>
                              <SelectItem value="12">12 hours (+80%)</SelectItem>
                              <SelectItem value="24">24 hours (+50%)</SelectItem>
                              <SelectItem value="48">2 days (+30%)</SelectItem>
                              <SelectItem value="72">3 days (+20%)</SelectItem>
                              <SelectItem value="168">1 week (Standard)</SelectItem>
                              <SelectItem value="336">2 weeks (Standard)</SelectItem>
                              <SelectItem value="720">1 month (Standard)</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="subject">Subject/Topic *</Label>
                        <Input placeholder="Enter your subject or topic" required />
                      </div>

                      <div>
                        <Label htmlFor="instructions">Paper Instructions *</Label>
                        <Textarea
                          placeholder="Provide detailed instructions for your paper including requirements, format, sources, etc."
                          rows={6}
                          required
                        />
                      </div>

                      <div>
                        <Label htmlFor="sources">Number of Sources</Label>
                        <Input type="number" min="0" placeholder="How many sources do you need?" />
                      </div>

                      <div>
                        <Label htmlFor="format">Citation Format</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Select citation format" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="apa">APA</SelectItem>
                            <SelectItem value="mla">MLA</SelectItem>
                            <SelectItem value="chicago">Chicago</SelectItem>
                            <SelectItem value="harvard">Harvard</SelectItem>
                            <SelectItem value="ieee">IEEE</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      {/* File Upload Section */}
                      <div>
                        <Label htmlFor="files">Attach Files (Optional)</Label>
                        <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-primary transition-colors">
                          <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                          <p className="text-sm text-muted-foreground mb-2">
                            Upload any relevant files (instructions, samples, resources)
                          </p>
                          <Input
                            type="file"
                            multiple
                            onChange={handleFileUpload}
                            className="hidden"
                            id="file-upload"
                            accept=".pdf,.doc,.docx,.txt,.jpg,.png"
                          />
                          <Label htmlFor="file-upload" className="cursor-pointer">
                            <Button type="button" variant="outline" className="pointer-events-none bg-transparent">
                              Choose Files
                            </Button>
                          </Label>
                          <p className="text-xs text-muted-foreground mt-2">
                            Supported formats: PDF, DOC, DOCX, TXT, JPG, PNG (Max 10MB each)
                          </p>
                        </div>
                        {files.length > 0 && (
                          <div className="mt-4">
                            <p className="text-sm font-medium mb-2">Uploaded Files:</p>
                            <div className="space-y-2">
                              {files.map((file, index) => (
                                <div key={index} className="flex items-center justify-between bg-gray-50 p-2 rounded">
                                  <span className="text-sm">{file.name}</span>
                                  <Badge variant="secondary">{(file.size / 1024 / 1024).toFixed(2)} MB</Badge>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>

                      <div>
                        <Label htmlFor="email">Your Email *</Label>
                        <Input type="email" placeholder="Enter your email address" required />
                        <p className="text-xs text-muted-foreground mt-1">
                          You'll receive order confirmation and payment notifications at this email
                        </p>
                      </div>

                      <div>
                        <Label htmlFor="phone">Phone Number (Optional)</Label>
                        <Input type="tel" placeholder="Enter your phone number" />
                      </div>

                      <Button type="submit" className="w-full bg-coral hover:bg-coral/90 text-lg py-3">
                        Confirm Your Order - ${finalPrice}
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </div>

              {/* Price Calculator & Summary */}
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Calculator className="h-5 w-5 mr-2" />
                      Price Calculator
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between">
                        <span>Pages:</span>
                        <span>{pages}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Price per page:</span>
                        <span>${pricePerPage}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Subtotal:</span>
                        <span>${totalPrice}</span>
                      </div>
                      {urgencyMultiplier > 1 && (
                        <div className="flex justify-between text-orange-600">
                          <span>Urgency fee:</span>
                          <span>+{Math.round((urgencyMultiplier - 1) * 100)}%</span>
                        </div>
                      )}
                      <div className="border-t pt-4">
                        <div className="flex justify-between text-lg font-bold">
                          <span>Total:</span>
                          <span className="text-coral">${finalPrice}</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <CreditCard className="h-5 w-5 mr-2" />
                      Payment Process
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 mb-4">
                      <div className="flex items-center space-x-3 p-3 border rounded-lg">
                        <CreditCard className="h-5 w-5 text-blue-600" />
                        <div>
                          <div className="font-medium">PayPal</div>
                          <div className="text-sm text-muted-foreground">Secure online payment</div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3 p-3 border rounded-lg">
                        <Building2 className="h-5 w-5 text-green-600" />
                        <div>
                          <div className="font-medium">Bank Transfer</div>
                          <div className="text-sm text-muted-foreground">Direct bank payment</div>
                        </div>
                      </div>
                    </div>

                    <div className="bg-coral/10 p-4 rounded-lg">
                      <div className="flex items-start space-x-3">
                        <MessageCircle className="h-5 w-5 text-coral mt-0.5" />
                        <div>
                          <h4 className="font-medium text-coral mb-1">Payment Confirmation Process</h4>
                          <p className="text-sm text-coral/80">
                            After making payment, send your payment confirmation via our inbox:
                          </p>
                          <ul className="text-xs text-coral/70 mt-2 space-y-1">
                            <li>• Take a screenshot of your payment confirmation</li>
                            <li>
                              • Send it through our{" "}
                              <a href="/messages" className="underline font-medium">
                                message inbox
                              </a>
                            </li>
                            <li>• Include your order number in the message</li>
                            <li>• We'll assign your order number and start work immediately</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Shield className="h-5 w-5 mr-2" />
                      Our Guarantees
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="w-4 h-4 text-success" />
                        <span className="font-medium">100% Human Written Content</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="w-4 h-4 text-success" />
                        <span>100% Original Work</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="w-4 h-4 text-success" />
                        <span>On-Time Delivery</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="w-4 h-4 text-success" />
                        <span>Free Unlimited Revisions</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="w-4 h-4 text-success" />
                        <span>Money-Back Guarantee</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="w-4 h-4 text-success" />
                        <span>24/7 Customer Support</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="w-4 h-4 text-success" />
                        <span>Automatic Email Updates</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
