// Admin authentication utilities
export const isAdminAuthenticated = (): boolean => {
  if (typeof window === "undefined") return false
  return localStorage.getItem("adminAuth") === "true"
}

export const getAdminUser = (): string | null => {
  if (typeof window === "undefined") return null
  return localStorage.getItem("adminUser")
}

export const adminLogout = (): void => {
  if (typeof window === "undefined") return
  localStorage.removeItem("adminAuth")
  localStorage.removeItem("adminUser")
  window.location.href = "/admin/login"
}

export const requireAdminAuth = (): boolean => {
  const isAuth = isAdminAuthenticated()
  if (!isAuth && typeof window !== "undefined") {
    window.location.href = "/admin/login"
    return false
  }
  return isAuth
}
