import React, { useEffect, useState } from 'react';

/**
 * ThemeToggle
 * - Applies theme classes to document.documentElement
 * - Persists selection in localStorage key 'wh_theme'
 * - Available themes: default (Vibrant), academic, mint, dark
 */

const THEMES = [
  { id: 'default', label: 'Vibrant', className: '' },
  { id: 'academic', label: 'Academic', className: 'theme-academic' },
  { id: 'mint', label: 'Mint', className: 'theme-mint' },
  { id: 'dark', label: 'Dark', className: 'theme-dark' }
];

export default function ThemeToggle() {
  const [theme, setTheme] = useState(() => {
    try {
      return localStorage.getItem('wh_theme') || 'default';
    } catch {
      return 'default';
    }
  });

  useEffect(() => {
    applyTheme(theme);
  }, [theme]);

  function applyTheme(id) {
    const doc = document.documentElement;
    // remove known theme classes
    THEMES.forEach(t => {
      if (t.className) doc.classList.remove(t.className);
    });
    const chosen = THEMES.find(t => t.id === id);
    if (chosen && chosen.className) {
      doc.classList.add(chosen.className);
    }
    try {
      localStorage.setItem('wh_theme', id);
    } catch {}
  }

  function handleSelect(id) {
    setTheme(id);
  }

  return (
    <div className="theme-toggle" role="toolbar" aria-label="Theme selector">
      {THEMES.map(t => (
        <button
          key={t.id}
          onClick={() => handleSelect(t.id)}
          aria-pressed={theme === t.id}
          title={`Switch to ${t.label} theme`}
          style={{
            outline: theme === t.id ? '2px solid rgba(255,255,255,0.92)' : 'none',
            padding: 4,
            borderRadius: 8,
            minWidth: 40,
            display: 'inline-flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
        >
          <span
            className={`swatch ${t.id === 'default' ? 'default' : t.id === 'academic' ? 'academic' : t.id === 'mint' ? 'mint' : 'dark'}`}
            aria-hidden="true"
            style={{ display: 'inline-block' }}
          />
        </button>
      ))}
    </div>
  );
}