"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import AdminLayout from "@/components/admin-layout"
import { MessageCircle, Mail, Clock, User, Phone, Reply, Archive, Star, Search, MoreVertical } from "lucide-react"

export default function AdminInboxPage() {
  const [selectedMessage, setSelectedMessage] = useState<string | null>(null)
  const [filter, setFilter] = useState("all")

  // Mock messages data - in production, this would come from your database
  const messages = [
    {
      id: "MSG-001",
      name: "Sarah Johnson",
      email: "sarah.j@email.com",
      phone: "+254 712 345 678",
      subject: "Urgent Essay Help Needed",
      message: "Hi, I need help with a 5-page essay on environmental science. The deadline is tomorrow. Can you help?",
      priority: "urgent",
      status: "unread",
      timestamp: "2024-01-15 14:30",
      orderRelated: true,
      orderId: "ORD-001",
    },
    {
      id: "MSG-002",
      name: "Michael Chen",
      email: "m.chen@university.edu",
      phone: "+254 723 456 789",
      subject: "Question about Research Paper Service",
      message:
        "I'm interested in your research paper writing service. What's included in the $4 per page price? Do you provide references and formatting?",
      priority: "normal",
      status: "read",
      timestamp: "2024-01-15 12:15",
      orderRelated: false,
      orderId: null,
    },
    {
      id: "MSG-003",
      name: "Emma Davis",
      email: "emma.davis@student.ac.ke",
      phone: "+254 734 567 890",
      subject: "Class Management Service Inquiry",
      message:
        "I'm struggling with multiple assignments this semester. Can you tell me more about your class management service? What exactly is included in the weekly package?",
      priority: "high",
      status: "unread",
      timestamp: "2024-01-15 10:45",
      orderRelated: false,
      orderId: null,
    },
    {
      id: "MSG-004",
      name: "James Wilson",
      email: "j.wilson@gmail.com",
      phone: "+254 745 678 901",
      subject: "Payment Confirmation Issue",
      message: "I made a payment for order ORD-002 but haven't received confirmation. Can you please check the status?",
      priority: "normal",
      status: "replied",
      timestamp: "2024-01-14 16:20",
      orderRelated: true,
      orderId: "ORD-002",
    },
    {
      id: "MSG-005",
      name: "Lisa Anderson",
      email: "lisa.a@outlook.com",
      phone: "+254 756 789 012",
      subject: "Revision Request",
      message:
        "I received my essay but need some minor revisions. The conclusion needs to be stronger and I'd like to add one more reference. When can this be done?",
      priority: "normal",
      status: "unread",
      timestamp: "2024-01-14 09:30",
      orderRelated: true,
      orderId: "ORD-003",
    },
  ]

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "urgent":
        return "bg-red-100 text-red-800"
      case "high":
        return "bg-orange-100 text-orange-800"
      case "normal":
        return "bg-blue-100 text-blue-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "unread":
        return "bg-green-100 text-green-800"
      case "read":
        return "bg-yellow-100 text-yellow-800"
      case "replied":
        return "bg-blue-100 text-blue-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const filteredMessages = messages.filter((msg) => {
    if (filter === "all") return true
    if (filter === "unread") return msg.status === "unread"
    if (filter === "urgent") return msg.priority === "urgent" || msg.priority === "high"
    if (filter === "orders") return msg.orderRelated
    return true
  })

  const selectedMsg = messages.find((msg) => msg.id === selectedMessage)

  return (
    <AdminLayout title="Inbox Management">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">Client Messages</h1>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Search className="h-4 w-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search messages..."
                className="px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-coral"
              />
            </div>
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-coral"
            >
              <option value="all">All Messages</option>
              <option value="unread">Unread</option>
              <option value="urgent">Urgent</option>
              <option value="orders">Order Related</option>
            </select>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Messages</p>
                  <p className="text-2xl font-bold text-coral">{messages.length}</p>
                </div>
                <MessageCircle className="h-8 w-8 text-coral" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Unread</p>
                  <p className="text-2xl font-bold text-green-600">
                    {messages.filter((m) => m.status === "unread").length}
                  </p>
                </div>
                <Mail className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Urgent</p>
                  <p className="text-2xl font-bold text-red-600">
                    {messages.filter((m) => m.priority === "urgent").length}
                  </p>
                </div>
                <Clock className="h-8 w-8 text-red-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Order Related</p>
                  <p className="text-2xl font-bold text-purple">{messages.filter((m) => m.orderRelated).length}</p>
                </div>
                <User className="h-8 w-8 text-purple" />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Messages List */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle>Messages ({filteredMessages.length})</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="space-y-1 max-h-96 overflow-y-auto">
                {filteredMessages.map((msg) => (
                  <div
                    key={msg.id}
                    onClick={() => setSelectedMessage(msg.id)}
                    className={`p-4 border-b cursor-pointer hover:bg-slate-50 transition-colors ${
                      selectedMessage === msg.id ? "bg-coral/10 border-l-4 border-l-coral" : ""
                    }`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <h4 className="font-semibold text-sm">{msg.name}</h4>
                        <p className="text-xs text-muted-foreground">{msg.email}</p>
                      </div>
                      <div className="flex flex-col items-end space-y-1">
                        <Badge className={getPriorityColor(msg.priority)} size="sm">
                          {msg.priority}
                        </Badge>
                        <Badge className={getStatusColor(msg.status)} size="sm">
                          {msg.status}
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm font-medium mb-1">{msg.subject}</p>
                    <p className="text-xs text-muted-foreground mb-2 line-clamp-2">{msg.message}</p>
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span>{msg.timestamp}</span>
                      {msg.orderRelated && (
                        <Badge variant="outline" size="sm">
                          {msg.orderId}
                        </Badge>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Message Detail */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>{selectedMsg ? "Message Details" : "Select a message to view"}</CardTitle>
            </CardHeader>
            <CardContent>
              {selectedMsg ? (
                <div className="space-y-6">
                  {/* Message Header */}
                  <div className="flex items-start justify-between p-4 bg-slate-50 rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="font-semibold text-lg">{selectedMsg.name}</h3>
                        <Badge className={getPriorityColor(selectedMsg.priority)}>{selectedMsg.priority}</Badge>
                        <Badge className={getStatusColor(selectedMsg.status)}>{selectedMsg.status}</Badge>
                      </div>
                      <div className="space-y-1 text-sm text-muted-foreground">
                        <div className="flex items-center space-x-2">
                          <Mail className="h-4 w-4" />
                          <span>{selectedMsg.email}</span>
                        </div>
                        {selectedMsg.phone && (
                          <div className="flex items-center space-x-2">
                            <Phone className="h-4 w-4" />
                            <span>{selectedMsg.phone}</span>
                          </div>
                        )}
                        <div className="flex items-center space-x-2">
                          <Clock className="h-4 w-4" />
                          <span>{selectedMsg.timestamp}</span>
                        </div>
                        {selectedMsg.orderRelated && (
                          <div className="flex items-center space-x-2">
                            <Badge variant="outline">{selectedMsg.orderId}</Badge>
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Button size="sm" variant="outline">
                        <Star className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Archive className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  {/* Subject */}
                  <div>
                    <h4 className="font-semibold mb-2">Subject:</h4>
                    <p className="text-lg">{selectedMsg.subject}</p>
                  </div>

                  {/* Message Content */}
                  <div>
                    <h4 className="font-semibold mb-2">Message:</h4>
                    <div className="p-4 bg-white border rounded-lg">
                      <p className="whitespace-pre-wrap">{selectedMsg.message}</p>
                    </div>
                  </div>

                  {/* Reply Section */}
                  <div className="border-t pt-6">
                    <h4 className="font-semibold mb-4">Reply to {selectedMsg.name}</h4>
                    <div className="space-y-4">
                      <textarea
                        rows={4}
                        placeholder="Type your reply here..."
                        className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-coral"
                      />
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <label className="flex items-center space-x-2">
                            <input type="checkbox" />
                            <span className="text-sm">Send copy to WhatsApp</span>
                          </label>
                          <label className="flex items-center space-x-2">
                            <input type="checkbox" />
                            <span className="text-sm">Mark as resolved</span>
                          </label>
                        </div>
                        <div className="flex space-x-2">
                          <Button variant="outline">Save Draft</Button>
                          <Button className="bg-coral hover:bg-coral/90">
                            <Reply className="h-4 w-4 mr-2" />
                            Send Reply
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-12">
                  <MessageCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">Select a message from the list to view details and reply</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </AdminLayout>
  )
}
