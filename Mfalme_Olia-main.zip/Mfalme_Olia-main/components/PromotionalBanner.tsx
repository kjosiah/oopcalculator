"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { X, Clock, Star, ArrowRight, Zap, Gift } from "lucide-react"

interface PromotionalBannerProps {
  type?: "discount" | "limited-time" | "new-service" | "seasonal"
  title: string
  subtitle?: string
  discount?: string
  ctaText: string
  ctaLink: string
  expiryDate?: string
  isDismissible?: boolean
  className?: string
}

export default function PromotionalBanner({
  type = "discount",
  title,
  subtitle,
  discount,
  ctaText,
  ctaLink,
  expiryDate,
  isDismissible = true,
  className = "",
}: PromotionalBannerProps) {
  const [isVisible, setIsVisible] = useState(true)

  if (!isVisible) return null

  const getBannerStyle = () => {
    switch (type) {
      case "limited-time":
        return "bg-gradient-to-r from-coral to-orange-500 text-white"
      case "new-service":
        return "bg-gradient-to-r from-purple to-blue-600 text-white"
      case "seasonal":
        return "bg-gradient-to-r from-success to-green-600 text-white"
      default:
        return "bg-gradient-to-r from-coral to-purple text-white"
    }
  }

  const getIcon = () => {
    switch (type) {
      case "limited-time":
        return <Clock className="h-5 w-5" />
      case "new-service":
        return <Star className="h-5 w-5" />
      case "seasonal":
        return <Gift className="h-5 w-5" />
      default:
        return <Zap className="h-5 w-5" />
    }
  }

  const getBadgeText = () => {
    switch (type) {
      case "limited-time":
        return "Limited Time"
      case "new-service":
        return "New Service"
      case "seasonal":
        return "Special Offer"
      default:
        return "Hot Deal"
    }
  }

  return (
    <div className={`${getBannerStyle()} py-4 px-6 relative overflow-hidden ${className}`}>
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-32 h-32 bg-white rounded-full -translate-x-16 -translate-y-16"></div>
        <div className="absolute bottom-0 right-0 w-24 h-24 bg-white rounded-full translate-x-12 translate-y-12"></div>
      </div>

      <div className="container mx-auto relative">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              {getIcon()}
              <Badge className="bg-white/20 text-white border-white/30 hover:bg-white/30">{getBadgeText()}</Badge>
            </div>

            <div className="flex items-center space-x-6">
              <div>
                <h3 className="font-bold text-lg md:text-xl">{title}</h3>
                {subtitle && <p className="text-sm opacity-90">{subtitle}</p>}
              </div>

              {discount && (
                <div className="hidden md:block">
                  <div className="text-3xl font-bold">{discount}</div>
                  <div className="text-sm opacity-90">OFF</div>
                </div>
              )}

              {expiryDate && (
                <div className="hidden lg:flex items-center space-x-2 bg-white/20 rounded-lg px-3 py-2">
                  <Clock className="h-4 w-4" />
                  <span className="text-sm font-medium">Expires: {expiryDate}</span>
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <Button asChild className="bg-white text-coral hover:bg-gray-100 shadow-lg hover:shadow-xl font-semibold">
              <a href={ctaLink} className="flex items-center space-x-2">
                <span>{ctaText}</span>
                <ArrowRight className="h-4 w-4" />
              </a>
            </Button>

            {isDismissible && (
              <button onClick={() => setIsVisible(false)} className="text-white/70 hover:text-white transition-colors">
                <X className="h-5 w-5" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
