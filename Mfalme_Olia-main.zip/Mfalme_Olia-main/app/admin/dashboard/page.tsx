"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import AdminLayout from "@/components/admin-layout"
import {
  FileText,
  DollarSign,
  Users,
  Clock,
  TrendingUp,
  CheckCircle,
  AlertCircle,
  Eye,
  Edit,
  MessageCircle,
} from "lucide-react"

export default function AdminDashboardPage() {
  // Mock data - in production, this would come from your database
  const stats = {
    totalOrders: 1247,
    pendingOrders: 23,
    completedOrders: 1198,
    totalRevenue: 15680,
    monthlyRevenue: 3240,
    activeClients: 456,
  }

  const recentOrders = [
    {
      id: "ORD-001",
      client: "Sarah Johnson",
      service: "Essay Writing",
      pages: 5,
      deadline: "2024-01-15",
      status: "in-progress",
      amount: 20,
    },
    {
      id: "ORD-002",
      client: "Michael Chen",
      service: "Research Paper",
      pages: 12,
      deadline: "2024-01-18",
      status: "pending",
      amount: 48,
    },
    {
      id: "ORD-003",
      client: "Emma Davis",
      service: "Editing & Proofreading",
      pages: 8,
      deadline: "2024-01-14",
      status: "completed",
      amount: 32,
    },
    {
      id: "ORD-004",
      client: "James Wilson",
      service: "Class Management",
      pages: 1,
      deadline: "2024-01-20",
      status: "pending",
      amount: 25,
    },
    {
      id: "ORD-005",
      client: "Lisa Anderson",
      service: "Essay Writing",
      pages: 3,
      deadline: "2024-01-16",
      status: "in-progress",
      amount: 12,
    },
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800"
      case "in-progress":
        return "bg-blue-100 text-blue-800"
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <AdminLayout title="Dashboard Overview">
      <div className="space-y-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="border-l-4 border-l-coral">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Orders</p>
                  <p className="text-3xl font-bold text-coral">{stats.totalOrders}</p>
                </div>
                <div className="w-12 h-12 bg-coral/10 rounded-lg flex items-center justify-center">
                  <FileText className="h-6 w-6 text-coral" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm">
                <TrendingUp className="h-4 w-4 text-green-600 mr-1" />
                <span className="text-green-600">+12% from last month</span>
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-success">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Revenue</p>
                  <p className="text-3xl font-bold text-success">${stats.totalRevenue}</p>
                </div>
                <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center">
                  <DollarSign className="h-6 w-6 text-success" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm">
                <TrendingUp className="h-4 w-4 text-green-600 mr-1" />
                <span className="text-green-600">+8% from last month</span>
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-warning">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Pending Orders</p>
                  <p className="text-3xl font-bold text-warning">{stats.pendingOrders}</p>
                </div>
                <div className="w-12 h-12 bg-warning/10 rounded-lg flex items-center justify-center">
                  <Clock className="h-6 w-6 text-warning" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm">
                <AlertCircle className="h-4 w-4 text-warning mr-1" />
                <span className="text-warning">Requires attention</span>
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-purple">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Active Clients</p>
                  <p className="text-3xl font-bold text-purple">{stats.activeClients}</p>
                </div>
                <div className="w-12 h-12 bg-purple/10 rounded-lg flex items-center justify-center">
                  <Users className="h-6 w-6 text-purple" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm">
                <TrendingUp className="h-4 w-4 text-green-600 mr-1" />
                <span className="text-green-600">+15% from last month</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Recent Orders */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Recent Orders</span>
                <Button variant="outline" size="sm">
                  View All Orders
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentOrders.map((order) => (
                  <div key={order.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <span className="font-medium">{order.id}</span>
                        <Badge className={getStatusColor(order.status)}>{order.status}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-1">{order.client}</p>
                      <p className="text-sm">
                        {order.service} • {order.pages} pages • Due: {order.deadline}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-success">${order.amount}</p>
                      <div className="flex space-x-1 mt-2">
                        <Button size="sm" variant="outline">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <MessageCircle className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions & Stats */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full bg-coral hover:bg-coral/90 text-white">
                  <FileText className="h-4 w-4 mr-2" />
                  Create New Order
                </Button>
                <Button variant="outline" className="w-full bg-transparent">
                  <Users className="h-4 w-4 mr-2" />
                  Manage Clients
                </Button>
                <Button variant="outline" className="w-full bg-transparent">
                  <MessageCircle className="h-4 w-4 mr-2" />
                  Send Notifications
                </Button>
                <Button variant="outline" className="w-full bg-transparent">
                  <TrendingUp className="h-4 w-4 mr-2" />
                  View Analytics
                </Button>
              </CardContent>
            </Card>

            {/* Order Status Summary */}
            <Card>
              <CardHeader>
                <CardTitle>Order Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-success" />
                      <span className="text-sm">Completed</span>
                    </div>
                    <span className="font-medium">{stats.completedOrders}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Clock className="h-4 w-4 text-blue-600" />
                      <span className="text-sm">In Progress</span>
                    </div>
                    <span className="font-medium">26</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <AlertCircle className="h-4 w-4 text-warning" />
                      <span className="text-sm">Pending</span>
                    </div>
                    <span className="font-medium">{stats.pendingOrders}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Monthly Revenue */}
            <Card>
              <CardHeader>
                <CardTitle>This Month</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <p className="text-3xl font-bold text-success">${stats.monthlyRevenue}</p>
                  <p className="text-sm text-muted-foreground">Revenue Generated</p>
                  <div className="mt-4 flex items-center justify-center text-sm">
                    <TrendingUp className="h-4 w-4 text-green-600 mr-1" />
                    <span className="text-green-600">+18% vs last month</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* System Status */}
        <Card>
          <CardHeader>
            <CardTitle>System Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-4">
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span className="text-sm">Website Online</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span className="text-sm">Payment System</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span className="text-sm">Email Service</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                <span className="text-sm">Backup System</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  )
}
