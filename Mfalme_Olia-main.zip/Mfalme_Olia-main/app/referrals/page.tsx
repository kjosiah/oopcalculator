import type { Metadata } from "next"
import ReferralClientPage from "./ReferralClientPage"

export const metadata: Metadata = {
  title: "Referral Program - WriteHunters | Earn Rewards for Referrals",
  description:
    "Join WriteHunters referral program and earn rewards for every successful referral. Get paid for sharing our academic writing services with friends.",
  keywords: "referral program, earn money, WriteHunters rewards, academic writing referrals, student rewards",
}

export default function ReferralPage() {
  return <ReferralClientPage />
}
