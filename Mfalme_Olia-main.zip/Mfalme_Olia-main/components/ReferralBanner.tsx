"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Gift, Users, DollarSign, ArrowRight, X } from "lucide-react"

export default function ReferralBanner() {
  const [isVisible, setIsVisible] = useState(true)

  if (!isVisible) return null

  return (
    <Card className="bg-gradient-to-r from-coral/10 to-purple/10 border-coral/20 mb-8">
      <CardContent className="p-6 relative">
        <button
          onClick={() => setIsVisible(false)}
          className="absolute top-4 right-4 text-muted-foreground hover:text-foreground"
        >
          <X className="h-4 w-4" />
        </button>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-gradient-coral rounded-lg flex items-center justify-center">
              <Gift className="h-6 w-6 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-1">Earn Money with Referrals!</h3>
              <p className="text-sm text-muted-foreground">
                Get 20% commission for every friend you refer to WriteHunters
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <div className="hidden md:flex items-center space-x-6">
              <div className="text-center">
                <div className="flex items-center space-x-1 text-success">
                  <Users className="h-4 w-4" />
                  <span className="font-semibold">Easy Sharing</span>
                </div>
              </div>
              <div className="text-center">
                <div className="flex items-center space-x-1 text-coral">
                  <DollarSign className="h-4 w-4" />
                  <span className="font-semibold">20% Commission</span>
                </div>
              </div>
            </div>

            <Button asChild className="btn-coral">
              <a href="/referrals" className="flex items-center space-x-2">
                <span>Start Earning</span>
                <ArrowRight className="h-4 w-4" />
              </a>
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
