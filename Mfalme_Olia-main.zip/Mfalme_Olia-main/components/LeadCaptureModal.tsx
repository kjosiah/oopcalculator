"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { X, Gift, ArrowRight } from "lucide-react"

interface LeadCaptureModalProps {
  isOpen: boolean
  onClose: () => void
  type: "exit-intent" | "newsletter" | "discount"
}

export default function LeadCaptureModal({ isOpen, onClose, type }: LeadCaptureModalProps) {
  const [email, setEmail] = useState("")
  const [name, setName] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  if (!isOpen) return null

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Store lead data (in real app, send to your backend)
    console.log("Lead captured:", { email, name, type })

    setIsSubmitting(false)
    onClose()

    // Show success message
    alert("Thank you! Check your email for your discount code.")
  }

  const getModalContent = () => {
    switch (type) {
      case "exit-intent":
        return {
          title: "Wait! Don't Leave Empty-Handed",
          subtitle: "Get 15% OFF your first order",
          description: "Join thousands of students who trust WriteHunters for their academic success.",
          buttonText: "Get My Discount",
          badge: "Limited Time Offer",
        }
      case "discount":
        return {
          title: "Special Offer Just for You!",
          subtitle: "Save 20% on your next order",
          description: "Subscribe to our newsletter and get exclusive discounts, writing tips, and academic resources.",
          buttonText: "Claim Discount",
          badge: "Exclusive Deal",
        }
      default:
        return {
          title: "Join Our Academic Community",
          subtitle: "Get free writing tips & resources",
          description: "Receive weekly study tips, writing guides, and exclusive offers directly in your inbox.",
          buttonText: "Subscribe Now",
          badge: "Free Resources",
        }
    }
  }

  const content = getModalContent()

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
      <Card className="max-w-md w-full shadow-2xl animate-scale-in">
        <CardContent className="p-8 relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="h-5 w-5" />
          </button>

          <div className="text-center mb-6">
            <Badge className="mb-4 bg-coral text-white">
              <Gift className="h-4 w-4 mr-2" />
              {content.badge}
            </Badge>
            <h3 className="font-serif text-2xl font-bold mb-2">{content.title}</h3>
            <h4 className="text-xl text-coral font-semibold mb-3">{content.subtitle}</h4>
            <p className="text-muted-foreground">{content.description}</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <input
                type="text"
                placeholder="Your Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral focus:border-transparent"
                required
              />
            </div>
            <div>
              <input
                type="email"
                placeholder="Your Email Address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-coral focus:border-transparent"
                required
              />
            </div>
            <Button type="submit" className="w-full btn-coral py-3" disabled={isSubmitting}>
              {isSubmitting ? (
                "Processing..."
              ) : (
                <>
                  <span>{content.buttonText}</span>
                  <ArrowRight className="h-4 w-4 ml-2" />
                </>
              )}
            </Button>
          </form>

          <p className="text-xs text-muted-foreground text-center mt-4">
            We respect your privacy. Unsubscribe at any time.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
