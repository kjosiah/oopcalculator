import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Shield, Mail, Phone, FileText } from "lucide-react"
import Link from "next/link"

export const metadata = {
  title: "Privacy Policy - WriteHunters Academic Writing Services",
  description:
    "WriteHunters privacy policy outlining how we collect, use, and protect your personal information when using our academic writing services.",
  keywords: "privacy policy, data protection, WriteHunters, academic writing, privacy rights",
  openGraph: {
    title: "Privacy Policy - WriteHunters",
    description: "Learn how WriteHunters protects your privacy and personal information.",
    type: "website",
    url: "https://writehunters.com/privacy-policy",
  },
}

export default function PrivacyPolicyPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <BookOpen className="h-8 w-8 text-primary" />
              <span className="font-serif text-2xl font-bold text-primary">WriteHunters</span>
            </Link>
            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-foreground hover:text-primary transition-colors">
                Home
              </Link>
              <Link href="/services" className="text-foreground hover:text-primary transition-colors">
                Services
              </Link>
              <Link href="/about" className="text-foreground hover:text-primary transition-colors">
                About
              </Link>
              <Link href="/privacy-policy" className="text-primary font-semibold">
                Privacy Policy
              </Link>
              <Link href="/contact" className="text-foreground hover:text-primary transition-colors">
                Contact
              </Link>
            </nav>
            <Link href="/order">
              <Button className="bg-coral hover:bg-coral/90">Place Your Order</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <Badge className="mb-6 bg-primary/10 text-primary border-primary/20">Privacy Policy</Badge>
            <h1 className="font-serif text-4xl md:text-5xl font-bold text-foreground mb-6">Your Privacy Matters</h1>
            <p className="text-xl text-muted-foreground">
              Learn how WriteHunters protects your personal information and respects your privacy rights.
            </p>
          </div>
        </div>
      </section>

      {/* Privacy Policy Content */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="grid gap-8">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Shield className="h-6 w-6 mr-3 text-primary" />
                    Information We Collect
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-2">Personal Information</h4>
                    <p className="text-muted-foreground">
                      We collect information you provide directly to us, such as when you create an account, place an
                      order, or contact us. This may include:
                    </p>
                    <ul className="list-disc list-inside mt-2 space-y-1 text-muted-foreground">
                      <li>Name and contact information (email, phone number)</li>
                      <li>Academic information (institution, level of study)</li>
                      <li>Payment information (processed securely through third-party providers)</li>
                      <li>Order details and project requirements</li>
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-2">Automatically Collected Information</h4>
                    <p className="text-muted-foreground">
                      We may automatically collect certain information about your device and usage of our services,
                      including IP address, browser type, and pages visited.
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <FileText className="h-6 w-6 mr-3 text-coral" />
                    How We Use Your Information
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4">We use the information we collect to:</p>
                  <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                    <li>Provide, maintain, and improve our academic writing services</li>
                    <li>Process orders and payments</li>
                    <li>Communicate with you about your orders and our services</li>
                    <li>Send you updates, newsletters, and promotional materials (with your consent)</li>
                    <li>Respond to your inquiries and provide customer support</li>
                    <li>Comply with legal obligations and protect our rights</li>
                    <li>Analyze usage patterns to improve our website and services</li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Shield className="h-6 w-6 mr-3 text-purple" />
                    Information Sharing and Disclosure
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-2">We Do Not Sell Your Information</h4>
                    <p className="text-muted-foreground">
                      WriteHunters does not sell, trade, or rent your personal information to third parties.
                    </p>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-2">Limited Sharing</h4>
                    <p className="text-muted-foreground mb-2">
                      We may share your information only in the following circumstances:
                    </p>
                    <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                      <li>With qualified writers assigned to your project (only necessary project details)</li>
                      <li>With payment processors to complete transactions</li>
                      <li>When required by law or to protect our rights</li>
                      <li>With your explicit consent</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Shield className="h-6 w-6 mr-3 text-success" />
                    Data Security
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4">
                    We implement appropriate technical and organizational measures to protect your personal information
                    against unauthorized access, alteration, disclosure, or destruction. These measures include:
                  </p>
                  <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                    <li>SSL encryption for data transmission</li>
                    <li>Secure servers and databases</li>
                    <li>Regular security audits and updates</li>
                    <li>Limited access to personal information on a need-to-know basis</li>
                    <li>Staff training on data protection practices</li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <FileText className="h-6 w-6 mr-3 text-warning" />
                    Your Rights and Choices
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4">
                    You have the following rights regarding your personal information:
                  </p>
                  <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                    <li>
                      <strong>Access:</strong> Request a copy of the personal information we hold about you
                    </li>
                    <li>
                      <strong>Correction:</strong> Request correction of inaccurate or incomplete information
                    </li>
                    <li>
                      <strong>Deletion:</strong> Request deletion of your personal information (subject to legal
                      requirements)
                    </li>
                    <li>
                      <strong>Portability:</strong> Request transfer of your information to another service provider
                    </li>
                    <li>
                      <strong>Opt-out:</strong> Unsubscribe from marketing communications at any time
                    </li>
                    <li>
                      <strong>Restriction:</strong> Request limitation of processing in certain circumstances
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Mail className="h-6 w-6 mr-3 text-accent" />
                    Cookies and Tracking
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4">
                    We use cookies and similar tracking technologies to enhance your experience on our website. These
                    help us:
                  </p>
                  <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                    <li>Remember your preferences and settings</li>
                    <li>Analyze website traffic and usage patterns</li>
                    <li>Provide personalized content and advertisements</li>
                    <li>Improve our services and user experience</li>
                  </ul>
                  <p className="text-muted-foreground mt-4">
                    You can control cookies through your browser settings, but disabling them may affect website
                    functionality.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Phone className="h-6 w-6 mr-3 text-coral" />
                    Contact Us
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4">
                    If you have any questions about this Privacy Policy or our data practices, please contact us:
                  </p>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-3">
                      <Mail className="h-5 w-5 text-primary" />
                      <span>Email: writehunters@gmail.com</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Phone className="h-5 w-5 text-primary" />
                      <span>WhatsApp: +254 748 881893</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-50">
                <CardContent className="p-6">
                  <div className="text-center">
                    <h3 className="font-serif text-xl font-bold mb-2">Policy Updates</h3>
                    <p className="text-muted-foreground mb-4">
                      We may update this Privacy Policy from time to time. We will notify you of any material changes by
                      posting the new policy on this page and updating the "Last Updated" date.
                    </p>
                    <p className="text-sm text-muted-foreground">
                      <strong>Last Updated:</strong> December 19, 2024
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="font-serif text-3xl font-bold text-foreground mb-4">Ready to Get Started?</h2>
            <p className="text-lg text-muted-foreground mb-8">
              Your privacy is protected. Place your order with confidence knowing your information is secure.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-coral hover:bg-coral/90">
                <Link href="/order">Place Your Order</Link>
              </Button>
              <Button size="lg" variant="outline">
                <Link href="/contact">Contact Our Team</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
