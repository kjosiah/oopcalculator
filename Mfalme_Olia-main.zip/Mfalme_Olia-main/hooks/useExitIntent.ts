"use client"

import { useState, useEffect } from "react"

export function useExitIntent() {
  const [showExitIntent, setShowExitIntent] = useState(false)
  const [hasShown, setHasShown] = useState(false)

  useEffect(() => {
    const handleMouseLeave = (e: MouseEvent) => {
      if (e.clientY <= 0 && !hasShown) {
        setShowExitIntent(true)
        setHasShown(true)
      }
    }

    // Show after 30 seconds if not shown yet
    const timer = setTimeout(() => {
      if (!hasShown) {
        setShowExitIntent(true)
        setHasShown(true)
      }
    }, 30000)

    document.addEventListener("mouseleave", handleMouseLeave)

    return () => {
      document.removeEventListener("mouseleave", handleMouseLeave)
      clearTimeout(timer)
    }
  }, [hasShown])

  const closeExitIntent = () => {
    setShowExitIntent(false)
  }

  return { showExitIntent, closeExitIntent }
}
