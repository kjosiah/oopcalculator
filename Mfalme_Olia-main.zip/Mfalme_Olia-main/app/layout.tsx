import type React from "react"
import type { Metadata } from "next"
import { Playfair_Display, Source_Sans_3 as Source_Sans_Pro } from "next/font/google"
import "./globals.css"
import { GoogleAnalytics } from "./components/GoogleAnalytics"
import { Suspense } from "react"

const playfair = Playfair_Display({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-playfair",
})

const sourceSans = Source_Sans_Pro({
  subsets: ["latin"],
  weight: ["400", "600"],
  display: "swap",
  variable: "--font-source-sans",
})

export const metadata: Metadata = {
  title: {
    default: "WriteHunters - Professional Academic Writing Services | 100% Human Written",
    template: "%s | WriteHunters - Academic Writing Experts",
  },
  description:
    "Professional academic writing services with 100% human-written content. Expert essay writing, research papers, class management, and editing services. 24/7 support, plagiarism-free guarantee, and affordable pricing starting at $4/page.",
  keywords: [
    "academic writing services",
    "essay writing help",
    "research paper writing",
    "class management services",
    "academic editing",
    "dissertation writing",
    "homework help",
    "online tutoring",
    "WriteHunters",
    "professional writers",
    "plagiarism free",
    "24/7 support",
    "affordable academic help",
  ],
  authors: [{ name: "WriteHunters Academic Services", url: "https://writehunters.com" }],
  creator: "WriteHunters",
  publisher: "WriteHunters Academic Services",
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://writehunters.com",
    siteName: "WriteHunters",
    title: "WriteHunters - Professional Academic Writing Services | 100% Human Written",
    description:
      "Professional academic writing services with 100% human-written content. Expert writers, 24/7 support, plagiarism-free guarantee. Starting at $4/page.",
    images: [
      {
        url: "/academic-writing-hero.png",
        width: 1200,
        height: 630,
        alt: "WriteHunters - Professional Academic Writing Services",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "WriteHunters - Professional Academic Writing Services",
    description:
      "Expert academic writing help with 100% human-written content. 24/7 support, plagiarism-free guarantee.",
    images: ["/academic-writing-hero.png"],
    creator: "@writehunters",
  },
  alternates: {
    canonical: "https://writehunters.com",
  },
  category: "Education",
  verification: {
    google: "your-google-verification-code",
    yandex: "your-yandex-verification-code",
    yahoo: "your-yahoo-verification-code",
  },
  generator: "Next.js",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${playfair.variable} ${sourceSans.variable} antialiased`}>
      <head>
        <GoogleAnalytics />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Organization",
              name: "WriteHunters",
              url: "https://writehunters.com",
              logo: "https://writehunters.com/logo.png",
              description: "Professional academic writing services with 100% human-written content",
              contactPoint: {
                "@type": "ContactPoint",
                telephone: "+254748881893",
                contactType: "customer service",
                email: "writehunters@gmail.com",
                availableLanguage: "English",
              },
              sameAs: [
                "https://www.facebook.com/profile.php?id=61577361405554",
                "https://www.instagram.com/writehunters/",
              ],
              address: {
                "@type": "PostalAddress",
                addressCountry: "KE",
              },
              priceRange: "$4-$600",
              aggregateRating: {
                "@type": "AggregateRating",
                ratingValue: "4.9",
                reviewCount: "1500",
                bestRating: "5",
                worstRating: "1",
              },
            }),
          }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Service",
              name: "Academic Writing Services",
              provider: {
                "@type": "Organization",
                name: "WriteHunters",
              },
              description: "Professional academic writing, editing, and class management services",
              offers: {
                "@type": "Offer",
                price: "4.00",
                priceCurrency: "USD",
                priceSpecification: {
                  "@type": "UnitPriceSpecification",
                  price: "4.00",
                  priceCurrency: "USD",
                  unitText: "per page",
                },
              },
              areaServed: "Worldwide",
              availableChannel: {
                "@type": "ServiceChannel",
                serviceUrl: "https://writehunters.com",
                servicePhone: "+254748881893",
                servicePostalAddress: {
                  "@type": "PostalAddress",
                  addressCountry: "KE",
                },
              },
            }),
          }}
        />
      </head>
      <body className="font-sans">
        <Suspense fallback={<div>Loading...</div>}>{children}</Suspense>
      </body>
    </html>
  )
}
