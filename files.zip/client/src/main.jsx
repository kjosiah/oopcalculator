import React from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'
import Admin from './admin/Admin'
import './styles.css'

const root = createRoot(document.getElementById('root'))

// Simple route switch: serve Admin SPA at /admin, otherwise main App
if (window.location.pathname.startsWith('/admin')) {
  root.render(<Admin />)
} else {
  root.render(<App />)
}