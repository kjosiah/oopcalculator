interface SchemaProps {
  type: "service" | "organization" | "webpage"
  data: any
}

export function SEOSchema({ type, data }: SchemaProps) {
  let schema = {}

  switch (type) {
    case "service":
      schema = {
        "@context": "https://schema.org",
        "@type": "Service",
        name: data.name,
        description: data.description,
        provider: {
          "@type": "Organization",
          name: "WriteHunters",
          url: "https://writehunters.com",
        },
        offers: {
          "@type": "Offer",
          price: data.price,
          priceCurrency: "USD",
          availability: "https://schema.org/InStock",
        },
      }
      break
    case "organization":
      schema = {
        "@context": "https://schema.org",
        "@type": "Organization",
        ...data,
      }
      break
    case "webpage":
      schema = {
        "@context": "https://schema.org",
        "@type": "WebPage",
        ...data,
      }
      break
  }

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{
        __html: JSON.stringify(schema),
      }}
    />
  )
}
