"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Send, MessageCircle, Clock, Mail } from "lucide-react"
import Link from "next/link"

export default function MessagesPage() {
  const [message, setMessage] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: "",
    priority: "normal",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // In production, this would send to your backend/database
    console.log("Message sent:", message)
    alert("Message sent successfully! We'll get back to you within 24 hours.")
    setMessage({ name: "", email: "", phone: "", subject: "", message: "", priority: "normal" })
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <BookOpen className="h-8 w-8 text-primary" />
              <span className="font-serif text-2xl font-bold text-primary">WriteHunters</span>
            </Link>
            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-foreground hover:text-primary transition-colors">
                Home
              </Link>
              <Link href="/services" className="text-foreground hover:text-primary transition-colors">
                Services
              </Link>
              <Link href="/about" className="text-foreground hover:text-primary transition-colors">
                About
              </Link>
              <Link href="/blog" className="text-foreground hover:text-primary transition-colors">
                Blog
              </Link>
              <Link href="/contact" className="text-foreground hover:text-primary transition-colors">
                Contact
              </Link>
            </nav>
            <Link href="/order">
              <Button className="bg-coral hover:bg-coral/90">Place Your Order</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <Badge className="mb-6 bg-coral/10 text-coral border-coral/20">Direct Messaging</Badge>
            <h1 className="font-serif text-4xl md:text-5xl font-bold text-foreground mb-6">Send Us a Message</h1>
            <p className="text-xl text-muted-foreground">
              Have questions or need assistance? Send us a direct message and get personalized support from our team.
            </p>
          </div>
        </div>
      </section>

      {/* Messaging Form */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="grid lg:grid-cols-2 gap-12">
              <Card className="h-fit">
                <CardHeader>
                  <CardTitle className="font-serif text-2xl flex items-center">
                    <MessageCircle className="h-6 w-6 mr-3 text-coral" />
                    Send Direct Message
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                      <label className="block text-sm font-semibold text-foreground mb-2">Full Name *</label>
                      <input
                        type="text"
                        required
                        value={message.name}
                        onChange={(e) => setMessage({ ...message, name: e.target.value })}
                        className="w-full p-3 border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-coral"
                        placeholder="Your full name"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-foreground mb-2">Email Address *</label>
                      <input
                        type="email"
                        required
                        value={message.email}
                        onChange={(e) => setMessage({ ...message, email: e.target.value })}
                        className="w-full p-3 border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-coral"
                        placeholder="your.email@example.com"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-foreground mb-2">Phone Number</label>
                      <input
                        type="tel"
                        value={message.phone}
                        onChange={(e) => setMessage({ ...message, phone: e.target.value })}
                        className="w-full p-3 border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-coral"
                        placeholder="+254 XXX XXX XXX"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-foreground mb-2">Subject *</label>
                      <input
                        type="text"
                        required
                        value={message.subject}
                        onChange={(e) => setMessage({ ...message, subject: e.target.value })}
                        className="w-full p-3 border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-coral"
                        placeholder="What is this message about?"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-foreground mb-2">Priority Level</label>
                      <select
                        value={message.priority}
                        onChange={(e) => setMessage({ ...message, priority: e.target.value })}
                        className="w-full p-3 border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-coral"
                      >
                        <option value="normal">Normal</option>
                        <option value="urgent">Urgent</option>
                        <option value="high">High Priority</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-foreground mb-2">Message *</label>
                      <textarea
                        required
                        rows={6}
                        value={message.message}
                        onChange={(e) => setMessage({ ...message, message: e.target.value })}
                        className="w-full p-3 border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-coral"
                        placeholder="Type your message here..."
                      />
                    </div>

                    <Button type="submit" className="w-full bg-coral hover:bg-coral/90 text-lg py-3">
                      <Send className="h-5 w-5 mr-2" />
                      Send Message
                    </Button>
                  </form>
                </CardContent>
              </Card>

              <div className="space-y-8">
                <Card>
                  <CardHeader>
                    <CardTitle className="font-serif text-xl">Quick Contact Options</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center space-x-4 p-4 bg-green-50 rounded-lg">
                      <MessageCircle className="h-8 w-8 text-green-600" />
                      <div>
                        <h4 className="font-semibold">WhatsApp</h4>
                        <p className="text-sm text-muted-foreground">+254 748 881893</p>
                        <p className="text-xs text-green-600">Usually responds within minutes</p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-4 p-4 bg-blue-50 rounded-lg">
                      <Mail className="h-8 w-8 text-blue-600" />
                      <div>
                        <h4 className="font-semibold">Email</h4>
                        <p className="text-sm text-muted-foreground">writehunters@gmail.com</p>
                        <p className="text-xs text-blue-600">Response within 24 hours</p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-4 p-4 bg-coral/10 rounded-lg">
                      <Clock className="h-8 w-8 text-coral" />
                      <div>
                        <h4 className="font-semibold">Response Time</h4>
                        <p className="text-sm text-muted-foreground">Messages: 2-6 hours</p>
                        <p className="text-xs text-coral">Urgent: Within 1 hour</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="font-serif text-xl">Message Guidelines</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-coral rounded-full mt-2"></div>
                      <p className="text-sm">Be specific about your academic writing needs</p>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-coral rounded-full mt-2"></div>
                      <p className="text-sm">Include deadline and page count if known</p>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-coral rounded-full mt-2"></div>
                      <p className="text-sm">Mention your academic level and subject</p>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-coral rounded-full mt-2"></div>
                      <p className="text-sm">Use "Urgent" priority for same-day needs</p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-r from-coral/10 to-primary/10">
                  <CardContent className="p-6 text-center">
                    <h3 className="font-serif text-xl font-bold mb-2">Need Immediate Help?</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      For urgent academic writing assistance, contact us directly via WhatsApp
                    </p>
                    <Button className="bg-green-600 hover:bg-green-700 text-white">
                      <MessageCircle className="h-4 w-4 mr-2" />
                      WhatsApp Now
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
