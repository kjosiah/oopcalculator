#!/usr/bin/env bash
set -euo pipefail

# create_writehunters_zip.sh
# Creates a complete WriteHunters project scaffold on disk and zips it to writehunters.zip
# Usage: bash create_writehunters_zip.sh
# After running, you'll have writehunters.zip in the current directory containing the project.
# IMPORTANT: This zip contains .env.example only. Do NOT commit real secrets.

OUTDIR="writehunters"
ZIPNAME="writehunters.zip"

rm -rf "$OUTDIR" "$ZIPNAME"
mkdir -p "$OUTDIR"

echo "Creating project in $OUTDIR ..."

# root README.md
cat > "$OUTDIR/README.md" <<'EOF'
# WriteHunters — Academic Writing Website (Starter)

Overview
- Modern responsive frontend (React + Vite) and secure Node/Express backend.
- Features implemented:
  - Responsive UI with order form, price calculator, order dashboard, contact form, legal pages.
  - Secure registration & login (bcrypt + JWT in httpOnly cookies).
  - Order creation with unique Order Number generation and server-side price calculation.
  - PayPal integration points (uses your merchant ID PA5B4RAVDET9Y in client).
  - Contact form that sends email to writehunters@gmail.com (via SMTP nodemailer).
  - Admin route for site management (set via env).
  - WhatsApp quick chat button (opens chat but does not display the number).
- Excluded: Blog (as requested).

Quick start (development)
1. Copy environment variables:
   cp .env.example .env
   Fill in values for PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET, SMTP_*, JWT_SECRET, ADMIN_PASSWORD, and SESSION_COOKIE_SECRET.

2. Install dependencies and run:
   npm install
   npm run dev

3. Open http://localhost:5173 for the frontend (Vite) and API runs on http://localhost:4000

Important production notes
- Serve through HTTPS (TLS/SSL). If you deploy behind a load balancer / reverse proxy, terminate TLS there.
- Fill PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET in .env for server-side PayPal flows.
- Use a real SMTP provider for sending contact emails.
- Replace ADMIN_PASSWORD with a secure secret and manage admin accounts in DB for multiple admins.

Admin link
- Admin UI is available at: /admin
- Set ADMIN_PASSWORD in your .env to manage site via this route (or create admin user accounts in the DB).

Project layout (key)
- server/: Express backend
- client/: React frontend (Vite)
- legal/: Static legal pages (Privacy, Cookies, Terms)
EOF

# .env.example
cat > "$OUTDIR/.env.example" <<'EOF'
# Copy to .env and fill values

# Server
PORT=4000
NODE_ENV=development
JWT_SECRET=replace_with_a_long_random_secret
SESSION_COOKIE_SECRET=replace_with_a_random_secret

# Admin
ADMIN_PASSWORD=change_this_admin_password

# PayPal (for server side calls, required)
PAYPAL_CLIENT_ID=your-paypal-client-id
PAYPAL_CLIENT_SECRET=your-paypal-client-secret
PAYPAL_MERCHANT_ID=PA5B4RAVDET9Y
PAYPAL_WEBHOOK_ID=your-paypal-webhook-id

# SMTP (for contact form)
SMTP_HOST=smtp.example.com
SMTP_PORT=587
SMTP_USER=you@example.com
SMTP_PASS=your_smtp_password
CONTACT_EMAIL=writehunters@gmail.com

# Database (SQLite file path)
DATABASE_FILE=./server/data/writehunters.db

# Client: optional (Vite) environment variable for PayPal client id
# Create file client/.env and add: VITE_PAYPAL_CLIENT_ID=your-paypal-client-id
EOF

# .gitignore
cat > "$OUTDIR/.gitignore" <<'EOF'
node_modules/
client/node_modules/
.env
server/data/
server/uploads/
.DS_Store
dist/
EOF

# root package.json
cat > "$OUTDIR/package.json" <<'EOF'
{
  "name": "writehunters",
  "version": "0.1.0",
  "private": true,
  "scripts": {
    "start": "node server/index.js",
    "server": "node server/index.js",
    "client": "cd client && npm run dev",
    "dev": "concurrently \"npm:server\" \"npm:client\"",
    "build": "cd client && npm run build"
  },
  "dependencies": {
    "better-sqlite3": "^8.3.0",
    "bcrypt": "^5.1.0",
    "concurrently": "^8.2.0",
    "cookie-parser": "^1.4.6",
    "cors": "^2.8.5",
    "dotenv": "^16.1.4",
    "express": "^4.18.2",
    "helmet": "^7.0.0",
    "jsonwebtoken": "^9.0.0",
    "multer": "^1.4.5",
    "nodemailer": "^6.9.4",
    "uuid": "^9.0.0"
  },
  "devDependencies": {}
}
EOF

# server dir
mkdir -p "$OUTDIR/server/routes" "$OUTDIR/server/data" "$OUTDIR/server/uploads"

# server/index.js
cat > "$OUTDIR/server/index.js" <<'EOF'
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const dotenv = require('dotenv');
const path = require('path');
const fs = require('fs');

dotenv.config();

const authRoutes = require('./routes/auth');
const ordersRoutes = require('./routes/orders');
const contactRoutes = require('./routes/contact');
const adminRoutes = require('./routes/admin');
const paymentsRoutes = require('./routes/payments');

const app = express();
app.use(helmet());
app.use(express.json());
app.use(cookieParser());
app.use(cors({
  origin: ['http://localhost:5173'],
  credentials: true
}));

// ensure uploads directory exists
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

// Simple HTTPS redirect in production (expect TLS on proxy)
if (process.env.NODE_ENV === 'production') {
  app.use((req, res, next) => {
    if (req.headers['x-forwarded-proto'] !== 'https') {
      return res.redirect('https://' + req.hostname + req.url);
    }
    next();
  });
}

app.use('/api/auth', authRoutes);
app.use('/api/orders', ordersRoutes);
app.use('/api/contact', contactRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/payments', paymentsRoutes);

// Serve uploaded files
app.use('/uploads', express.static(uploadsDir));

// Serve legal static pages and client build if deployed
app.use('/legal', express.static(path.join(__dirname, '..', 'legal')));

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`WriteHunters API running on port ${PORT}`);
});
EOF

# server/db.js
cat > "$OUTDIR/server/db.js" <<'EOF'
const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');
const dotenv = require('dotenv');
dotenv.config();

const dbFile = process.env.DATABASE_FILE || path.join(__dirname, 'data', 'writehunters.db');
const dir = path.dirname(dbFile);
if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

const db = new Database(dbFile);

// Initial schema (orders extended: assigned_writer, paid flag, payment_id; added order_files)
db.exec(`
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  name TEXT,
  role TEXT DEFAULT 'client',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_number TEXT UNIQUE NOT NULL,
  user_id INTEGER,
  service_type TEXT,
  academic_level TEXT,
  pages INTEGER,
  price REAL,
  deadline TEXT,
  instructions TEXT,
  status TEXT DEFAULT 'pending',
  assigned_writer TEXT,
  paid INTEGER DEFAULT 0,
  payment_id TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER,
  author TEXT,
  body TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS order_files (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER,
  filename TEXT,
  original_name TEXT,
  mime_type TEXT,
  size INTEGER,
  uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);
`);

module.exports = db;
EOF

# server/mailer.js
cat > "$OUTDIR/server/mailer.js" <<'EOF'
const nodemailer = require('nodemailer');
const dotenv = require('dotenv');
dotenv.config();

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT || 587),
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS
  }
});

module.exports = async function sendMail({ to, subject, text, from }) {
  const info = await transporter.sendMail({
    from: from || process.env.SMTP_USER,
    to,
    subject,
    text
  });
  return info;
};
EOF

# server/routes/auth.js
cat > "$OUTDIR/server/routes/auth.js" <<'EOF'
const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const db = require('../db');
const router = express.Router();

const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret';
const COOKIE_NAME = 'wh_token';

// Register
router.post('/register', async (req, res) => {
  const { email, password, name } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email and password required' });
  const hash = await bcrypt.hash(password, 12);
  try {
    const stmt = db.prepare('INSERT INTO users (email, password_hash, name) VALUES (?, ?, ?)');
    const info = stmt.run(email, hash, name || null);
    const user = { id: info.lastInsertRowid, email, name };
    const token = jwt.sign(user, JWT_SECRET, { expiresIn: '7d' });
    res.cookie(COOKIE_NAME, token, { httpOnly: true, secure: process.env.NODE_ENV === 'production' });
    res.json({ user });
  } catch (err) {
    if (err.code === 'SQLITE_CONSTRAINT_UNIQUE') {
      return res.status(409).json({ error: 'Email already registered' });
    }
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const row = db.prepare('SELECT id, email, password_hash, name, role FROM users WHERE email = ?').get(email);
  if (!row) return res.status(401).json({ error: 'Invalid credentials' });
  const ok = await bcrypt.compare(password, row.password_hash);
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
  const user = { id: row.id, email: row.email, name: row.name, role: row.role };
  const token = jwt.sign(user, JWT_SECRET, { expiresIn: '7d' });
  res.cookie(COOKIE_NAME, token, { httpOnly: true, secure: process.env.NODE_ENV === 'production' });
  res.json({ user });
});

// Logout
router.post('/logout', (req, res) => {
  res.clearCookie(COOKIE_NAME);
  res.json({ ok: true });
});

module.exports = router;
EOF

# server/routes/orders.js
cat > "$OUTDIR/server/routes/orders.js" <<'EOF'
const express = require('express');
const db = require('../db');
const { v4: uuidv4 } = require('uuid');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret';

// Multer setup
const uploadsDir = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const unique = `${Date.now()}-${Math.random().toString(36).slice(2,8)}-${file.originalname}`;
    cb(null, unique);
  }
});
const upload = multer({ storage });

// Simple auth helper
function getUserFromToken(req) {
  const token = req.cookies?.wh_token;
  if (!token) return null;
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch {
    return null;
  }
}

// Price calculator
function calculatePrice(serviceType, pages) {
  let base = 0;
  switch ((serviceType || '').toLowerCase()) {
    case 'essay': base = 4; break;
    case 'research': base = 6; break;
    case 'editing': base = 3; break;
    case 'class management': base = 50; return base; // per week pricing handled separately
    default: base = 5;
  }
  return Math.max(1, pages) * base;
}

// Create an order
router.post('/create', (req, res) => {
  const user = getUserFromToken(req);
  const { serviceType, academicLevel, pages, deadline, instructions } = req.body;
  if (!serviceType || !pages) return res.status(400).json({ error: 'Missing fields' });

  const price = calculatePrice(serviceType, pages);
  const order_number = `WH-${Date.now().toString(36)}-${uuidv4().slice(0,6).toUpperCase()}`;

  const stmt = db.prepare(`INSERT INTO orders
    (order_number, user_id, service_type, academic_level, pages, price, deadline, instructions)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);

  const info = stmt.run(order_number, user?.id || null, serviceType, academicLevel, pages, price, deadline, instructions);
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(info.lastInsertRowid);

  res.json({ order });
});

// Upload file for an order
router.post('/:orderNumber/upload', upload.single('file'), (req, res) => {
  const user = getUserFromToken(req);
  if (!user) return res.status(401).json({ error: 'Unauthorized' });

  const row = db.prepare('SELECT * FROM orders WHERE order_number = ?').get(req.params.orderNumber);
  if (!row) return res.status(404).json({ error: 'Order not found' });
  if (row.user_id !== user.id && user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });

  const file = req.file;
  const stmt = db.prepare('INSERT INTO order_files (order_id, filename, original_name, mime_type, size) VALUES (?, ?, ?, ?, ?)');
  stmt.run(row.id, file.filename, file.originalname, file.mimetype, file.size);

  res.json({ ok: true, file: { filename: file.filename, original: file.originalname } });
});

// Get orders for current user
router.get('/my', (req, res) => {
  const user = getUserFromToken(req);
  if (!user) return res.status(401).json({ error: 'Unauthorized' });
  const rows = db.prepare('SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC').all(user.id);
  res.json({ orders: rows });
});

// Get order by number (public for signed-in users)
router.get('/:orderNumber', (req, res) => {
  const user = getUserFromToken(req);
  if (!user) return res.status(401).json({ error: 'Unauthorized' });
  const row = db.prepare('SELECT * FROM orders WHERE order_number = ?').get(req.params.orderNumber);
  if (!row) return res.status(404).json({ error: 'Order not found' });
  if (row.user_id !== user.id && user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
  const messages = db.prepare('SELECT * FROM messages WHERE order_id = ? ORDER BY created_at ASC').all(row.id);
  const files = db.prepare('SELECT id, filename, original_name, mime_type, size, uploaded_at FROM order_files WHERE order_id = ?').all(row.id);
  res.json({ order: row, messages, files });
});

// Add message to order (client/writer communication)
router.post('/:orderNumber/message', (req, res) => {
  const user = getUserFromToken(req);
  if (!user) return res.status(401).json({ error: 'Unauthorized' });
  const row = db.prepare('SELECT * FROM orders WHERE order_number = ?').get(req.params.orderNumber);
  if (!row) return res.status(404).json({ error: 'Order not found' });
  if (row.user_id !== user.id && user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });

  const stmt = db.prepare('INSERT INTO messages (order_id, author, body) VALUES (?, ?, ?)');
  stmt.run(row.id, user.email, req.body.body || '');
  res.json({ ok: true });
});

module.exports = router;
EOF

# server/routes/contact.js
cat > "$OUTDIR/server/routes/contact.js" <<'EOF'
const express = require('express');
const sendMail = require('../mailer');
const router = express.Router();

router.post('/', async (req, res) => {
  const { name, email, subject, message } = req.body;
  if (!email || !message) return res.status(400).json({ error: 'Email and message required' });
  const to = process.env.CONTACT_EMAIL || 'writehunters@gmail.com';
  const body = `
    New message from WriteHunters contact form:
    Name: ${name || 'N/A'}
    Email: ${email}
    Subject: ${subject || 'N/A'}
    Message:
    ${message}
  `;
  try {
    await sendMail({ to, subject: `[Contact] ${subject || 'Website message'}`, text: body, from: process.env.SMTP_USER });
    res.json({ ok: true });
  } catch (err) {
    console.error('Contact mail error', err);
    res.status(500).json({ error: 'Failed to send message' });
  }
});

module.exports = router;
EOF

# server/routes/admin.js
cat > "$OUTDIR/server/routes/admin.js" <<'EOF'
const express = require('express');
const db = require('../db');
const router = express.Router();

// Very light admin check: either a JWT user with role admin or ADMIN_PASSWORD in header (for quick setup).
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'change_this_admin_password';

function isAdmin(req) {
  // Basic header check for quick admin access (CHANGE for production)
  const pw = req.headers['x-admin-password'];
  if (pw && pw === ADMIN_PASSWORD) return true;
  return false;
}

router.get('/orders', (req, res) => {
  if (!isAdmin(req)) return res.status(403).json({ error: 'Forbidden' });
  const rows = db.prepare('SELECT * FROM orders ORDER BY created_at DESC').all();
  res.json({ orders: rows });
});

router.post('/orders/:orderNumber/status', (req, res) => {
  if (!isAdmin(req)) return res.status(403).json({ error: 'Forbidden' });
  const { status } = req.body;
  const stmt = db.prepare('UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE order_number = ?');
  stmt.run(status, req.params.orderNumber);
  res.json({ ok: true });
});

// Assign writer to order
router.post('/orders/:orderNumber/assign', (req, res) => {
  if (!isAdmin(req)) return res.status(403).json({ error: 'Forbidden' });
  const { writer } = req.body;
  const stmt = db.prepare('UPDATE orders SET assigned_writer = ?, updated_at = CURRENT_TIMESTAMP WHERE order_number = ?');
  stmt.run(writer, req.params.orderNumber);
  res.json({ ok: true });
});

// List files for an order
router.get('/orders/:orderNumber/files', (req, res) => {
  if (!isAdmin(req)) return res.status(403).json({ error: 'Forbidden' });
  const row = db.prepare('SELECT id FROM orders WHERE order_number = ?').get(req.params.orderNumber);
  if (!row) return res.status(404).json({ error: 'Order not found' });
  const files = db.prepare('SELECT id, filename, original_name, mime_type, size, uploaded_at FROM order_files WHERE order_id = ?').all(row.id);
  res.json({ files });
});

module.exports = router;
EOF

# server/routes/payments.js
cat > "$OUTDIR/server/routes/payments.js" <<'EOF'
const express = require('express');
const db = require('../db');
const fetch = global.fetch; // Node 18+ has global fetch
const dotenv = require('dotenv');
dotenv.config();

const router = express.Router();

const PAYPAL_CLIENT_ID = process.env.PAYPAL_CLIENT_ID;
const PAYPAL_CLIENT_SECRET = process.env.PAYPAL_CLIENT_SECRET;
const PAYPAL_WEBHOOK_ID = process.env.PAYPAL_WEBHOOK_ID; // configure in your PayPal app
const PAYPAL_API = process.env.NODE_ENV === 'production' ? 'https://api-m.paypal.com' : 'https://api-m.sandbox.paypal.com';

// get access token
async function getAccessToken() {
  const auth = Buffer.from(`${PAYPAL_CLIENT_ID}:${PAYPAL_CLIENT_SECRET}`).toString('base64');
  const res = await fetch(`${PAYPAL_API}/v1/oauth2/token`, {
    method: 'POST',
    headers: {
      Authorization: `Basic ${auth}`,
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: 'grant_type=client_credentials'
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error('Failed to get PayPal token: ' + text);
  }
  const data = await res.json();
  return data.access_token;
}

// Create PayPal order for an existing orderNumber
router.post('/create-paypal-order', async (req, res) => {
  try {
    const { orderNumber } = req.body;
    if (!orderNumber) return res.status(400).json({ error: 'orderNumber required' });
    const order = db.prepare('SELECT * FROM orders WHERE order_number = ?').get(orderNumber);
    if (!order) return res.status(404).json({ error: 'Order not found' });

    const accessToken = await getAccessToken();
    const body = {
      intent: 'CAPTURE',
      purchase_units: [{
        reference_id: order.order_number,
        amount: {
          currency_code: 'USD',
          value: String(Number(order.price).toFixed(2))
        }
      }]
    };

    const resp = await fetch(`${PAYPAL_API}/v2/checkout/orders`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    });

    const data = await resp.json();
    if (!resp.ok) {
      return res.status(500).json({ error: 'Failed to create PayPal order', details: data });
    }
    res.json({ id: data.id });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Capture PayPal order after approval
router.post('/capture-paypal-order', async (req, res) => {
  try {
    const { orderID, orderNumber } = req.body;
    if (!orderID || !orderNumber) return res.status(400).json({ error: 'orderID and orderNumber required' });

    const accessToken = await getAccessToken();
    const resp = await fetch(`${PAYPAL_API}/v2/checkout/orders/${orderID}/capture`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      }
    });
    const data = await resp.json();
    if (!resp.ok) {
      return res.status(500).json({ error: 'Failed to capture PayPal order', details: data });
    }

    // Find capture id and update order as paid
    const capture = (data.purchase_units?.[0]?.payments?.captures?.[0]) || null;
    const captureId = capture ? capture.id : (data.id || null);

    const stmt = db.prepare('UPDATE orders SET paid = 1, payment_id = ?, status = ?, updated_at = CURRENT_TIMESTAMP WHERE order_number = ?');
    stmt.run(captureId, 'paid', orderNumber);

    res.json({ ok: true, capture: data });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Webhook endpoint to verify PayPal events (e.g., PAYMENT.CAPTURE.COMPLETED)
router.post('/webhook', express.raw({ type: '*/*' }), async (req, res) => {
  try {
    // Extract PayPal headers
    const transmissionId = req.headers['paypal-transmission-id'];
    const transmissionTime = req.headers['paypal-transmission-time'];
    const certUrl = req.headers['paypal-cert-url'];
    const authAlgo = req.headers['paypal-auth-algo'];
    const transmissionSig = req.headers['paypal-transmission-sig'];
    const webhookId = PAYPAL_WEBHOOK_ID;

    if (!transmissionId || !transmissionTime || !certUrl || !authAlgo || !transmissionSig || !webhookId) {
      console.warn('Missing PayPal webhook headers or webhook id');
      return res.status(400).end();
    }

    const accessToken = await getAccessToken();

    const verifyPayload = {
      auth_algo: authAlgo,
      cert_url: certUrl,
      transmission_id: transmissionId,
      transmission_sig: transmissionSig,
      transmission_time: transmissionTime,
      webhook_id: webhookId,
      webhook_event: JSON.parse(req.body.toString())
    };

    const verifyResp = await fetch(`${PAYPAL_API}/v1/notifications/verify-webhook-signature`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(verifyPayload)
    });

    const verifyData = await verifyResp.json();
    if (!verifyResp.ok || verifyData.verification_status !== 'SUCCESS') {
      console.warn('Webhook verification failed', verifyData);
      return res.status(400).json({ verified: false, details: verifyData });
    }

    const event = verifyPayload.webhook_event;
    // handle payment capture completed events
    if (event.event_type === 'PAYMENT.CAPTURE.COMPLETED' || event.event_type === 'PAYMENT.CAPTURE.DENIED') {
      const resource = event.resource;
      const captureId = resource.id;
      const referenceId = resource.supplementary_data?.related_ids?.order_id || resource.invoice_id || resource.custom_id || null;
      // If we have reference id mapping to our order_number, update order as paid
      if (referenceId) {
        const stmt = db.prepare('UPDATE orders SET paid = 1, payment_id = ?, status = ?, updated_at = CURRENT_TIMESTAMP WHERE order_number = ?');
        stmt.run(captureId, 'paid', referenceId);
      }
    }

    res.json({ verified: true });
  } catch (err) {
    console.error('Webhook processing error', err);
    res.status(500).end();
  }
});

module.exports = router;
EOF

# client dir
mkdir -p "$OUTDIR/client/src/admin" "$OUTDIR/client/src/components"

# client/package.json
cat > "$OUTDIR/client/package.json" <<'EOF'
{
  "name": "client",
  "version": "0.0.0",
  "private": true,
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "axios": "^1.5.0",
    "react": "^18.2.0",
    "react-dom": "^18.2.0"
  },
  "devDependencies": {
    "vite": "^5.0.0"
  }
}
EOF

# client/index.html
cat > "$OUTDIR/client/index.html" <<'EOF'
<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>WriteHunters</title>
    <link rel="stylesheet" href="/src/styles.css" />
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.jsx"></script>
  </body>
</html>
EOF

# client/src/main.jsx
cat > "$OUTDIR/client/src/main.jsx" <<'EOF'
import React from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'
import Admin from './admin/Admin'
import './styles.css'

const root = createRoot(document.getElementById('root'))

if (window.location.pathname.startsWith('/admin')) {
  root.render(<Admin />)
} else {
  root.render(<App />)
}
EOF

# client/src/admin/Admin.jsx
cat > "$OUTDIR/client/src/admin/Admin.jsx" <<'EOF'
import React, { useState } from 'react'
import axios from 'axios'

export default function Admin() {
  const [password, setPassword] = useState('')
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const headers = password ? { 'X-Admin-Password': password } : {}

  const fetchOrders = async () => {
    setLoading(true)
    setError('')
    try {
      const res = await axios.get('/api/admin/orders', { headers })
      setOrders(res.data.orders || [])
    } catch (err) {
      setError(err.response?.data?.error || err.message)
    } finally {
      setLoading(false)
    }
  }

  const changeStatus = async (orderNumber, status) => {
    try {
      await axios.post(`/api/admin/orders/${orderNumber}/status`, { status }, { headers })
      fetchOrders()
    } catch (err) {
      alert('Error updating status')
    }
  }

  const assignWriter = async (orderNumber, writer) => {
    try {
      await axios.post(`/api/admin/orders/${orderNumber}/assign`, { writer }, { headers })
      fetchOrders()
    } catch (err) {
      alert('Error assigning writer')
    }
  }

  const viewFiles = async (orderNumber) => {
    try {
      const res = await axios.get(`/api/admin/orders/${orderNumber}/files`, { headers })
      const files = res.data.files || []
      if (files.length === 0) return alert('No files')
      const list = files.map(f => `<a href="/uploads/${f.filename}" target="_blank" rel="noreferrer">${f.original_name}</a>`).join('<br/>')
      const w = window.open('', '_blank')
      w.document.write(`<h3>Files for ${orderNumber}</h3>${list}`)
    } catch (err) {
      alert('Error fetching files')
    }
  }

  return (
    <div style={{ padding: 24, maxWidth: 1000, margin: '0 auto' }}>
      <h1>WriteHunters — Admin</h1>
      <p>Enter admin password (X-Admin-Password) to authenticate for this quick admin SPA.</p>
      <div style={{ marginBottom: 12 }}>
        <input value={password} onChange={e => setPassword(e.target.value)} placeholder="Admin password" style={{ padding: 8, width: 300 }} />
        <button onClick={fetchOrders} style={{ marginLeft: 8, padding: '8px 12px' }}>Load Orders</button>
      </div>
      {loading && <p>Loading...</p>}
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <div>
        {orders.map(o => (
          <div key={o.order_number} style={{ border: '1px solid #eee', padding: 12, marginBottom: 8 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <div>
                <strong>{o.order_number}</strong> — {o.service_type} — ${o.price} — status: {o.status} — paid: {o.paid ? 'Yes' : 'No'}
                <div>Assigned writer: {o.assigned_writer || '—'}</div>
                <div>Instructions: {o.instructions}</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ marginBottom: 6 }}>
                  <button onClick={() => changeStatus(o.order_number, 'in progress')}>In Progress</button>
                  <button onClick={() => changeStatus(o.order_number, 'completed')} style={{ marginLeft: 6 }}>Mark Completed</button>
                  <button onClick={() => changeStatus(o.order_number, 'cancelled')} style={{ marginLeft: 6 }}>Cancel</button>
                </div>

                <div style={{ marginBottom: 6 }}>
                  <input id={`writer-${o.order_number}`} placeholder="writer@example.com" style={{ padding: 6 }} />
                  <button onClick={() => assignWriter(o.order_number, document.getElementById(`writer-${o.order_number}`).value)} style={{ marginLeft: 6 }}>Assign</button>
                </div>

                <div>
                  <button onClick={() => viewFiles(o.order_number)}>View Files</button>
                </div>
              </div>
            </div>
          </div>
        ))}
        {orders.length === 0 && <p>No orders loaded</p>}
      </div>
    </div>
  )
}
EOF

# client/src/components/ThemeToggle.jsx
cat > "$OUTDIR/client/src/components/ThemeToggle.jsx" <<'EOF'
import React, { useEffect, useState } from 'react';

const THEMES = [
  { id: 'default', label: 'Vibrant', className: '' },
  { id: 'academic', label: 'Academic', className: 'theme-academic' },
  { id: 'mint', label: 'Mint', className: 'theme-mint' },
  { id: 'dark', label: 'Dark', className: 'theme-dark' }
];

export default function ThemeToggle() {
  const [theme, setTheme] = useState(() => {
    try {
      return localStorage.getItem('wh_theme') || 'default';
    } catch {
      return 'default';
    }
  });

  useEffect(() => {
    applyTheme(theme);
  }, [theme]);

  function applyTheme(id) {
    const doc = document.documentElement;
    THEMES.forEach(t => {
      if (t.className) doc.classList.remove(t.className);
    });
    const chosen = THEMES.find(t => t.id === id);
    if (chosen && chosen.className) {
      doc.classList.add(chosen.className);
    }
    try {
      localStorage.setItem('wh_theme', id);
    } catch {}
  }

  function handleSelect(id) {
    setTheme(id);
  }

  return (
    <div className="theme-toggle" role="toolbar" aria-label="Theme selector">
      {THEMES.map(t => (
        <button
          key={t.id}
          onClick={() => handleSelect(t.id)}
          aria-pressed={theme === t.id}
          title={`Switch to ${t.label} theme`}
          style={{
            outline: theme === t.id ? '2px solid rgba(255,255,255,0.92)' : 'none',
            padding: 4,
            borderRadius: 8,
            minWidth: 40,
            display: 'inline-flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
        >
          <span
            className={`swatch ${t.id === 'default' ? 'default' : t.id === 'academic' ? 'academic' : t.id === 'mint' ? 'mint' : 'dark'}`}
            aria-hidden="true"
            style={{ display: 'inline-block' }}
          />
        </button>
      ))}
    </div>
  );
}
EOF

# client/src/App.jsx
cat > "$OUTDIR/client/src/App.jsx" <<'EOF'
import React, { useState } from 'react'
import axios from 'axios'
import ThemeToggle from './components/ThemeToggle'

function Header() {
  return (
    <header className="site-header">
      <div className="container">
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <h1>WriteHunters</h1>
          <nav style={{ display: 'flex', gap: 12 }}>
            <a href="#services">Services</a>
            <a href="#order">Order Now</a>
            <a href="#contact">Contact</a>
            <a href="/legal/privacy.html" target="_blank" rel="noreferrer">Privacy</a>
            <a href="/admin" className="admin-link">Admin</a>
          </nav>
        </div>

        <div className="right-controls">
          <ThemeToggle />
        </div>
      </div>
    </header>
  )
}

function OrderForm() {
  const [form, setForm] = useState({ serviceType: 'Essay', pages: 1, academicLevel: 'Undergraduate', deadline: '', instructions: '' })
  const [price, setPrice] = useState(0)
  const [createdOrder, setCreatedOrder] = useState(null)
  const [file, setFile] = useState(null)
  const [uploading, setUploading] = useState(false)
  const [payloaded, setPayloaded] = useState(false)

  const calcPrice = () => {
    const base = form.serviceType === 'Research' ? 6 : form.serviceType === 'Editing' ? 3 : form.serviceType === 'Class Management' ? 50 : 4
    if (form.serviceType === 'Class Management') return base
    return Math.max(1, Number(form.pages)) * base
  }

  React.useEffect(()=> setPrice(calcPrice()), [form])

  const submit = async (e) => {
    e.preventDefault()
    try {
      const res = await axios.post('/api/orders/create', form, { withCredentials: true })
      setCreatedOrder(res.data.order)
    } catch (err) {
      alert('Error creating order: ' + (err.response?.data?.error || err.message))
    }
  }

  const uploadFile = async (e) => {
    e.preventDefault()
    if (!file || !createdOrder) return alert('Select a file and create order first')
    setUploading(true)
    try {
      const fd = new FormData()
      fd.append('file', file)
      await axios.post(`/api/orders/${createdOrder.order_number}/upload`, fd, { withCredentials: true, headers: { 'Content-Type': 'multipart/form-data' } })
      alert('Uploaded')
    } catch (err) {
      alert('Upload failed')
    } finally {
      setUploading(false)
    }
  }

  React.useEffect(() => {
    if (!createdOrder || payloaded) return
    const script = document.createElement('script')
    const clientId = import.meta.env.VITE_PAYPAL_CLIENT_ID || ''
    const cid = clientId || 'sb'
    script.src = `https://www.paypal.com/sdk/js?client-id=${cid}&currency=USD`
    script.async = true
    script.onload = () => {
      if (!window.paypal) return
      window.paypal.Buttons({
        createOrder: async () => {
          const res = await fetch('/api/payments/create-paypal-order', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ orderNumber: createdOrder.order_number })
          })
          const data = await res.json()
          if (!res.ok) throw new Error(data?.error || 'Failed to create PayPal order')
          return data.id
        },
        onApprove: async (data, actions) => {
          const res = await fetch('/api/payments/capture-paypal-order', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ orderID: data.orderID || data.orderID, orderNumber: createdOrder.order_number })
          })
          const capture = await res.json()
          if (res.ok) {
            alert('Payment captured and order marked paid.')
            setPayloaded(true)
          } else {
            alert('Capture failed: ' + JSON.stringify(capture))
          }
        },
        onError: (err) => {
          console.error('PayPal error', err)
          alert('PayPal error')
        }
      }).render('#paypal-button-container')
    }
    document.body.appendChild(script)
  }, [createdOrder, payloaded])

  return (
    <section id="order" className="order-section container">
      <h2>Place an Order</h2>
      <form onSubmit={submit}>
        <label>Service
          <select value={form.serviceType} onChange={e => setForm({...form, serviceType: e.target.value})}>
            <option>Essay</option>
            <option>Research</option>
            <option>Editing</option>
            <option>Class Management</option>
          </select>
        </label>
        <label>Academic Level
          <select value={form.academicLevel} onChange={e => setForm({...form, academicLevel: e.target.value})}>
            <option>Undergraduate</option>
            <option>Masters</option>
            <option>PhD</option>
          </select>
        </label>
        <label>Pages
          <input type="number" value={form.pages} min="1" onChange={e => setForm({...form, pages: e.target.value})} />
        </label>
        <label>Deadline
          <input type="date" value={form.deadline} onChange={e => setForm({...form, deadline: e.target.value})} />
        </label>
        <label>Instructions
          <textarea value={form.instructions} onChange={e => setForm({...form, instructions: e.target.value})} />
        </label>

        <div className="price">Estimated price: ${price}</div>

        <button type="submit" className="btn primary">Create Order</button>

        {createdOrder && (
          <div className="order-created">
            <p>Order created: <strong>{createdOrder.order_number}</strong></p>
            <p>Price: ${createdOrder.price}</p>

            <div style={{ marginTop: 12 }}>
              <h4>Upload File (drafts / attachments)</h4>
              <input type="file" onChange={e => setFile(e.target.files?.[0] || null)} />
              <button onClick={uploadFile} disabled={uploading} className="btn" style={{ marginLeft: 8 }}>{uploading ? 'Uploading...' : 'Upload'}</button>
            </div>

            <div style={{ marginTop: 16 }}>
              <h4>Pay with PayPal</h4>
              <div id="paypal-button-container"></div>
            </div>
          </div>
        )}
      </form>
    </section>
  )
}

function Services() {
  return (
    <section id="services" className="container services">
      <h2>Services</h2>
      <ul>
        <li>Essay Writing — From $4/page</li>
        <li>Research Papers — From $6/page</li>
        <li>Editing & Proofreading — From $3/page</li>
        <li>Class Management — From $50/week</li>
      </ul>
    </section>
  )
}

function Contact() {
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: ''})
  const submit = async (e) => {
    e.preventDefault()
    try {
      await axios.post('/api/contact', form)
      alert('Message sent. We will respond to writehunters@gmail.com')
    } catch (err) {
      alert('Error sending message')
    }
  }
  return (
    <section id="contact" className="container">
      <h2>Contact Us</h2>
      <form onSubmit={submit}>
        <label>Name<input value={form.name} onChange={e => setForm({...form, name: e.target.value})} /></label>
        <label>Email<input value={form.email} onChange={e => setForm({...form, email: e.target.value})} /></label>
        <label>Subject<input value={form.subject} onChange={e => setForm({...form, subject: e.target.value})} /></label>
        <label>Message<textarea value={form.message} onChange={e => setForm({...form, message: e.target.value})} /></label>
        <button className="btn">Send Message</button>
      </form>

      <div className="social">
        <a href="https://www.facebook.com/profile.php?id=61577361405554" target="_blank" rel="noreferrer">Facebook</a>
        <a href="https://www.instagram.com/writehunters/" target="_blank" rel="noreferrer">Instagram</a>
        <a className="whatsapp" href="https://wa.me/254748881893" target="_blank" rel="noreferrer">Chat on WhatsApp</a>
      </div>
    </section>
  )
}

function Footer() {
  return (
    <footer className="site-footer">
      <div className="container">
        <p>&copy; {new Date().getFullYear()} WriteHunters — Integrity · Excellence · Support</p>
      </div>
    </footer>
  )
}

export default function App() {
  return (
    <div>
      <Header />
      <main>
        <section className="hero container">
          <h2>Your academic success partner</h2>
          <p>High-quality academic writing, editing and class management support — secure, confidential, affordable.</p>
          <a href="#order" className="btn primary">Order Now</a>
          <a href="#contact" className="btn">Contact Us</a>
        </section>

        <Services />
        <OrderForm />
        <Contact />
      </main>
      <Footer />
    </div>
  )
}
EOF

# client/src/styles.css
cat > "$OUTDIR/client/src/styles.css" <<'EOF'
:root{
  --accent: #2d7cf3;
  --accent-2: #8b5cf6;
  --bg: #f7fafc;
  --card: #ffffff;
  --text: #0f1724;
  --muted: #6b7280;
  --radius: 12px;
  --max-width: 1100px;
  --gradient: linear-gradient(90deg, var(--accent), var(--accent-2));
  --shadow: 0 6px 18px rgba(16,24,40,0.06);
  --glass: rgba(255,255,255,0.6);
  --success: #10b981;
  --danger: #ef4444;
  --link: var(--accent);
  --transition: 300ms ease;
}

/* Dark theme */
.theme-dark {
  --accent: #1e90ff;
  --accent-2: #6a11cb;
  --bg: #0b1220;
  --card: #071025;
  --text: #e6eef8;
  --muted: #9aa6b2;
  --gradient: linear-gradient(90deg, var(--accent), var(--accent-2));
  --glass: rgba(255,255,255,0.03);
  --shadow: 0 10px 30px rgba(2,6,23,0.6);
}

/* Academic theme: warm, scholarly */
.theme-academic {
  --accent: #8b1e3f;
  --accent-2: #f59e0b;
  --bg: #fbfaf7;
  --card: #ffffff;
  --text: #0b1220;
  --muted: #6b7280;
  --gradient: linear-gradient(90deg, var(--accent), var(--accent-2));
  --glass: rgba(255,250,240,0.6);
}

/* Mint theme: fresh, modern */
.theme-mint {
  --accent: #00c389;
  --accent-2: #00b4d8;
  --bg: #f0fdf9;
  --card: #ffffff;
  --text: #023020;
  --muted: #2a6f66;
  --gradient: linear-gradient(90deg, var(--accent), var(--accent-2));
  --glass: rgba(240,253,249,0.6);
}

* {
  box-sizing: border-box;
  transition: background-color var(--transition), color var(--transition), border-color var(--transition), box-shadow var(--transition);
}

body {
  font-family: Inter, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;
  background: var(--bg);
  color: var(--text);
  margin: 0;
  -webkit-font-smoothing:antialiased;
  -moz-osx-font-smoothing:grayscale;
}

.container {
  max-width: var(--max-width);
  margin: 0 auto;
  padding: 2rem;
}

.site-header {
  background: var(--gradient);
  color: white;
  padding: 1rem 0;
  box-shadow: var(--shadow);
}
.site-header .container {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
}
.site-header h1 {
  margin: 0;
  font-weight: 700;
  letter-spacing: -0.02em;
}
.site-header nav {
  display: flex;
  align-items: center;
  gap: 1rem;
}
.site-header nav a {
  color: rgba(255,255,255,0.95);
  margin-left: 1rem;
  text-decoration: none;
  font-weight: 600;
}
.site-header .right-controls {
  display: flex;
  align-items: center;
  gap: 0.75rem;
}

.hero {
  background: linear-gradient(180deg, rgba(255,255,255,0.6), transparent);
  border-radius: var(--radius);
  padding: 2rem;
  margin: 2rem 0;
  text-align: center;
  box-shadow: var(--shadow);
}
.hero h2 {
  margin: 0 0 0.5rem 0;
  font-size: 1.9rem;
  color: var(--text);
}
.hero p {
  margin: 0 0 1rem 0;
  color: var(--muted);
}

.services, .order-section, #contact {
  background: var(--card);
  border-radius: var(--radius);
  padding: 1.5rem;
  margin: 1rem 0;
  box-shadow: var(--shadow);
  border: 1px solid rgba(15,23,36,0.04);
}

label {
  display: block;
  margin-bottom: 0.75rem;
  color: var(--text);
  font-weight: 600;
}
input[type="text"], input[type="email"], input[type="number"], input[type="date"], select, textarea {
  width: 100%;
  padding: 0.6rem;
  border: 1px solid rgba(15,23,36,0.08);
  border-radius: 8px;
  background: linear-gradient(180deg, rgba(255,255,255,0.6), transparent);
  color: var(--text);
}
textarea { min-height: 100px; }
.btn {
  display: inline-block;
  padding: 0.6rem 1rem;
  border-radius: 8px;
  text-decoration: none;
  background: transparent;
  color: var(--link);
  border: 1px solid rgba(15,23,36,0.06);
  cursor: pointer;
  font-weight: 700;
}
.btn.primary {
  background: var(--gradient);
  color: white;
  border: none;
  box-shadow: 0 8px 24px rgba(45,124,243,0.18);
}

.price { font-weight: 700; margin: 0.5rem 0; color: var(--text); }
.order-created {
  margin-top: 1rem;
  padding: 1rem;
  background: var(--glass);
  border-radius: 8px;
  border: 1px solid rgba(15,23,36,0.04);
}

.site-footer {
  padding: 2rem 0;
  text-align: center;
  color: var(--muted);
}

.theme-toggle {
  display: flex;
  gap: 8px;
  align-items: center;
}
.theme-toggle button {
  border: none;
  background: transparent;
  cursor: pointer;
  padding: 6px;
  border-radius: 8px;
  display: inline-flex;
  align-items: center;
  gap: 8px;
  color: white;
  font-weight: 600;
}
.theme-toggle .swatch {
  width: 32px;
  height: 20px;
  border-radius: 6px;
  box-shadow: 0 4px 12px rgba(2,6,23,0.12);
  border: 1px solid rgba(255,255,255,0.18);
}
.theme-toggle .swatch.default { background: linear-gradient(90deg, #2d7cf3, #8b5cf6); }
.theme-toggle .swatch.academic { background: linear-gradient(90deg, #8b1e3f, #f59e0b); }
.theme-toggle .swatch.mint { background: linear-gradient(90deg, #00c389, #00b4d8); }
.theme-toggle .swatch.dark { background: linear-gradient(90deg, #1e90ff, #6a11cb); }

@media (max-width: 720px) {
  .site-header .container { flex-direction: column; align-items: flex-start; gap: 12px; }
  .site-header nav { order: 2; width: 100%; display: flex; justify-content: space-between; }
}

@media (min-width:800px){
  .order-section form { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
  .order-section form label { grid-column: span 1; }
  .order-section form textarea { grid-column: 1 / 3; }
}
EOF

# client/src/App.jsx already created; ensured above

# legal pages
mkdir -p "$OUTDIR/legal"
cat > "$OUTDIR/legal/privacy.html" <<'EOF'
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Privacy Policy - WriteHunters</title></head>
<body>
<h1>Privacy Policy</h1>
<p>WriteHunters respects your privacy. We collect only data necessary to provide services: account email, order details, and communication you provide. We secure data using encryption in transit and hashed credentials. For full policy, configure this file with your legal counsel.</p>
<a href="/legal/cookies.html">Cookie Policy</a> | <a href="/legal/terms.html">Terms & Conditions</a>
</body></html>
EOF

cat > "$OUTDIR/legal/cookies.html" <<'EOF'
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Cookie Policy - WriteHunters</title></head>
<body>
<h1>Cookie Policy</h1>
<p>We use cookies to maintain sessions and improve UX. You can control cookies through your browser.</p>
</body></html>
EOF

cat > "$OUTDIR/legal/terms.html" <<'EOF'
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Terms & Conditions - WriteHunters</title></head>
<body>
<h1>Terms & Conditions</h1>
<p>Terms & conditions go here. This is a starter template — consult legal counsel before publishing.</p>
</body></html>
EOF

# admin route client already added

# finally zip
echo "Zipping project to $ZIPNAME ..."
cd "$OUTDIR/.."
zip -r "$ZIPNAME" "$(basename "$OUTDIR")" >/dev/null
mv "$ZIPNAME" "$(pwd)/$ZIPNAME"
cd - >/dev/null

echo "Done. Created $ZIPNAME"
ls -lh "$ZIPNAME"
EOF