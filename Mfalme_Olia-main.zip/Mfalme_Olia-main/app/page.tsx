import ClientPage from "./ClientPage"

export const metadata = {
  title: "WriteHunters - Professional Academic Writing Services | Essays, Research Papers & More",
  description:
    "Get expert academic writing help from WriteHunters. Professional essay writing, research papers, editing & proofreading services. 24/7 support, plagiarism-free work, on-time delivery guaranteed.",
  keywords:
    "academic writing, essay writing service, research papers, editing, proofreading, WriteHunters, Kenya academic writing, university essays, dissertation help",
  openGraph: {
    title: "WriteHunters - Professional Academic Writing Services",
    description:
      "Expert academic writing services with 5000+ satisfied students. Essays, research papers, editing & more. Get started today!",
    type: "website",
    url: "https://writehunters.com",
    images: [
      {
        url: "/academic-writing-hero.png",
        width: 1200,
        height: 630,
        alt: "WriteHunters - Professional Academic Writing Services",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "WriteHunters - Professional Academic Writing Services",
    description:
      "Expert academic writing services with 5000+ satisfied students. Essays, research papers, editing & more.",
    images: ["/academic-writing-hero.png"],
  },
}

export default function HomePage() {
  return <ClientPage />
}
