"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { X, Sparkles, ArrowRight, Clock } from "lucide-react"

export default function FloatingPromoBanner() {
  const [isVisible, setIsVisible] = useState(false)
  const [timeLeft, setTimeLeft] = useState({
    hours: 23,
    minutes: 45,
    seconds: 30,
  })

  useEffect(() => {
    // Show banner after 10 seconds
    const showTimer = setTimeout(() => {
      setIsVisible(true)
    }, 10000)

    // Countdown timer
    const countdownTimer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 }
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 }
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 }
        }
        return prev
      })
    }, 1000)

    return () => {
      clearTimeout(showTimer)
      clearInterval(countdownTimer)
    }
  }, [])

  if (!isVisible) return null

  return (
    <div className="fixed bottom-6 right-6 z-50 max-w-sm animate-slide-up">
      <div className="bg-gradient-to-r from-coral to-purple text-white rounded-2xl shadow-2xl p-6 relative overflow-hidden">
        {/* Background decoration */}
        <div className="absolute top-0 right-0 w-20 h-20 bg-white/10 rounded-full -translate-y-10 translate-x-10"></div>
        <div className="absolute bottom-0 left-0 w-16 h-16 bg-white/10 rounded-full translate-y-8 -translate-x-8"></div>

        <button onClick={() => setIsVisible(false)} className="absolute top-3 right-3 text-white/70 hover:text-white">
          <X className="h-4 w-4" />
        </button>

        <div className="relative">
          <Badge className="bg-white/20 text-white border-white/30 mb-3">
            <Sparkles className="h-3 w-3 mr-1" />
            Limited Time Offer
          </Badge>

          <h3 className="font-bold text-lg mb-2">Get 25% OFF Your First Order!</h3>
          <p className="text-sm opacity-90 mb-4">New customers only. Professional academic writing services.</p>

          <div className="flex items-center space-x-2 mb-4">
            <Clock className="h-4 w-4" />
            <span className="text-sm font-medium">
              Expires in: {String(timeLeft.hours).padStart(2, "0")}:{String(timeLeft.minutes).padStart(2, "0")}:
              {String(timeLeft.seconds).padStart(2, "0")}
            </span>
          </div>

          <Button className="w-full bg-white text-coral hover:bg-gray-100 font-semibold">
            <a href="/order" className="flex items-center justify-center space-x-2 w-full">
              <span>Claim Discount</span>
              <ArrowRight className="h-4 w-4" />
            </a>
          </Button>
        </div>
      </div>
    </div>
  )
}
