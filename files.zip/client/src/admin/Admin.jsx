import React, { useState } from 'react'
import axios from 'axios'

export default function Admin() {
  const [password, setPassword] = useState('')
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const headers = password ? { 'X-Admin-Password': password } : {}

  const fetchOrders = async () => {
    setLoading(true)
    setError('')
    try {
      const res = await axios.get('/api/admin/orders', { headers })
      setOrders(res.data.orders || [])
    } catch (err) {
      setError(err.response?.data?.error || err.message)
    } finally {
      setLoading(false)
    }
  }

  const changeStatus = async (orderNumber, status) => {
    try {
      await axios.post(`/api/admin/orders/${orderNumber}/status`, { status }, { headers })
      fetchOrders()
    } catch (err) {
      alert('Error updating status')
    }
  }

  const assignWriter = async (orderNumber, writer) => {
    try {
      await axios.post(`/api/admin/orders/${orderNumber}/assign`, { writer }, { headers })
      fetchOrders()
    } catch (err) {
      alert('Error assigning writer')
    }
  }

  const viewFiles = async (orderNumber) => {
    try {
      const res = await axios.get(`/api/admin/orders/${orderNumber}/files`, { headers })
      const files = res.data.files || []
      if (files.length === 0) return alert('No files')
      const list = files.map(f => `<a href="/uploads/${f.filename}" target="_blank" rel="noreferrer">${f.original_name}</a>`).join('<br/>')
      const w = window.open('', '_blank')
      w.document.write(`<h3>Files for ${orderNumber}</h3>${list}`)
    } catch (err) {
      alert('Error fetching files')
    }
  }

  return (
    <div style={{ padding: 24, maxWidth: 1000, margin: '0 auto' }}>
      <h1>WriteHunters — Admin</h1>
      <p>Enter admin password (X-Admin-Password) to authenticate for this quick admin SPA.</p>
      <div style={{ marginBottom: 12 }}>
        <input value={password} onChange={e => setPassword(e.target.value)} placeholder="Admin password" style={{ padding: 8, width: 300 }} />
        <button onClick={fetchOrders} style={{ marginLeft: 8, padding: '8px 12px' }}>Load Orders</button>
      </div>
      {loading && <p>Loading...</p>}
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <div>
        {orders.map(o => (
          <div key={o.order_number} style={{ border: '1px solid #eee', padding: 12, marginBottom: 8 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <div>
                <strong>{o.order_number}</strong> — {o.service_type} — ${o.price} — status: {o.status} — paid: {o.paid ? 'Yes' : 'No'}
                <div>Assigned writer: {o.assigned_writer || '—'}</div>
                <div>Instructions: {o.instructions}</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ marginBottom: 6 }}>
                  <button onClick={() => changeStatus(o.order_number, 'in progress')}>In Progress</button>
                  <button onClick={() => changeStatus(o.order_number, 'completed')} style={{ marginLeft: 6 }}>Mark Completed</button>
                  <button onClick={() => changeStatus(o.order_number, 'cancelled')} style={{ marginLeft: 6 }}>Cancel</button>
                </div>

                <div style={{ marginBottom: 6 }}>
                  <input id={`writer-${o.order_number}`} placeholder="writer@example.com" style={{ padding: 6 }} />
                  <button onClick={() => assignWriter(o.order_number, document.getElementById(`writer-${o.order_number}`).value)} style={{ marginLeft: 6 }}>Assign</button>
                </div>

                <div>
                  <button onClick={() => viewFiles(o.order_number)}>View Files</button>
                </div>
              </div>
            </div>
          </div>
        ))}
        {orders.length === 0 && <p>No orders loaded</p>}
      </div>
    </div>
  )
}