import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BookOpen, Cookie, Settings, Eye, Shield, Info } from "lucide-react"
import Link from "next/link"

export const metadata = {
  title: "Cookie Policy - WriteHunters Academic Writing Services",
  description:
    "Learn about WriteHunters' cookie policy and how we use cookies to improve your experience on our academic writing services website.",
  keywords: "WriteHunters cookie policy, website cookies, tracking, academic writing cookies",
  openGraph: {
    title: "Cookie Policy - WriteHunters",
    description: "Understand how WriteHunters uses cookies to enhance your browsing experience.",
    type: "website",
    url: "https://writehunters.com/cookie-policy",
  },
}

export default function CookiePolicyPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <BookOpen className="h-8 w-8 text-primary" />
              <span className="font-serif text-2xl font-bold text-primary">WriteHunters</span>
            </Link>
            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-foreground hover:text-primary transition-colors">
                Home
              </Link>
              <Link href="/services" className="text-foreground hover:text-primary transition-colors">
                Services
              </Link>
              <Link href="/about" className="text-foreground hover:text-primary transition-colors">
                About
              </Link>
              <Link href="/contact" className="text-foreground hover:text-primary transition-colors">
                Contact
              </Link>
            </nav>
            <Button asChild className="bg-coral hover:bg-coral/90 text-coral-foreground">
              <Link href="/order">Place Your Order</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-orange-500 to-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <Cookie className="h-8 w-8 text-white" />
            </div>
            <h1 className="font-serif text-4xl md:text-5xl font-bold text-foreground mb-6">Cookie Policy</h1>
            <p className="text-xl text-muted-foreground">
              Learn how we use cookies to enhance your browsing experience and improve our services.
            </p>
            <p className="text-sm text-muted-foreground mt-4">Last updated: December 2024</p>
          </div>
        </div>
      </section>

      {/* Cookie Policy Content */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="space-y-12">
              {/* What Are Cookies */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Info className="h-6 w-6 mr-3 text-primary" />
                    What Are Cookies?
                  </CardTitle>
                </CardHeader>
                <CardContent className="prose prose-lg max-w-none">
                  <p>
                    Cookies are small text files that are stored on your device (computer, tablet, or mobile) when you
                    visit a website. They are widely used to make websites work more efficiently and provide information
                    to website owners.
                  </p>
                  <p>
                    WriteHunters uses cookies to enhance your browsing experience, analyze website traffic, and provide
                    personalized content. This Cookie Policy explains what cookies we use, why we use them, and how you
                    can manage your cookie preferences.
                  </p>
                </CardContent>
              </Card>

              {/* Types of Cookies */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Cookie className="h-6 w-6 mr-3 text-coral" />
                    Types of Cookies We Use
                  </CardTitle>
                </CardHeader>
                <CardContent className="prose prose-lg max-w-none">
                  <h3>Essential Cookies</h3>
                  <p>
                    These cookies are necessary for the website to function properly. They enable basic functions like
                    page navigation, access to secure areas, and form submissions. The website cannot function properly
                    without these cookies.
                  </p>
                  <ul>
                    <li>Session management cookies</li>
                    <li>Security cookies</li>
                    <li>Load balancing cookies</li>
                  </ul>

                  <h3>Analytics Cookies</h3>
                  <p>
                    These cookies help us understand how visitors interact with our website by collecting and reporting
                    information anonymously. We use this data to improve our website performance and user experience.
                  </p>
                  <ul>
                    <li>Google Analytics cookies</li>
                    <li>Page view tracking</li>
                    <li>User behavior analysis</li>
                  </ul>

                  <h3>Functional Cookies</h3>
                  <p>
                    These cookies enable enhanced functionality and personalization, such as remembering your
                    preferences and providing personalized content.
                  </p>
                  <ul>
                    <li>Language preferences</li>
                    <li>User interface customization</li>
                    <li>Form data retention</li>
                  </ul>

                  <h3>Marketing Cookies</h3>
                  <p>
                    These cookies track your browsing habits to show you relevant advertisements and measure the
                    effectiveness of our marketing campaigns.
                  </p>
                  <ul>
                    <li>Advertising targeting cookies</li>
                    <li>Social media integration cookies</li>
                    <li>Conversion tracking cookies</li>
                  </ul>
                </CardContent>
              </Card>

              {/* Third-Party Cookies */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Eye className="h-6 w-6 mr-3 text-success" />
                    Third-Party Cookies
                  </CardTitle>
                </CardHeader>
                <CardContent className="prose prose-lg max-w-none">
                  <p>We may use third-party services that set cookies on our website. These include:</p>

                  <h3>Google Analytics</h3>
                  <p>
                    We use Google Analytics to analyze website traffic and user behavior. Google Analytics uses cookies
                    to collect information about how you use our website.
                  </p>

                  <h3>Social Media Platforms</h3>
                  <p>
                    Our website includes social media buttons and widgets from platforms like Facebook and Instagram.
                    These may set cookies when you interact with them.
                  </p>

                  <h3>Payment Processors</h3>
                  <p>
                    When you make payments, our payment processors (such as PayPal) may set cookies to facilitate secure
                    transactions.
                  </p>

                  <p>
                    Please note that we do not control these third-party cookies. We recommend reviewing the privacy
                    policies of these third-party services for more information about their cookie practices.
                  </p>
                </CardContent>
              </Card>

              {/* Cookie Management */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Settings className="h-6 w-6 mr-3 text-warning" />
                    Managing Your Cookie Preferences
                  </CardTitle>
                </CardHeader>
                <CardContent className="prose prose-lg max-w-none">
                  <h3>Browser Settings</h3>
                  <p>You can control and manage cookies through your browser settings. Most browsers allow you to:</p>
                  <ul>
                    <li>View cookies stored on your device</li>
                    <li>Delete existing cookies</li>
                    <li>Block cookies from specific websites</li>
                    <li>Block all cookies</li>
                    <li>Set preferences for different types of cookies</li>
                  </ul>

                  <h3>Browser-Specific Instructions</h3>
                  <div className="bg-slate-50 p-6 rounded-lg border">
                    <h4>Google Chrome</h4>
                    <p>Settings → Privacy and Security → Cookies and other site data</p>

                    <h4>Mozilla Firefox</h4>
                    <p>Options → Privacy & Security → Cookies and Site Data</p>

                    <h4>Safari</h4>
                    <p>Preferences → Privacy → Manage Website Data</p>

                    <h4>Microsoft Edge</h4>
                    <p>Settings → Cookies and site permissions → Cookies and site data</p>
                  </div>

                  <h3>Opt-Out Tools</h3>
                  <p>You can also use the following opt-out tools:</p>
                  <ul>
                    <li>Google Analytics Opt-out Browser Add-on</li>
                    <li>Network Advertising Initiative opt-out tool</li>
                    <li>Digital Advertising Alliance opt-out tool</li>
                  </ul>
                </CardContent>
              </Card>

              {/* Impact of Disabling Cookies */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Shield className="h-6 w-6 mr-3 text-purple" />
                    Impact of Disabling Cookies
                  </CardTitle>
                </CardHeader>
                <CardContent className="prose prose-lg max-w-none">
                  <p>
                    While you have the right to disable cookies, please note that doing so may affect your experience on
                    our website:
                  </p>
                  <ul>
                    <li>Some features may not work properly</li>
                    <li>You may need to re-enter information repeatedly</li>
                    <li>Personalized content may not be available</li>
                    <li>Website performance may be reduced</li>
                  </ul>
                  <p>
                    Essential cookies cannot be disabled as they are necessary for the basic functionality of our
                    website.
                  </p>
                </CardContent>
              </Card>

              {/* Cookie Consent */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Eye className="h-6 w-6 mr-3 text-accent" />
                    Cookie Consent
                  </CardTitle>
                </CardHeader>
                <CardContent className="prose prose-lg max-w-none">
                  <p>
                    When you first visit our website, you will see a cookie banner asking for your consent to use
                    non-essential cookies. You can:
                  </p>
                  <ul>
                    <li>Accept all cookies</li>
                    <li>Reject non-essential cookies</li>
                    <li>Customize your cookie preferences</li>
                  </ul>
                  <p>
                    You can change your cookie preferences at any time by clicking the "Cookie Settings" link in our
                    website footer or by adjusting your browser settings.
                  </p>
                </CardContent>
              </Card>

              {/* Updates to Cookie Policy */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Info className="h-6 w-6 mr-3 text-coral" />
                    Updates to This Cookie Policy
                  </CardTitle>
                </CardHeader>
                <CardContent className="prose prose-lg max-w-none">
                  <p>
                    We may update this Cookie Policy from time to time to reflect changes in our practices, technology,
                    or legal requirements. When we make changes, we will:
                  </p>
                  <ul>
                    <li>Update the "Last updated" date at the top of this policy</li>
                    <li>Notify you through our website or email if the changes are significant</li>
                    <li>Request your consent again if required by law</li>
                  </ul>
                  <p>
                    We encourage you to review this Cookie Policy periodically to stay informed about how we use
                    cookies.
                  </p>
                </CardContent>
              </Card>

              {/* Contact Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BookOpen className="h-6 w-6 mr-3 text-primary" />
                    Contact Us
                  </CardTitle>
                </CardHeader>
                <CardContent className="prose prose-lg max-w-none">
                  <p>If you have any questions about this Cookie Policy or our use of cookies, please contact us:</p>
                  <div className="bg-slate-50 p-6 rounded-lg border">
                    <div className="space-y-2">
                      <div>
                        <strong>Email:</strong> writehunters@gmail.com
                      </div>
                      <div>
                        <strong>WhatsApp:</strong> +254 748 881893
                      </div>
                      <div>
                        <strong>Address:</strong> Kenya
                      </div>
                    </div>
                  </div>
                  <p>We will respond to your inquiry as soon as possible, typically within 48 hours.</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-slate-900 to-slate-800 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <BookOpen className="h-6 w-6 text-accent" />
                <span className="font-serif text-xl font-bold">WriteHunters</span>
              </div>
              <p className="text-slate-300">
                Professional academic writing services for students and academics worldwide.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4 text-coral">Services</h4>
              <ul className="space-y-2 text-slate-300">
                <li>
                  <Link href="/services">Essay Writing</Link>
                </li>
                <li>
                  <Link href="/services">Research Papers</Link>
                </li>
                <li>
                  <Link href="/services">Editing & Proofreading</Link>
                </li>
                <li>Class Management</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4 text-purple">Company</h4>
              <ul className="space-y-2 text-slate-300">
                <li>
                  <Link href="/about">About Us</Link>
                </li>
                <li>
                  <Link href="/contact">Contact</Link>
                </li>
                <li>
                  <Link href="/privacy-policy">Privacy Policy</Link>
                </li>
                <li>
                  <Link href="/cookie-policy">Cookie Policy</Link>
                </li>
                <li>
                  <Link href="/terms-conditions">Terms & Conditions</Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4 text-success">Contact</h4>
              <div className="space-y-2 text-slate-300">
                <div>WhatsApp: +254 748 881893</div>
                <div>Email: writehunters@gmail.com</div>
              </div>
            </div>
          </div>

          <div className="border-t border-slate-700 mt-8 pt-8 text-center text-slate-300">
            <p>&copy; 2024 WriteHunters. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
