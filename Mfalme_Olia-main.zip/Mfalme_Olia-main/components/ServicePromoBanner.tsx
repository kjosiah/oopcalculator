"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Users, Star, ArrowRight, TrendingUp } from "lucide-react"

interface ServicePromoBannerProps {
  service: "write-my-paper" | "class-management" | "editing"
}

export default function ServicePromoBanner({ service }: ServicePromoBannerProps) {
  const getServiceConfig = () => {
    switch (service) {
      case "write-my-paper":
        return {
          title: "Need a Paper Written?",
          subtitle: "Professional writers ready to help with your academic papers",
          features: ["100% Original Content", "Expert Writers", "On-Time Delivery"],
          price: "Starting at $4/page",
          ctaText: "Get Started",
          ctaLink: "/write-my-paper",
          icon: <BookOpen className="h-8 w-8 text-white" />,
          gradient: "from-coral to-orange-500",
          badgeColor: "bg-coral",
        }
      case "class-management":
        return {
          title: "Struggling with Classes?",
          subtitle: "Let our experts handle your assignments, exams, and coursework",
          features: ["CATs: $10 each", "Exams: $25 each", "Full Management: $50/week"],
          price: "Flexible Pricing",
          ctaText: "Manage My Classes",
          ctaLink: "/manage-my-classes",
          icon: <Users className="h-8 w-8 text-white" />,
          gradient: "from-purple to-blue-600",
          badgeColor: "bg-purple",
        }
      default:
        return {
          title: "Perfect Your Writing",
          subtitle: "Professional editing and proofreading services",
          features: ["Grammar Check", "Style Improvement", "Structure Optimization"],
          price: "Affordable Rates",
          ctaText: "Edit My Paper",
          ctaLink: "/services",
          icon: <Star className="h-8 w-8 text-white" />,
          gradient: "from-success to-green-600",
          badgeColor: "bg-success",
        }
    }
  }

  const config = getServiceConfig()

  return (
    <Card className="overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-300 hover-lift">
      <CardContent className="p-0">
        <div className={`bg-gradient-to-r ${config.gradient} text-white p-6`}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center">{config.icon}</div>
              <div>
                <h3 className="font-bold text-xl">{config.title}</h3>
                <p className="text-sm opacity-90">{config.subtitle}</p>
              </div>
            </div>
            <Badge className={`${config.badgeColor} text-white border-0`}>
              <TrendingUp className="h-3 w-3 mr-1" />
              Popular
            </Badge>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div>
              <ul className="space-y-2">
                {config.features.map((feature, index) => (
                  <li key={index} className="flex items-center space-x-2 text-sm">
                    <div className="w-1.5 h-1.5 bg-white rounded-full"></div>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold mb-1">{config.price}</div>
              <div className="text-sm opacity-90">Transparent Pricing</div>
            </div>
          </div>

          <Button className="w-full bg-white text-coral hover:bg-gray-100 font-semibold">
            <a href={config.ctaLink} className="flex items-center justify-center space-x-2 w-full">
              <span>{config.ctaText}</span>
              <ArrowRight className="h-4 w-4" />
            </a>
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
