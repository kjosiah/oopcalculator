"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import {
  BookOpen,
  CheckCircle,
  Clock,
  Shield,
  Star,
  Users,
  Award,
  FileText,
  Calculator,
  MessageCircle,
  Mail,
  Phone,
  GraduationCap,
  Calendar,
  Target,
  Zap,
  ArrowRight,
} from "lucide-react"
import Link from "next/link"

export default function ManageMyClassesClientPage() {
  const [serviceType, setServiceType] = useState("")
  const [duration, setDuration] = useState("")
  const [showOrderForm, setShowOrderForm] = useState(false)
  const [selectedPackage, setSelectedPackage] = useState("")

  const getServicePrice = () => {
    switch (serviceType) {
      case "cat":
        return 10
      case "exam":
        return 25
      case "full-weekly":
        return 50
      case "full-monthly":
        return 600
      default:
        return 0
    }
  }

  const handleOrderSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const orderNumber = `WH${Date.now().toString().slice(-6)}${Math.floor(Math.random() * 1000)
      .toString()
      .padStart(3, "0")}`
    const orderData = {
      orderNumber,
      serviceType: "Class Management",
      specificService: serviceType,
      duration,
      totalPrice: getServicePrice(),
      timestamp: new Date().toISOString(),
      status: "pending",
    }
    localStorage.setItem("orderData", JSON.stringify(orderData))
    localStorage.setItem("currentOrderNumber", orderNumber)
    window.location.href = "/payment"
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <BookOpen className="h-8 w-8 text-primary" />
              <span className="font-serif text-2xl font-bold text-primary">WriteHunters</span>
            </Link>
            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-foreground hover:text-primary transition-colors">
                Home
              </Link>
              <Link href="/services" className="text-foreground hover:text-primary transition-colors">
                Services
              </Link>
              <Link href="/about" className="text-foreground hover:text-primary transition-colors">
                About
              </Link>
              <Link href="/blog" className="text-foreground hover:text-primary transition-colors">
                Blog
              </Link>
              <Link href="/contact" className="text-foreground hover:text-primary transition-colors">
                Contact
              </Link>
            </nav>
            <Button onClick={() => setShowOrderForm(true)} className="bg-warning hover:bg-warning/90">
              Manage My Classes
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-warning/5 via-success/5 to-purple/5">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <div className="flex justify-center space-x-4 mb-6">
              <Badge className="bg-warning/10 text-warning border-warning/20">Class Management</Badge>
              <Badge className="bg-success/10 text-success border-success/20">24/7 Support</Badge>
              <Badge className="bg-purple/10 text-purple border-purple/20">Expert Tutors</Badge>
            </div>
            <h1 className="font-serif text-5xl md:text-6xl font-bold text-foreground mb-6">
              <span className="text-warning">Manage My Classes</span> with Expert Support
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
              Let our academic experts handle your coursework, CATs, exams, and assignments. Focus on what matters while
              we ensure your academic success.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Button
                size="lg"
                onClick={() => setShowOrderForm(true)}
                className="bg-warning hover:bg-warning/90 text-lg px-8 py-4"
              >
                <GraduationCap className="h-5 w-5 mr-2" />
                Get Class Management
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="text-lg px-8 py-4 bg-transparent border-success text-success hover:bg-success hover:text-white"
                asChild
              >
                <Link href="#pricing">
                  <Calculator className="h-5 w-5 mr-2" />
                  View Pricing
                </Link>
              </Button>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-2xl mx-auto">
              <div className="text-center">
                <div className="text-3xl font-bold text-warning">500+</div>
                <div className="text-sm text-muted-foreground">Classes Managed</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-success">95%</div>
                <div className="text-sm text-muted-foreground">Pass Rate</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple">4.8/5</div>
                <div className="text-sm text-muted-foreground">Student Rating</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-coral">24/7</div>
                <div className="text-sm text-muted-foreground">Support</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Service Packages */}
      <section id="pricing" className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl font-bold text-foreground mb-4">Choose Your Class Management Package</h2>
            <p className="text-xl text-muted-foreground">
              Flexible options to meet your specific academic needs and budget
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* CATs Package */}
            <Card className="border-2 hover:border-coral/30 transition-all hover:shadow-lg group">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-coral/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-coral/20 transition-colors">
                  <FileText className="h-8 w-8 text-coral" />
                </div>
                <CardTitle className="font-serif text-2xl">CATs Assistance</CardTitle>
                <p className="text-muted-foreground">Individual CAT support</p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Complete CAT preparation
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Research and answers
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Timely submission
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Quality guarantee
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    24/7 communication
                  </div>
                </div>

                <div className="border-t pt-4">
                  <div className="text-center mb-4">
                    <div className="text-3xl font-bold text-coral">$10</div>
                    <div className="text-sm text-muted-foreground">per CAT</div>
                  </div>
                </div>

                <Button
                  className="w-full bg-coral hover:bg-coral/90"
                  onClick={() => {
                    setServiceType("cat")
                    setSelectedPackage("CATs Assistance")
                    setShowOrderForm(true)
                  }}
                >
                  Order CAT Help
                </Button>
              </CardContent>
            </Card>

            {/* Exams Package */}
            <Card className="border-2 hover:border-purple/30 transition-all hover:shadow-lg group">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-purple/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-purple/20 transition-colors">
                  <Award className="h-8 w-8 text-purple" />
                </div>
                <CardTitle className="font-serif text-2xl">Exam Support</CardTitle>
                <p className="text-muted-foreground">Comprehensive exam assistance</p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Exam preparation
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Study materials
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Practice questions
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Live exam support
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Result guarantee
                  </div>
                </div>

                <div className="border-t pt-4">
                  <div className="text-center mb-4">
                    <div className="text-3xl font-bold text-purple">$25</div>
                    <div className="text-sm text-muted-foreground">per exam</div>
                  </div>
                </div>

                <Button
                  className="w-full bg-purple hover:bg-purple/90"
                  onClick={() => {
                    setServiceType("exam")
                    setSelectedPackage("Exam Support")
                    setShowOrderForm(true)
                  }}
                >
                  Order Exam Help
                </Button>
              </CardContent>
            </Card>

            {/* Weekly Management */}
            <Card className="border-2 hover:border-success/30 transition-all hover:shadow-lg group">
              <CardHeader className="text-center pb-4">
                <Badge className="mb-2 bg-success/10 text-success border-success/20">Popular</Badge>
                <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-success/20 transition-colors">
                  <Calendar className="h-8 w-8 text-success" />
                </div>
                <CardTitle className="font-serif text-2xl">Weekly Management</CardTitle>
                <p className="text-muted-foreground">Complete weekly class support</p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    All assignments
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Discussion posts
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Quiz assistance
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Progress tracking
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Weekly reports
                  </div>
                </div>

                <div className="border-t pt-4">
                  <div className="text-center mb-4">
                    <div className="text-3xl font-bold text-success">$50</div>
                    <div className="text-sm text-muted-foreground">per week</div>
                  </div>
                </div>

                <Button
                  className="w-full bg-success hover:bg-success/90"
                  onClick={() => {
                    setServiceType("full-weekly")
                    setSelectedPackage("Weekly Management")
                    setShowOrderForm(true)
                  }}
                >
                  Start Weekly Plan
                </Button>
              </CardContent>
            </Card>

            {/* Monthly Management */}
            <Card className="border-2 hover:border-warning/30 transition-all hover:shadow-lg border-warning/30 group">
              <CardHeader className="text-center pb-4">
                <Badge className="mb-2 bg-warning text-warning-foreground">Best Value</Badge>
                <div className="w-16 h-16 bg-warning/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-warning/20 transition-colors">
                  <Target className="h-8 w-8 text-warning" />
                </div>
                <CardTitle className="font-serif text-2xl">Monthly Management</CardTitle>
                <p className="text-muted-foreground">Complete semester support</p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Full course management
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    All assignments & exams
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Priority support
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Grade guarantee
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Dedicated tutor
                  </div>
                </div>

                <div className="border-t pt-4">
                  <div className="text-center mb-4">
                    <div className="text-3xl font-bold text-warning">$600</div>
                    <div className="text-sm text-muted-foreground">per month</div>
                    <div className="text-xs text-success">Save $200/month</div>
                  </div>
                </div>

                <Button
                  className="w-full bg-warning hover:bg-warning/90"
                  onClick={() => {
                    setServiceType("full-monthly")
                    setSelectedPackage("Monthly Management")
                    setShowOrderForm(true)
                  }}
                >
                  Start Monthly Plan
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Order Form */}
      {showOrderForm && (
        <section className="py-12 bg-white border-t-4 border-warning">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <div className="text-center mb-8">
                <h2 className="font-serif text-3xl font-bold text-foreground mb-4">Order {selectedPackage}</h2>
                <p className="text-muted-foreground">
                  Fill out the form below to get started with your class management
                </p>
              </div>

              <Card className="border-2 border-warning/20">
                <CardContent className="p-8">
                  <form onSubmit={handleOrderSubmit} className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <Label htmlFor="courseName">Course/Subject Name *</Label>
                        <Input placeholder="e.g., Business Statistics, Chemistry 101" required />
                      </div>

                      <div>
                        <Label htmlFor="institution">Institution *</Label>
                        <Input placeholder="Your school/university name" required />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <Label htmlFor="academicLevel">Academic Level *</Label>
                        <Select required>
                          <SelectTrigger>
                            <SelectValue placeholder="Select academic level" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="high-school">High School</SelectItem>
                            <SelectItem value="undergraduate">Undergraduate</SelectItem>
                            <SelectItem value="masters">Master's</SelectItem>
                            <SelectItem value="phd">PhD</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      {(serviceType === "full-weekly" || serviceType === "full-monthly") && (
                        <div>
                          <Label htmlFor="duration">Duration *</Label>
                          <Select value={duration} onValueChange={setDuration} required>
                            <SelectTrigger>
                              <SelectValue placeholder="Select duration" />
                            </SelectTrigger>
                            <SelectContent>
                              {serviceType === "full-weekly" && (
                                <>
                                  <SelectItem value="1-week">1 Week</SelectItem>
                                  <SelectItem value="2-weeks">2 Weeks</SelectItem>
                                  <SelectItem value="4-weeks">4 Weeks</SelectItem>
                                  <SelectItem value="8-weeks">8 Weeks</SelectItem>
                                </>
                              )}
                              {serviceType === "full-monthly" && (
                                <>
                                  <SelectItem value="1-month">1 Month</SelectItem>
                                  <SelectItem value="2-months">2 Months</SelectItem>
                                  <SelectItem value="3-months">3 Months</SelectItem>
                                  <SelectItem value="semester">Full Semester</SelectItem>
                                </>
                              )}
                            </SelectContent>
                          </Select>
                        </div>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="requirements">Specific Requirements *</Label>
                      <Textarea
                        placeholder="Describe what you need help with - assignments, exams, discussion posts, etc."
                        rows={4}
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="loginDetails">Course Login Details (if applicable)</Label>
                      <Textarea
                        placeholder="Provide login credentials for your course platform (we ensure complete security)"
                        rows={3}
                      />
                      <p className="text-xs text-muted-foreground mt-1">
                        Your login details are encrypted and secure. We never share or misuse your information.
                      </p>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <Label htmlFor="email">Your Email *</Label>
                        <Input type="email" placeholder="Enter your email address" required />
                      </div>

                      <div>
                        <Label htmlFor="phone">Phone Number *</Label>
                        <Input type="tel" placeholder="+254 XXX XXX XXX" required />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="communication">Preferred Communication Method *</Label>
                      <Select required>
                        <SelectTrigger>
                          <SelectValue placeholder="How would you like us to contact you?" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="whatsapp">WhatsApp (+254 748 881893)</SelectItem>
                          <SelectItem value="email">Email (writehunters@gmail.com)</SelectItem>
                          <SelectItem value="phone">Phone Call</SelectItem>
                          <SelectItem value="all">All Methods</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="flex items-center justify-between p-6 bg-warning/5 rounded-lg">
                      <div>
                        <div className="font-semibold text-lg">Service: {selectedPackage}</div>
                        <div className="text-sm text-muted-foreground">
                          {serviceType === "cat" && "Per CAT assistance"}
                          {serviceType === "exam" && "Per exam support"}
                          {serviceType === "full-weekly" && "Weekly class management"}
                          {serviceType === "full-monthly" && "Monthly class management"}
                        </div>
                      </div>
                      <div className="text-4xl font-bold text-warning">${getServicePrice()}</div>
                    </div>

                    <Button type="submit" className="w-full bg-warning hover:bg-warning/90 text-lg py-4">
                      <ArrowRight className="h-5 w-5 mr-2" />
                      Proceed to Payment - ${getServicePrice()}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      )}

      {/* How It Works */}
      <section className="py-20 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl font-bold text-foreground mb-4">How Class Management Works</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Our proven process ensures your academic success while you focus on other priorities
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-warning/10 rounded-full flex items-center justify-center mx-auto mb-6 relative">
                <FileText className="h-8 w-8 text-warning" />
                <div className="absolute -top-2 -right-2 w-8 h-8 bg-warning text-white rounded-full flex items-center justify-center text-sm font-bold">
                  1
                </div>
              </div>
              <h3 className="font-serif text-xl font-bold mb-4">Choose Your Package</h3>
              <p className="text-muted-foreground">
                Select the service that fits your needs - CATs, exams, or full class management.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-6 relative">
                <Users className="h-8 w-8 text-success" />
                <div className="absolute -top-2 -right-2 w-8 h-8 bg-success text-white rounded-full flex items-center justify-center text-sm font-bold">
                  2
                </div>
              </div>
              <h3 className="font-serif text-xl font-bold mb-4">Expert Assignment</h3>
              <p className="text-muted-foreground">We assign a qualified tutor with expertise in your subject area.</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-purple/10 rounded-full flex items-center justify-center mx-auto mb-6 relative">
                <Target className="h-8 w-8 text-purple" />
                <div className="absolute -top-2 -right-2 w-8 h-8 bg-purple text-white rounded-full flex items-center justify-center text-sm font-bold">
                  3
                </div>
              </div>
              <h3 className="font-serif text-xl font-bold mb-4">Active Management</h3>
              <p className="text-muted-foreground">
                Your tutor handles assignments, discussions, and exam preparation.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-coral/10 rounded-full flex items-center justify-center mx-auto mb-6 relative">
                <CheckCircle className="h-8 w-8 text-coral" />
                <div className="absolute -top-2 -right-2 w-8 h-8 bg-coral text-white rounded-full flex items-center justify-center text-sm font-bold">
                  4
                </div>
              </div>
              <h3 className="font-serif text-xl font-bold mb-4">Success & Updates</h3>
              <p className="text-muted-foreground">Regular progress updates and guaranteed academic success.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Communication Options */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl font-bold text-foreground mb-4">Stay Connected Throughout</h2>
            <p className="text-xl text-muted-foreground">
              Multiple ways to communicate and track your academic progress
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <MessageCircle className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="font-serif text-xl font-bold mb-4">WhatsApp Support</h3>
                <p className="text-muted-foreground mb-4">
                  Instant communication with your dedicated tutor via WhatsApp.
                </p>
                <div className="text-lg font-semibold text-green-600 mb-4">+254 748 881893</div>
                <Button className="w-full bg-green-600 hover:bg-green-700 text-white">
                  <MessageCircle className="h-4 w-4 mr-2" />
                  Chat on WhatsApp
                </Button>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Mail className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="font-serif text-xl font-bold mb-4">Email Updates</h3>
                <p className="text-muted-foreground mb-4">
                  Detailed progress reports and assignment updates via email.
                </p>
                <div className="text-lg font-semibold text-blue-600 mb-4">writehunters@gmail.com</div>
                <Button
                  variant="outline"
                  className="w-full bg-transparent border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white"
                >
                  <Mail className="h-4 w-4 mr-2" />
                  Send Email
                </Button>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Phone className="h-8 w-8 text-purple-600" />
                </div>
                <h3 className="font-serif text-xl font-bold mb-4">Phone Consultations</h3>
                <p className="text-muted-foreground mb-4">
                  Schedule phone calls for detailed discussions about your courses.
                </p>
                <div className="text-lg font-semibold text-purple-600 mb-4">Available 24/7</div>
                <Button
                  variant="outline"
                  className="w-full bg-transparent border-purple-600 text-purple-600 hover:bg-purple-600 hover:text-white"
                >
                  <Phone className="h-4 w-4 mr-2" />
                  Schedule Call
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Guarantees */}
      <section className="py-20 bg-gradient-to-r from-warning/5 to-success/5">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl font-bold text-foreground mb-4">Our Class Management Guarantees</h2>
            <p className="text-xl text-muted-foreground">
              We're committed to your academic success with these guarantees
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="h-8 w-8 text-success" />
              </div>
              <h3 className="font-serif text-xl font-bold mb-4">Grade Guarantee</h3>
              <p className="text-muted-foreground">We guarantee improved grades or your money back.</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-warning/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Clock className="h-8 w-8 text-warning" />
              </div>
              <h3 className="font-serif text-xl font-bold mb-4">Timely Submissions</h3>
              <p className="text-muted-foreground">All assignments and exams completed before deadlines.</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-purple/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Shield className="h-8 w-8 text-purple" />
              </div>
              <h3 className="font-serif text-xl font-bold mb-4">Complete Confidentiality</h3>
              <p className="text-muted-foreground">Your information and academic work remain completely private.</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-coral/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Users className="h-8 w-8 text-coral" />
              </div>
              <h3 className="font-serif text-xl font-bold mb-4">Expert Tutors</h3>
              <p className="text-muted-foreground">Qualified professionals with advanced degrees in your field.</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <MessageCircle className="h-8 w-8 text-success" />
              </div>
              <h3 className="font-serif text-xl font-bold mb-4">24/7 Communication</h3>
              <p className="text-muted-foreground">Always available via WhatsApp, email, or phone.</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-warning/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Star className="h-8 w-8 text-warning" />
              </div>
              <h3 className="font-serif text-xl font-bold mb-4">Quality Assurance</h3>
              <p className="text-muted-foreground">All work reviewed by senior tutors before submission.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-warning to-success">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center text-white">
            <h2 className="font-serif text-4xl font-bold mb-6">Ready to Manage Your Classes?</h2>
            <p className="text-xl mb-8 opacity-90">
              Let our experts handle your coursework while you focus on what matters most to you.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                onClick={() => setShowOrderForm(true)}
                className="bg-white text-warning hover:bg-gray-100 text-lg px-8 py-4"
              >
                <Zap className="h-5 w-5 mr-2" />
                Start Class Management
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="text-lg px-8 py-4 border-white text-white hover:bg-white hover:text-warning bg-transparent"
                asChild
              >
                <Link href="/contact">
                  <MessageCircle className="h-5 w-5 mr-2" />
                  Contact Us First
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
