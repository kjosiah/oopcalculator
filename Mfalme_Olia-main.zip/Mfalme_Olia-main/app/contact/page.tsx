import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Mail, MessageCircle, Clock, Send, HelpCircle, Facebook, Instagram } from "lucide-react"
import Link from "next/link"

export const metadata = {
  title: "Contact WriteHunters - Get Free Quote for Academic Writing Services",
  description:
    "Contact WriteHunters for professional academic writing help. WhatsApp: +254 748 881893, Email: writehunters@gmail.com. Get instant quotes and 24/7 support.",
  keywords: "contact WriteHunters, academic writing help, get quote, WhatsApp academic writing, WriteHunters contact",
  openGraph: {
    title: "Contact WriteHunters - Academic Writing Services",
    description: "Get in touch with WriteHunters for professional academic writing help. 24/7 support available.",
    type: "website",
    url: "https://writehunters.com/contact",
  },
}

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <BookOpen className="h-8 w-8 text-primary" />
              <span className="font-serif text-2xl font-bold text-primary">WriteHunters</span>
            </Link>
            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-foreground hover:text-primary transition-colors">
                Home
              </Link>
              <Link href="/services" className="text-foreground hover:text-primary transition-colors">
                Services
              </Link>
              <Link href="/about" className="text-foreground hover:text-primary transition-colors">
                About
              </Link>
              <Link href="/contact" className="text-primary font-semibold">
                Contact
              </Link>
            </nav>
            <Button className="bg-primary hover:bg-primary/90">Get Started</Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <Badge className="mb-6 bg-accent/10 text-accent border-accent/20">Get In Touch</Badge>
            <h1 className="font-serif text-4xl md:text-5xl font-bold text-foreground mb-6">Contact WriteHunters</h1>
            <p className="text-xl text-muted-foreground">
              Ready to get started? We're here to help with all your academic writing needs. Contact us today for a free
              consultation and quote.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Methods */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                  <MessageCircle className="h-8 w-8 text-primary" />
                </div>
                <h3 className="font-serif text-xl font-bold mb-4">WhatsApp</h3>
                <p className="text-muted-foreground mb-4">
                  Get instant responses to your questions and quick quotes for your projects.
                </p>
                <div className="text-lg font-semibold text-primary mb-4">+254 748 881893</div>
                <Button className="w-full bg-accent hover:bg-accent/90">
                  <MessageCircle className="h-4 w-4 mr-2" />
                  Chat on WhatsApp
                </Button>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Mail className="h-8 w-8 text-primary" />
                </div>
                <h3 className="font-serif text-xl font-bold mb-4">Email</h3>
                <p className="text-muted-foreground mb-4">
                  Send us detailed requirements and receive comprehensive proposals.
                </p>
                <div className="text-lg font-semibold text-primary mb-4">writehunters@gmail.com</div>
                <Button variant="outline" className="w-full bg-transparent">
                  <Mail className="h-4 w-4 mr-2" />
                  Send Email
                </Button>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Facebook className="h-8 w-8 text-primary" />
                </div>
                <h3 className="font-serif text-xl font-bold mb-4">Social Media</h3>
                <p className="text-muted-foreground mb-4">
                  Follow us for updates, tips, and academic writing resources.
                </p>
                <div className="space-y-3">
                  <Button variant="outline" className="w-full bg-blue-50 border-blue-200 hover:bg-blue-100" asChild>
                    <a
                      href="https://www.facebook.com/profile.php?id=61577361405554"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Facebook className="h-4 w-4 mr-2" />
                      Facebook
                    </a>
                  </Button>
                  <Button variant="outline" className="w-full bg-pink-50 border-pink-200 hover:bg-pink-100" asChild>
                    <a href="https://www.instagram.com/writehunters/" target="_blank" rel="noopener noreferrer">
                      <Instagram className="h-4 w-4 mr-2" />
                      Instagram
                    </a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Contact Form */}
          <div className="max-w-4xl mx-auto">
            <div className="grid lg:grid-cols-2 gap-12">
              <div>
                <h2 className="font-serif text-3xl font-bold text-foreground mb-6">Send Us a Message</h2>
                <p className="text-muted-foreground mb-8">
                  Fill out the form below with your project details, and we'll get back to you with a personalized quote
                  and timeline.
                </p>

                <Card>
                  <CardContent className="p-8">
                    <form className="space-y-6">
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-semibold text-foreground mb-2">First Name *</label>
                          <input
                            type="text"
                            required
                            className="w-full p-3 border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                            placeholder="John"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-semibold text-foreground mb-2">Last Name *</label>
                          <input
                            type="text"
                            required
                            className="w-full p-3 border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                            placeholder="Doe"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-foreground mb-2">Email Address *</label>
                        <input
                          type="email"
                          required
                          className="w-full p-3 border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                          placeholder="john.doe@email.com"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-foreground mb-2">Phone Number</label>
                        <input
                          type="tel"
                          className="w-full p-3 border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                          placeholder="+1 (555) 123-4567"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-foreground mb-2">Service Needed *</label>
                        <select
                          required
                          className="w-full p-3 border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                        >
                          <option value="">Select a service</option>
                          <option value="essay-writing">Essay Writing</option>
                          <option value="research-papers">Research Papers</option>
                          <option value="editing-proofreading">Editing & Proofreading</option>
                          <option value="dissertation">Dissertation Help</option>
                          <option value="other">Other</option>
                        </select>
                      </div>

                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-semibold text-foreground mb-2">Academic Level</label>
                          <select className="w-full p-3 border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary">
                            <option value="">Select level</option>
                            <option value="high-school">High School</option>
                            <option value="undergraduate">Undergraduate</option>
                            <option value="masters">Master's</option>
                            <option value="phd">PhD</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-sm font-semibold text-foreground mb-2">Deadline</label>
                          <input
                            type="date"
                            className="w-full p-3 border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-foreground mb-2">Project Details *</label>
                        <textarea
                          required
                          rows={5}
                          className="w-full p-3 border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                          placeholder="Please provide details about your project including topic, length, specific requirements, citation style, etc."
                        ></textarea>
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-foreground mb-2">Additional Files</label>
                        <input
                          type="file"
                          multiple
                          className="w-full p-3 border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                        />
                        <p className="text-sm text-muted-foreground mt-2">
                          Upload any relevant files, instructions, or materials (optional)
                        </p>
                      </div>

                      <Button className="w-full bg-primary hover:bg-primary/90 text-lg py-3">
                        <Send className="h-5 w-5 mr-2" />
                        Send Message & Get Quote
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-8">
                <div>
                  <h3 className="font-serif text-2xl font-bold text-foreground mb-6">Why Choose WriteHunters?</h3>
                  <div className="space-y-4">
                    <div className="flex items-start space-x-4">
                      <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center mt-1">
                        <Clock className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-semibold mb-2">Fast Turnaround</h4>
                        <p className="text-muted-foreground text-sm">
                          We can handle urgent deadlines as short as 3 hours while maintaining quality.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-4">
                      <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center mt-1">
                        <BookOpen className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-semibold mb-2">Expert Writers</h4>
                        <p className="text-muted-foreground text-sm">
                          Our team includes PhD holders and subject matter experts across all disciplines.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-4">
                      <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center mt-1">
                        <Mail className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-semibold mb-2">24/7 Support</h4>
                        <p className="text-muted-foreground text-sm">
                          Get help anytime through WhatsApp, email, or our contact form.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* FAQ Section */}
                <Card>
                  <CardHeader>
                    <CardTitle className="font-serif text-xl flex items-center">
                      <HelpCircle className="h-5 w-5 mr-2" />
                      Frequently Asked Questions
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="font-semibold mb-2">How quickly can you complete my order?</h4>
                      <p className="text-muted-foreground text-sm">
                        We can handle deadlines as short as 3 hours, though we recommend at least 24 hours for best
                        quality.
                      </p>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">Do you provide plagiarism reports?</h4>
                      <p className="text-muted-foreground text-sm">
                        Yes, every order comes with a free plagiarism report to ensure 100% originality.
                      </p>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">What if I need revisions?</h4>
                      <p className="text-muted-foreground text-sm">
                        We offer unlimited free revisions within 14 days to ensure your complete satisfaction.
                      </p>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">How do I make payment?</h4>
                      <p className="text-muted-foreground text-sm">
                        We accept various payment methods including mobile money, bank transfers, and online payments.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="font-serif text-4xl font-bold text-foreground mb-6">Ready to Get Started?</h2>
            <p className="text-xl text-muted-foreground mb-8">
              Don't wait - contact us now and get your academic writing project started today!
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-accent hover:bg-accent/90 text-lg px-8">
                <MessageCircle className="h-5 w-5 mr-2" />
                WhatsApp: +254 748 881893
              </Button>
              <Button size="lg" variant="outline" className="text-lg px-8 bg-transparent">
                <Mail className="h-5 w-5 mr-2" />
                Email Us Now
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <BookOpen className="h-6 w-6" />
                <span className="font-serif text-xl font-bold">WriteHunters</span>
              </div>
              <p className="text-slate-300 mb-4">
                Professional academic writing services for students and academics worldwide.
              </p>
              <div className="flex space-x-4">
                <a
                  href="https://www.facebook.com/profile.php?id=61577361405554"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center hover:bg-blue-700 transition-colors"
                >
                  <Facebook className="h-5 w-5 text-white" />
                </a>
                <a
                  href="https://www.instagram.com/writehunters/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center hover:from-purple-600 hover:to-pink-600 transition-colors"
                >
                  <Instagram className="h-5 w-5 text-white" />
                </a>
              </div>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-slate-300">
                <li>
                  <Link href="/services/essay-writing">Essay Writing</Link>
                </li>
                <li>
                  <Link href="/services/research-papers">Research Papers</Link>
                </li>
                <li>
                  <Link href="/services/editing">Editing & Proofreading</Link>
                </li>
                <li>Dissertation Help</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-slate-300">
                <li>
                  <Link href="/about">About Us</Link>
                </li>
                <li>Our Writers</li>
                <li>Quality Guarantee</li>
                <li>Privacy Policy</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <div className="space-y-2 text-slate-300">
                <div>WhatsApp: +254 748 881893</div>
                <div>Email: writehunters@gmail.com</div>
                <div className="mt-4 space-y-1">
                  <div>
                    <a
                      href="https://www.facebook.com/profile.php?id=61577361405554"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-slate-300 hover:text-white transition-colors"
                    >
                      Facebook
                    </a>
                  </div>
                  <div>
                    <a
                      href="https://www.instagram.com/writehunters/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-slate-300 hover:text-white transition-colors"
                    >
                      Instagram
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-slate-700 mt-8 pt-8 text-center text-slate-300">
            <p>&copy; 2024 WriteHunters. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
