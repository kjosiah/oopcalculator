const nodemailer = require('nodemailer');
const dotenv = require('dotenv');
dotenv.config();

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT || 587),
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS
  }
});

module.exports = async function sendMail({ to, subject, text, from }) {
  const info = await transporter.sendMail({
    from: from || process.env.SMTP_USER,
    to,
    subject,
    text
  });
  return info;
};