import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BookOpen, CheckCircle, FileText, Users } from "lucide-react"
import Link from "next/link"

export const metadata = {
  title: "Professional Essay Writing Service - Starting at $15/page | WriteHunters",
  description:
    "Expert essay writing service from WriteHunters. Argumentative, descriptive, narrative, expository essays & more. 100% original, plagiarism-free work with unlimited revisions.",
  keywords:
    "essay writing service, argumentative essays, descriptive essays, narrative essays, expository essays, compare contrast essays, academic essays, WriteHunters",
  openGraph: {
    title: "Professional Essay Writing Service - WriteHunters",
    description:
      "Expert essay writing service starting at $15/page. All types of academic essays with unlimited revisions.",
    type: "website",
    url: "https://writehunters.com/services/essay-writing",
  },
}

export default function EssayWritingPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <BookOpen className="h-8 w-8 text-primary" />
              <span className="font-serif text-2xl font-bold text-primary">WriteHunters</span>
            </Link>
            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-foreground hover:text-primary transition-colors">
                Home
              </Link>
              <Link href="/services" className="text-primary font-semibold">
                Services
              </Link>
              <Link href="/about" className="text-foreground hover:text-primary transition-colors">
                About
              </Link>
              <Link href="/contact" className="text-foreground hover:text-primary transition-colors">
                Contact
              </Link>
            </nav>
            <Button className="bg-primary hover:bg-primary/90">Get Started</Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <Badge className="mb-6 bg-accent/10 text-accent border-accent/20">Essay Writing Service</Badge>
                <h1 className="font-serif text-4xl md:text-5xl font-bold text-foreground mb-6">
                  Professional Essay Writing That Gets Results
                </h1>
                <p className="text-xl text-muted-foreground mb-8">
                  From argumentative to narrative essays, our expert writers craft compelling, well-researched papers
                  that meet your exact requirements and academic standards.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button size="lg" className="bg-primary hover:bg-primary/90">
                    Order Now
                  </Button>
                  <Button size="lg" variant="outline">
                    Get Free Quote
                  </Button>
                </div>
              </div>
              <div className="lg:text-right">
                <Card className="inline-block">
                  <CardContent className="p-8">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-primary mb-2">Starting at $15</div>
                      <div className="text-muted-foreground mb-4">per page</div>
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center">
                          <CheckCircle className="h-4 w-4 text-accent mr-2" />
                          Free revisions
                        </div>
                        <div className="flex items-center">
                          <CheckCircle className="h-4 w-4 text-accent mr-2" />
                          Plagiarism report
                        </div>
                        <div className="flex items-center">
                          <CheckCircle className="h-4 w-4 text-accent mr-2" />
                          24/7 support
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Essay Types */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl font-bold text-foreground mb-4">Types of Essays We Write</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Our expert writers specialize in all types of academic essays
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="font-serif text-xl">Argumentative Essays</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  Present compelling arguments with strong evidence and logical reasoning to persuade your audience.
                </p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-accent mr-2" />
                    Strong thesis statements
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-accent mr-2" />
                    Evidence-based arguments
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-accent mr-2" />
                    Counter-argument analysis
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="font-serif text-xl">Descriptive Essays</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  Vivid descriptions that engage the senses and create lasting impressions on readers.
                </p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-accent mr-2" />
                    Sensory details
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-accent mr-2" />
                    Figurative language
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-accent mr-2" />
                    Organized structure
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="font-serif text-xl">Narrative Essays</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  Tell compelling stories with clear plots, characters, and meaningful themes.
                </p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-accent mr-2" />
                    Engaging storytelling
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-accent mr-2" />
                    Character development
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-accent mr-2" />
                    Meaningful themes
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="font-serif text-xl">Expository Essays</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  Clear explanations and analysis of complex topics with factual information.
                </p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-accent mr-2" />
                    Clear explanations
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-accent mr-2" />
                    Factual information
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-accent mr-2" />
                    Logical organization
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="font-serif text-xl">Compare & Contrast</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  Analyze similarities and differences between subjects with balanced perspectives.
                </p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-accent mr-2" />
                    Balanced analysis
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-accent mr-2" />
                    Clear comparisons
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-accent mr-2" />
                    Structured format
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="font-serif text-xl">Persuasive Essays</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  Convince readers to adopt your viewpoint through emotional and logical appeals.
                </p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-accent mr-2" />
                    Emotional appeals
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-accent mr-2" />
                    Logical reasoning
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-accent mr-2" />
                    Call to action
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="py-20 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl font-bold text-foreground mb-4">Our Writing Process</h2>
            <p className="text-xl text-muted-foreground">Simple steps to get your perfect essay</p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <FileText className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-serif text-xl font-bold mb-4">1. Submit Requirements</h3>
              <p className="text-muted-foreground">Share your essay topic, requirements, and deadline with us.</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Users className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-serif text-xl font-bold mb-4">2. Writer Assignment</h3>
              <p className="text-muted-foreground">We match you with an expert writer in your subject area.</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <BookOpen className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-serif text-xl font-bold mb-4">3. Writing & Research</h3>
              <p className="text-muted-foreground">Your writer conducts research and crafts your essay from scratch.</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-serif text-xl font-bold mb-4">4. Quality Check</h3>
              <p className="text-muted-foreground">We review, edit, and deliver your polished essay on time.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="font-serif text-4xl font-bold text-foreground mb-6">Ready to Order Your Essay?</h2>
            <p className="text-xl text-muted-foreground mb-8">
              Get started today and receive a high-quality, original essay written just for you.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-lg px-8">
                Order Now - From $15
              </Button>
              <Button size="lg" variant="outline" className="text-lg px-8 bg-transparent">
                Get Free Quote
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <BookOpen className="h-6 w-6" />
                <span className="font-serif text-xl font-bold">WriteHunters</span>
              </div>
              <p className="text-slate-300">
                Professional academic writing services for students and academics worldwide.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-slate-300">
                <li>
                  <Link href="/services/essay-writing">Essay Writing</Link>
                </li>
                <li>
                  <Link href="/services/research-papers">Research Papers</Link>
                </li>
                <li>
                  <Link href="/services/editing">Editing & Proofreading</Link>
                </li>
                <li>Dissertation Help</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-slate-300">
                <li>
                  <Link href="/about">About Us</Link>
                </li>
                <li>Our Writers</li>
                <li>Quality Guarantee</li>
                <li>Privacy Policy</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <div className="space-y-2 text-slate-300">
                <div>WhatsApp: +254 748 881893</div>
                <div>Email: writehunters@gmail.com</div>
              </div>
            </div>
          </div>

          <div className="border-t border-slate-700 mt-8 pt-8 text-center text-slate-300">
            <p>&copy; 2024 WriteHunters. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
