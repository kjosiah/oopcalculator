import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Award, Users, CheckCircle, Clock, Shield, Star, GraduationCap } from "lucide-react"
import Link from "next/link"

export const metadata = {
  title: "Academic Writing Services - Essays, Research Papers & Editing | WriteHunters",
  description:
    "Comprehensive academic writing services from WriteHunters. Professional essay writing, research papers, editing & proofreading. Starting from $15/page with 24/7 support.",
  keywords:
    "academic writing services, essay writing, research papers, editing services, proofreading, academic help, WriteHunters services",
  openGraph: {
    title: "Academic Writing Services - WriteHunters",
    description:
      "Professional academic writing services including essays, research papers, and editing. Starting from $15/page.",
    type: "website",
    url: "https://writehunters.com/services",
  },
}

export default function ServicesPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <BookOpen className="h-8 w-8 text-primary" />
              <span className="font-serif text-2xl font-bold text-primary">WriteHunters</span>
            </Link>
            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-foreground hover:text-primary transition-colors">
                Home
              </Link>
              <Link href="/services" className="text-primary font-semibold">
                Services
              </Link>
              <Link href="/about" className="text-foreground hover:text-primary transition-colors">
                About
              </Link>
              <Link href="/blog" className="text-foreground hover:text-primary transition-colors">
                Blog
              </Link>
              <Link href="/contact" className="text-foreground hover:text-primary transition-colors">
                Contact
              </Link>
            </nav>
            <Button asChild className="bg-coral hover:bg-coral/90 text-coral-foreground">
              <Link href="/order">Place Your Order</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <Badge className="mb-6 bg-accent/10 text-accent border-accent/20">Our Services</Badge>
            <h1 className="font-serif text-4xl md:text-5xl font-bold text-foreground mb-6">
              Comprehensive Academic Writing Solutions
            </h1>
            <p className="text-xl text-muted-foreground">
              From essays to dissertations, we provide expert writing services tailored to your academic needs
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 xl:grid-cols-4 gap-8">
            {/* Essay Writing */}
            <Card className="border-2 hover:border-coral/30 transition-all hover:shadow-lg group">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-coral/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-coral/20 transition-colors">
                  <BookOpen className="h-8 w-8 text-coral" />
                </div>
                <CardTitle className="font-serif text-2xl">Essay Writing</CardTitle>
                <p className="text-muted-foreground">Custom essays crafted to perfection</p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Argumentative Essays
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Descriptive Essays
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Narrative Essays
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Expository Essays
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Compare & Contrast
                  </div>
                </div>

                <div className="border-t pt-4">
                  <div className="text-center mb-4">
                    <div className="text-2xl font-bold text-coral">From $4</div>
                    <div className="text-sm text-muted-foreground">per page</div>
                  </div>
                </div>

                <Link href="/services/essay-writing">
                  <Button className="w-full bg-coral hover:bg-coral/90 text-coral-foreground">Learn More</Button>
                </Link>
              </CardContent>
            </Card>

            {/* Research Papers */}
            <Card className="border-2 hover:border-purple/30 transition-all hover:shadow-lg border-purple/30 group">
              <CardHeader className="text-center pb-4">
                <Badge className="mb-2 bg-purple text-purple-foreground">Most Popular</Badge>
                <div className="w-16 h-16 bg-purple/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-purple/20 transition-colors">
                  <Award className="h-8 w-8 text-purple" />
                </div>
                <CardTitle className="font-serif text-2xl">Research Papers</CardTitle>
                <p className="text-muted-foreground">In-depth research and analysis</p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Literature Reviews
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Case Studies
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Term Papers
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Thesis Papers
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Dissertations
                  </div>
                </div>

                <div className="border-t pt-4">
                  <div className="text-center mb-4">
                    <div className="text-2xl font-bold text-purple">From $6</div>
                    <div className="text-sm text-muted-foreground">per page</div>
                  </div>
                </div>

                <Link href="/services/research-papers">
                  <Button className="w-full bg-purple hover:bg-purple/90 text-purple-foreground">Learn More</Button>
                </Link>
              </CardContent>
            </Card>

            {/* Editing & Proofreading */}
            <Card className="border-2 hover:border-accent/30 transition-all hover:shadow-lg group">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-accent/20 transition-colors">
                  <Users className="h-8 w-8 text-accent" />
                </div>
                <CardTitle className="font-serif text-2xl">Editing & Proofreading</CardTitle>
                <p className="text-muted-foreground">Polish your work to perfection</p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Grammar & Spelling
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Style & Tone
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Structure & Flow
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Citation Formatting
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Plagiarism Check
                  </div>
                </div>

                <div className="border-t pt-4">
                  <div className="text-center mb-4">
                    <div className="text-2xl font-bold text-accent">From $3</div>
                    <div className="text-sm text-muted-foreground">per page</div>
                  </div>
                </div>

                <Link href="/services/editing">
                  <Button className="w-full bg-accent hover:bg-accent/90 text-accent-foreground">Learn More</Button>
                </Link>
              </CardContent>
            </Card>

            {/* Class Management Services */}
            <Card className="border-2 hover:border-warning/30 transition-all hover:shadow-lg group">
              <CardHeader className="text-center pb-4">
                <Badge className="mb-2 bg-warning/10 text-warning border-warning/20">New Service</Badge>
                <div className="w-16 h-16 bg-warning/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-warning/20 transition-colors">
                  <GraduationCap className="h-8 w-8 text-warning" />
                </div>
                <CardTitle className="font-serif text-2xl">Class Management</CardTitle>
                <p className="text-muted-foreground">Complete academic support</p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Assignment Tracking
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Discussion Posts
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Quiz Assistance
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Course Projects
                  </div>
                  <div className="flex items-center text-sm">
                    <CheckCircle className="h-4 w-4 text-success mr-3" />
                    Weekly Support
                  </div>
                </div>

                <div className="border-t pt-4">
                  <div className="text-center mb-4">
                    <div className="text-2xl font-bold text-warning">From $50</div>
                    <div className="text-sm text-muted-foreground">per week</div>
                  </div>
                </div>

                <Link href="/contact">
                  <Button className="w-full bg-warning hover:bg-warning/90 text-warning-foreground">Contact Us</Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Client Reviews */}
      <section className="py-20 bg-gradient-to-r from-slate-50 to-blue-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl font-bold text-foreground mb-4">What Our Clients Say</h2>
            <p className="text-xl text-muted-foreground">Trusted by students and academics worldwide</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="border-l-4 border-l-coral hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <div className="flex text-warning">{"★".repeat(5)}</div>
                </div>
                <p className="text-muted-foreground mb-4 text-sm">
                  "WriteHunters delivered an exceptional research paper that exceeded my expectations. The quality and
                  attention to detail were outstanding."
                </p>
                <div className="font-semibold text-coral">Sarah M.</div>
                <div className="text-xs text-muted-foreground">Graduate Student</div>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-purple hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <div className="flex text-warning">{"★".repeat(5)}</div>
                </div>
                <p className="text-muted-foreground mb-4 text-sm">
                  "Professional, reliable, and always on time. Their editing service helped me improve my thesis
                  significantly."
                </p>
                <div className="font-semibold text-purple">James K.</div>
                <div className="text-xs text-muted-foreground">PhD Candidate</div>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-success hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <div className="flex text-warning">{"★".repeat(5)}</div>
                </div>
                <p className="text-muted-foreground mb-4 text-sm">
                  "The team at WriteHunters understands academic requirements perfectly. Highly recommend their
                  services!"
                </p>
                <div className="font-semibold text-success">Maria L.</div>
                <div className="text-xs text-muted-foreground">Undergraduate</div>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-warning hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <div className="flex text-warning">{"★".repeat(5)}</div>
                </div>
                <p className="text-muted-foreground mb-4 text-sm">
                  "Their class management service saved my semester! They handled all my assignments professionally and
                  on time."
                </p>
                <div className="font-semibold text-warning">David R.</div>
                <div className="text-xs text-muted-foreground">Business Student</div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl font-bold text-foreground mb-4">Why Choose WriteHunters?</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              We deliver excellence through expertise, reliability, and commitment to your success
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-coral/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Clock className="h-8 w-8 text-coral" />
              </div>
              <h3 className="font-serif text-xl font-bold mb-4">Timely Delivery</h3>
              <p className="text-muted-foreground">
                We understand deadlines matter. Every project is delivered on time, guaranteed.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-purple/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Shield className="h-8 w-8 text-purple" />
              </div>
              <h3 className="font-serif text-xl font-bold mb-4">100% Original</h3>
              <p className="text-muted-foreground">
                All work is written from scratch with thorough plagiarism checks and reports.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Star className="h-8 w-8 text-success" />
              </div>
              <h3 className="font-serif text-xl font-bold mb-4">Expert Writers</h3>
              <p className="text-muted-foreground">
                Our team consists of qualified writers with advanced degrees in various fields.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-coral/5 to-purple/5">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="font-serif text-4xl font-bold text-foreground mb-6">Ready to Get Started?</h2>
            <p className="text-xl text-muted-foreground mb-8">
              Contact us today for a free consultation and quote for your academic writing needs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" asChild className="bg-coral hover:bg-coral/90 text-coral-foreground text-lg px-8">
                <Link href="/order">Place Your Order</Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                asChild
                className="text-lg px-8 bg-transparent border-purple text-purple hover:bg-purple hover:text-purple-foreground"
              >
                <Link href="/contact">Contact Us</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-slate-900 to-slate-800 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <BookOpen className="h-6 w-6 text-accent" />
                <span className="font-serif text-xl font-bold">WriteHunters</span>
              </div>
              <p className="text-slate-300">
                Professional academic writing services for students and academics worldwide.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4 text-coral">Services</h4>
              <ul className="space-y-2 text-slate-300">
                <li>
                  <Link href="/services/essay-writing">Essay Writing</Link>
                </li>
                <li>
                  <Link href="/services/research-papers">Research Papers</Link>
                </li>
                <li>
                  <Link href="/services/editing">Editing & Proofreading</Link>
                </li>
                <li>Class Management</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4 text-purple">Company</h4>
              <ul className="space-y-2 text-slate-300">
                <li>
                  <Link href="/about">About Us</Link>
                </li>
                <li>
                  <Link href="/blog">Blog</Link>
                </li>
                <li>Quality Guarantee</li>
                <li>Privacy Policy</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4 text-success">Contact</h4>
              <div className="space-y-2 text-slate-300">
                <div>WhatsApp: +254 748 881893</div>
                <div>Email: writehunters@gmail.com</div>
              </div>
            </div>
          </div>

          <div className="border-t border-slate-700 mt-8 pt-8 text-center text-slate-300">
            <p>&copy; 2024 WriteHunters. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
