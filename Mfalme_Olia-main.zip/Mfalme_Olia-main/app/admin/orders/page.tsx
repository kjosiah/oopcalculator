"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import AdminLayout from "@/components/admin-layout"
import { FileText, Edit, Mail, Phone, Download, Search } from "lucide-react"

export default function AdminOrdersPage() {
  const [selectedOrder, setSelectedOrder] = useState<string | null>(null)
  const [filter, setFilter] = useState("all")

  // Mock orders data with order numbers
  const orders = [
    {
      id: "WH240115001",
      orderNumber: "WH240115001",
      client: "Sarah Johnson",
      email: "sarah.j@email.com",
      phone: "+254 712 345 678",
      service: "Essay Writing",
      pages: 5,
      academicLevel: "Undergraduate",
      deadline: "2024-01-16 14:00",
      totalPrice: 30,
      status: "in-progress",
      paymentStatus: "paid",
      createdAt: "2024-01-15 10:30",
      subject: "Environmental Science Essay",
      instructions: "5-page essay on climate change impacts...",
      files: 2,
      writer: "Dr. Smith",
    },
    {
      id: "WH240115002",
      orderNumber: "WH240115002",
      client: "Michael Chen",
      email: "m.chen@university.edu",
      phone: "+254 723 456 789",
      service: "Research Paper",
      pages: 12,
      academicLevel: "Masters",
      deadline: "2024-01-20 12:00",
      totalPrice: 48,
      status: "pending",
      paymentStatus: "pending",
      createdAt: "2024-01-15 09:15",
      subject: "Marketing Research Analysis",
      instructions: "12-page research paper on digital marketing trends...",
      files: 1,
      writer: null,
    },
    {
      id: "WH240114003",
      orderNumber: "WH240114003",
      client: "Emma Davis",
      email: "emma.davis@student.ac.ke",
      phone: "+254 734 567 890",
      service: "Class Management",
      pages: 1,
      academicLevel: "Undergraduate",
      deadline: "2024-01-21 23:59",
      totalPrice: 50,
      status: "completed",
      paymentStatus: "paid",
      createdAt: "2024-01-14 16:45",
      subject: "Weekly Class Management",
      instructions: "Manage all assignments for Business Studies course...",
      files: 0,
      writer: "Prof. Johnson",
    },
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800"
      case "in-progress":
        return "bg-blue-100 text-blue-800"
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case "paid":
        return "bg-green-100 text-green-800"
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "failed":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const filteredOrders = orders.filter((order) => {
    if (filter === "all") return true
    if (filter === "pending") return order.status === "pending"
    if (filter === "in-progress") return order.status === "in-progress"
    if (filter === "completed") return order.status === "completed"
    if (filter === "payment-pending") return order.paymentStatus === "pending"
    return true
  })

  const selectedOrderData = orders.find((order) => order.id === selectedOrder)

  return (
    <AdminLayout title="Order Management">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">Order Management</h1>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Search className="h-4 w-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search by order number..."
                className="px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-coral"
              />
            </div>
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-coral"
            >
              <option value="all">All Orders</option>
              <option value="pending">Pending</option>
              <option value="in-progress">In Progress</option>
              <option value="completed">Completed</option>
              <option value="payment-pending">Payment Pending</option>
            </select>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Orders</p>
                  <p className="text-2xl font-bold text-coral">{orders.length}</p>
                </div>
                <FileText className="h-8 w-8 text-coral" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">In Progress</p>
                  <p className="text-2xl font-bold text-blue-600">
                    {orders.filter((o) => o.status === "in-progress").length}
                  </p>
                </div>
                <Edit className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Completed</p>
                  <p className="text-2xl font-bold text-green-600">
                    {orders.filter((o) => o.status === "completed").length}
                  </p>
                </div>
                <Download className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Revenue</p>
                  <p className="text-2xl font-bold text-success">
                    ${orders.reduce((sum, order) => sum + order.totalPrice, 0)}
                  </p>
                </div>
                <FileText className="h-8 w-8 text-success" />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Orders List */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Orders ({filteredOrders.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {filteredOrders.map((order) => (
                  <div
                    key={order.id}
                    onClick={() => setSelectedOrder(order.id)}
                    className={`p-4 border rounded-lg cursor-pointer hover:bg-slate-50 transition-colors ${
                      selectedOrder === order.id ? "bg-coral/10 border-coral" : ""
                    }`}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <span className="font-bold text-coral">{order.orderNumber}</span>
                          <Badge className={getStatusColor(order.status)}>{order.status}</Badge>
                          <Badge className={getPaymentStatusColor(order.paymentStatus)}>{order.paymentStatus}</Badge>
                        </div>
                        <h4 className="font-semibold">{order.client}</h4>
                        <p className="text-sm text-muted-foreground">{order.email}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-success">${order.totalPrice}</p>
                        <p className="text-sm text-muted-foreground">{order.pages} pages</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Service: </span>
                        <span>{order.service}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Deadline: </span>
                        <span>{new Date(order.deadline).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Order Details */}
          <Card>
            <CardHeader>
              <CardTitle>{selectedOrderData ? "Order Details" : "Select an order"}</CardTitle>
            </CardHeader>
            <CardContent>
              {selectedOrderData ? (
                <div className="space-y-4">
                  <div className="p-4 bg-slate-50 rounded-lg">
                    <h3 className="font-bold text-lg text-coral mb-2">{selectedOrderData.orderNumber}</h3>
                    <div className="space-y-2 text-sm">
                      <div>
                        <strong>Client:</strong> {selectedOrderData.client}
                      </div>
                      <div>
                        <strong>Email:</strong> {selectedOrderData.email}
                      </div>
                      <div>
                        <strong>Phone:</strong> {selectedOrderData.phone}
                      </div>
                      <div>
                        <strong>Created:</strong> {selectedOrderData.createdAt}
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-2">Order Information</h4>
                    <div className="space-y-2 text-sm">
                      <div>
                        <strong>Service:</strong> {selectedOrderData.service}
                      </div>
                      <div>
                        <strong>Subject:</strong> {selectedOrderData.subject}
                      </div>
                      <div>
                        <strong>Pages:</strong> {selectedOrderData.pages}
                      </div>
                      <div>
                        <strong>Academic Level:</strong> {selectedOrderData.academicLevel}
                      </div>
                      <div>
                        <strong>Deadline:</strong> {selectedOrderData.deadline}
                      </div>
                      <div>
                        <strong>Total Price:</strong> ${selectedOrderData.totalPrice}
                      </div>
                      <div>
                        <strong>Files Attached:</strong> {selectedOrderData.files}
                      </div>
                      {selectedOrderData.writer && (
                        <div>
                          <strong>Assigned Writer:</strong> {selectedOrderData.writer}
                        </div>
                      )}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-2">Instructions</h4>
                    <p className="text-sm text-muted-foreground bg-white p-3 rounded border">
                      {selectedOrderData.instructions}
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Button className="w-full bg-coral hover:bg-coral/90">
                      <Mail className="h-4 w-4 mr-2" />
                      Send Update Email
                    </Button>
                    <Button variant="outline" className="w-full bg-transparent">
                      <Phone className="h-4 w-4 mr-2" />
                      Contact Client
                    </Button>
                    <Button variant="outline" className="w-full bg-transparent">
                      <Edit className="h-4 w-4 mr-2" />
                      Update Status
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="text-center py-12">
                  <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">Select an order to view details</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </AdminLayout>
  )
}
