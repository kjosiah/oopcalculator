"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, X, User, MapPin } from "lucide-react"

interface Notification {
  id: string
  customer: string
  action: string
  service: string
  location: string
  timeAgo: string
}

export default function SocialProofNotification() {
  const [notification, setNotification] = useState<Notification | null>(null)
  const [isVisible, setIsVisible] = useState(false)

  const notifications: Notification[] = [
    {
      id: "1",
      customer: "Sarah M.",
      action: "just completed",
      service: "Research Paper",
      location: "Nairobi",
      timeAgo: "2 minutes ago",
    },
    {
      id: "2",
      customer: "James K.",
      action: "just ordered",
      service: "Essay Writing",
      location: "Mombasa",
      timeAgo: "5 minutes ago",
    },
    {
      id: "3",
      customer: "Maria L.",
      action: "just signed up for",
      service: "Class Management",
      location: "Kisumu",
      timeAgo: "8 minutes ago",
    },
  ]

  useEffect(() => {
    const showNotification = () => {
      const randomNotification = notifications[Math.floor(Math.random() * notifications.length)]
      setNotification(randomNotification)
      setIsVisible(true)

      // Hide after 5 seconds
      setTimeout(() => {
        setIsVisible(false)
      }, 5000)
    }

    // Show first notification after 3 seconds
    const initialTimer = setTimeout(showNotification, 3000)

    // Then show notifications every 20 seconds
    const interval = setInterval(showNotification, 20000)

    return () => {
      clearTimeout(initialTimer)
      clearInterval(interval)
    }
  }, [])

  if (!isVisible || !notification) return null

  return (
    <div className="fixed bottom-6 left-6 z-50 max-w-sm animate-slide-up">
      <Card className="card-elevated shadow-2xl border-l-4 border-l-success">
        <CardContent className="p-4">
          <div className="flex items-start space-x-3">
            <div className="w-10 h-10 bg-gradient-success rounded-full flex items-center justify-center flex-shrink-0">
              <User className="h-5 w-5 text-white" />
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <Badge className="bg-success/10 text-success border-success/20 text-xs">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Recent Activity
                </Badge>
                <button onClick={() => setIsVisible(false)} className="text-muted-foreground hover:text-foreground">
                  <X className="h-4 w-4" />
                </button>
              </div>

              <p className="text-sm font-medium text-foreground mb-1">
                <span className="font-semibold">{notification.customer}</span> {notification.action}{" "}
                <span className="text-coral">{notification.service}</span>
              </p>

              <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                <MapPin className="h-3 w-3" />
                <span>{notification.location}</span>
                <span>•</span>
                <span>{notification.timeAgo}</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
