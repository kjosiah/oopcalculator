"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Users, TrendingUp, Globe } from "lucide-react"

export default function CustomerCounter() {
  const [stats, setStats] = useState({
    totalCustomers: 5247,
    onlineNow: 23,
    ordersToday: 47,
    countriesServed: 15,
  })

  useEffect(() => {
    const interval = setInterval(() => {
      setStats((prev) => ({
        ...prev,
        totalCustomers: prev.totalCustomers + Math.floor(Math.random() * 3),
        onlineNow: Math.max(15, prev.onlineNow + Math.floor(Math.random() * 5) - 2),
        ordersToday: prev.ordersToday + Math.floor(Math.random() * 2),
      }))
    }, 30000) // Update every 30 seconds

    return () => clearInterval(interval)
  }, [])

  return (
    <Card className="bg-gradient-to-r from-purple/5 to-coral/5 border-purple/20">
      <CardContent className="p-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="text-center">
            <div className="flex items-center justify-center mb-2">
              <Users className="h-5 w-5 text-purple mr-2" />
              <span className="text-2xl font-bold text-purple">{stats.totalCustomers.toLocaleString()}</span>
            </div>
            <p className="text-sm text-muted-foreground">Happy Students</p>
          </div>

          <div className="text-center">
            <div className="flex items-center justify-center mb-2">
              <div className="w-2 h-2 bg-success rounded-full animate-pulse mr-2"></div>
              <span className="text-2xl font-bold text-success">{stats.onlineNow}</span>
            </div>
            <p className="text-sm text-muted-foreground">Online Now</p>
          </div>

          <div className="text-center">
            <div className="flex items-center justify-center mb-2">
              <TrendingUp className="h-5 w-5 text-coral mr-2" />
              <span className="text-2xl font-bold text-coral">{stats.ordersToday}</span>
            </div>
            <p className="text-sm text-muted-foreground">Orders Today</p>
          </div>

          <div className="text-center">
            <div className="flex items-center justify-center mb-2">
              <Globe className="h-5 w-5 text-blue-600 mr-2" />
              <span className="text-2xl font-bold text-blue-600">{stats.countriesServed}</span>
            </div>
            <p className="text-sm text-muted-foreground">Countries</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
